@echo off
reg add HKCU\Console /v QuickEdit /t REG_DWORD /d 0 /f >nul 2>&1
cd /d "%~dp0"
cls

echo ===================================================================
echo   SHOPEE AUTO UPLOAD LOCAL - CLIENT SIEU MUOT (PORT 6868)
echo   Ket noi Server Ky Ma Cum Boxphone (192.168.1.14:3099)
echo ===================================================================
echo.

:: 1. Dong cua so Tool Upload cu (neu con mo ngam) va giai phong cong 6868
echo [1/3] Kiem tra va giai phong cong 6868...
taskkill /f /fi "WINDOWTITLE eq SHOPEE_UPLOAD_6868_RUNNER*" /t >nul 2>&1
title SHOPEE_UPLOAD_6868_RUNNER - TOOL UPLOAD (PORT 6868)
for /f "tokens=5" %%a in ('netstat -aon ^| findstr ":6868 " ^| findstr "LISTENING" 2^>nul') do (
    if not "%%a"=="0" taskkill /f /t /pid %%a >nul 2>&1
)
ping 127.0.0.1 -n 2 >nul

:: 2. Tim kiem Node.js
echo [2/3] Kiem tra Node.js...
set "NODE_BIN=node"
where node >nul 2>nul
if %errorlevel% neq 0 (
    if exist "C:\Program Files\nodejs\node.exe" (
        set "NODE_BIN=C:\Program Files\nodejs\node.exe"
        set "PATH=%PATH%;C:\Program Files\nodejs"
    ) else if exist "C:\Program Files (x86)\nodejs\node.exe" (
        set "NODE_BIN=C:\Program Files (x86)\nodejs\node.exe"
        set "PATH=%PATH%;C:\Program Files (x86)\nodejs"
    ) else if exist "node.exe" (
        set "NODE_BIN=node.exe"
    ) else if exist "CAI_DAT_NODEJS_TU_DONG.bat" (
        echo [!] Dang cai dat Node.js tu dong...
        call CAI_DAT_NODEJS_TU_DONG.bat AUTO
        if exist "C:\Program Files\nodejs\node.exe" (
            set "NODE_BIN=C:\Program Files\nodejs\node.exe"
            set "PATH=%PATH%;C:\Program Files\nodejs;C:\Users\%USERNAME%\AppData\Roaming\npm"
        )
    )
)

:: 3. Tu dong bat cua so App Giao Dien 6868 ngay khi cong 6868 LISTENING
echo [3/3] Khoi chay Web Dashboard doc lap tai http://127.0.0.1:6868 ...
echo.
start "" /min cmd /c call "%~dp0MO_GIAO_DIEN_6868.bat" WAIT_READY

:RESTART_LOOP
for /f "tokens=5" %%a in ('netstat -aon ^| findstr ":6868 " ^| findstr "LISTENING" 2^>nul') do (
    if not "%%a"=="0" taskkill /f /t /pid %%a >nul 2>&1
)
chcp 65001 >nul
"%NODE_BIN%" src/start.js
set "EXIT_CODE=%errorlevel%"
if "%EXIT_CODE%"=="0" exit /b 0
echo.
echo [!] Tien trinh Node tam dung (Ma: %EXIT_CODE%). Tu dong khoi dong lai sau 3 giay...
ping 127.0.0.1 -n 4 >nul
goto RESTART_LOOP
