// Toast function
function showToast(message, type = 'info') {
  const toastEl = document.getElementById('liveToast') || document.getElementById('toast-container');
  if (!toastEl) return;
  
  if (typeof window.showCyberToast === 'function') {
      window.showCyberToast(type === 'error' ? 'Lỗi' : 'Thông Báo', message, type);
      return;
  }
}

// Guard flags
let _fetchingThreads = false;
let _fetchingLogs = false;
let _fetchingTaskStats = false;

// Periodic updates
setInterval(() => {
  if (document.hidden) return;

  if (!_fetchingThreads && typeof loadThreads === 'function') {
    _fetchingThreads = true;
    try { loadThreads(); } catch(e) {}
    setTimeout(() => { _fetchingThreads = false; }, 5000);
  }

  if (!_fetchingLogs && typeof loadLogs === 'function') {
    _fetchingLogs = true;
    try { loadLogs(); } catch(e) {}
    setTimeout(() => { _fetchingLogs = false; }, 5000);
  }
}, 10000);

// Task stats polling
setInterval(() => {
  if (document.hidden) return;
  if (_fetchingTaskStats) return;
  _fetchingTaskStats = true;
  updateTaskStats().finally(() => { _fetchingTaskStats = false; });
}, 5000);

function updateTaskStats() {
  return fetch('/api/videos/task-stats')
    .then(res => res.json())
    .then(data => {
      if (!data.success) return;
      const s = data.stats;
      const el = (id) => document.getElementById(id);
      if (el('taskTotalCount')) el('taskTotalCount').textContent = s.total || 0;
      if (el('taskPendingCount')) el('taskPendingCount').textContent = s.pending || 0;
      if (el('taskUploadingCount')) el('taskUploadingCount').textContent = s.uploading || 0;
      if (el('taskCompletedCount')) el('taskCompletedCount').textContent = s.completed || 0;
      if (el('taskFailedCount')) el('taskFailedCount').textContent = s.failed || 0;
    })
    .catch(() => {});
}
