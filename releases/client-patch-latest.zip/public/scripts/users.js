// === User proxy inline edit ===
function toggleEditUserProxy(userId, currentProxy) {
  document.getElementById('proxyUserDisplay_' + userId).classList.add('d-none');
  document.getElementById('proxyUserEdit_' + userId).classList.remove('d-none');
  document.getElementById('proxyUserInput_' + userId).value = currentProxy || '';
  document.getElementById('proxyUserInput_' + userId).focus();
}
function cancelEditUserProxy(userId) {
  document.getElementById('proxyUserDisplay_' + userId).classList.remove('d-none');
  document.getElementById('proxyUserEdit_' + userId).classList.add('d-none');
}
function saveUserProxy(userId) {
  const proxy = document.getElementById('proxyUserInput_' + userId).value.trim();
  fetch(`/api/users/${userId}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ proxy }),
  })
    .then(res => res.json())
    .then(data => {
      if (data.success) {
        showToast('Cập nhật proxy thành công', 'success');
        loadUsers();
      } else {
        showToast(data.message || 'Lỗi', 'error');
      }
    })
    .catch(() => showToast('Lỗi kết nối', 'error'));
}

function exportUsersJson() {
  const a = document.createElement('a');
  a.href = '/api/users/export-json';
  a.download = '';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  showToast('Đang tải file JSON...', 'success');
}

function showImportJsonModal() {
  const modalEl = document.getElementById('importJsonModal');
  if (modalEl) new bootstrap.Modal(modalEl).show();
}

function showAddModal() {
  const modalEl = document.getElementById('addModal');
  if (modalEl) new bootstrap.Modal(modalEl).show();
}

function editUser(id, username, cookie, proxy) {
  const modalEl = document.getElementById('editModal');
  if (modalEl) {
      document.getElementById('editForm').action = `/users/${id}`;
      document.getElementById('editUsername').value = username;
      document.getElementById('editCookie').value = cookie;
      document.getElementById('editProxy').value = proxy || '';
      new bootstrap.Modal(modalEl).show();
  }
}

function showImportModal() {
  const modalEl = document.getElementById('importModal');
  if (modalEl) new bootstrap.Modal(modalEl).show();
}

function showBulkThreadModal() {
  const selectedUsers = document.querySelectorAll('.user-checkbox:checked');
  if (selectedUsers.length === 0) {
    showToast('Vui lòng chọn ít nhất một người dùng', 'warning');
    return;
  }
  const modalEl = document.getElementById('bulkThreadModal');
  if (modalEl) new bootstrap.Modal(modalEl).show();
}

function toggleAllUsers(checkbox) {
  const userCheckboxes = document.querySelectorAll(
    '.user-checkbox:not(:disabled)'
  );
  userCheckboxes.forEach((box) => {
    box.checked = checkbox.checked;
  });
}

// Xóa các tài khoản đã tích chọn
function deleteSelectedUsers() {
  const ids = Array.from(
    document.querySelectorAll('.user-checkbox:checked')
  ).map((cb) => cb.dataset.userId);

  if (ids.length === 0) {
    showToast('Vui lòng chọn ít nhất một tài khoản', 'warning');
    return;
  }
  if (!confirm(`Bạn có chắc muốn xóa ${ids.length} tài khoản đã chọn không?`)) {
    return;
  }
  fetch('/api/users/bulk-delete', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
    body: JSON.stringify({ ids }),
  })
    .then((res) => res.json())
    .then((data) => {
      if (data.success) {
        const selectAll = document.getElementById('selectAllUsers');
        if (selectAll) selectAll.checked = false;
        loadUsers();
        if (typeof loadThreads === 'function') loadThreads();
        showToast(data.message || `Đã xóa ${data.deleted} tài khoản`, 'success');
      } else {
        showToast(data.message || 'Xóa không thành công', 'error');
      }
    })
    .catch(() => showToast('Lỗi khi xóa tài khoản', 'error'));
}

// Xóa TẤT CẢ tài khoản
function deleteAllUsers() {
  if (!confirm('XÓA TẤT CẢ tài khoản? Hành động này KHÔNG THỂ hoàn tác!')) {
    return;
  }
  fetch('/api/users/bulk-delete', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
    body: JSON.stringify({ all: true }),
  })
    .then((res) => res.json())
    .then((data) => {
      if (data.success) {
        const selectAll = document.getElementById('selectAllUsers');
        if (selectAll) selectAll.checked = false;
        loadUsers();
        if (typeof loadThreads === 'function') loadThreads();
        showToast(data.message || `Đã xóa ${data.deleted} tài khoản`, 'success');
      } else {
        showToast(data.message || 'Xóa không thành công', 'error');
      }
    })
    .catch(() => showToast('Lỗi khi xóa tài khoản', 'error'));
}

function confirmDeleteUser(userId) {
  if (confirm('Bạn có chắc chắn muốn xóa người dùng này không?')) {
    fetch(`/api/users/${userId}`, {
      method: 'DELETE',
      headers: {
        Accept: 'application/json',
      },
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.success) {
          loadUsers();
          if (typeof loadThreads === 'function') loadThreads();
          showToast('Xóa người dùng thành công', 'success');
        } else {
          showToast(data.message || 'Xóa người dùng không thành công', 'error');
        }
      })
      .catch((error) => {
        console.error('Error:', error);
        showToast('Lỗi khi xóa người dùng', 'error');
      });
  }
  return false;
}

function loadUsers() {
  if (typeof loadAccountsTable === 'function') {
      loadAccountsTable();
  }
}
