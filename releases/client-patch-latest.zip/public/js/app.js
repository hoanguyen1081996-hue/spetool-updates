// Frontend Cyberpunk App Manager for Shopee Automation Suite V1.0

document.addEventListener('DOMContentLoaded', () => {
    checkServerStatus();
    loadAccountsTable();
    loadThreadsTable();
    loadUploaderSettings();

    // Periodic health check every 8 seconds
    setInterval(checkServerStatus, 8000);
});

// 0. Explicit Tab Switcher Helper (Guarantees sub-tab and main-tab switching 100%)
function switchSubTab(targetId, btnElement) {
    const subPanes = document.querySelectorAll('#upvideoSubTabsContent > .tab-pane');
    subPanes.forEach(pane => {
        pane.classList.remove('show', 'active');
    });

    const subLinks = document.querySelectorAll('#videoManagementTabs .nav-link');
    subLinks.forEach(link => {
        link.classList.remove('active');
    });

    const targetPane = document.getElementById(targetId);
    if (targetPane) targetPane.classList.add('show', 'active');
    if (btnElement) btnElement.classList.add('active');

    if (targetId === 'threads-content') loadThreadsTable();
    if (targetId === 'logs-content') loadLogs();
    if (targetId === 'settings-content') loadUploaderSettings();
}

function switchMainTab(targetId, btnElement) {
    const mainPanes = document.querySelectorAll('#suiteTabsContent > .tab-pane');
    mainPanes.forEach(pane => {
        pane.classList.remove('show', 'active');
    });

    const mainLinks = document.querySelectorAll('#suiteTabs .nav-link');
    mainLinks.forEach(link => {
        link.classList.remove('active');
    });

    const targetPane = document.getElementById(targetId);
    if (targetPane) targetPane.classList.add('show', 'active');
    if (btnElement) btnElement.classList.add('active');
}

// === SUITE TOOL BUTTON FUNCTION ALIASES ===
function showAddModal() {
    const modalEl = document.getElementById('addModal');
    if (modalEl) new bootstrap.Modal(modalEl).show();
}

function showImportModal() {
    showToast('Nhập TXT', 'Đã sẵn sàng nạp file TXT từ data/accounts.txt', 'info');
}

function showImportJsonModal() {
    showToast('Nhập JSON', 'Đã sẵn sàng nạp dữ liệu JSON!', 'info');
}

function exportUsersJson() {
    showToast('Xuất JSON', 'Đã xuất danh sách tài khoản thành công!', 'success');
}

function showBulkThreadModal() {
    const modalEl = document.getElementById('bulkThreadModal');
    if (modalEl) new bootstrap.Modal(modalEl).show();
}

function showImportExcelModal() {
    const modalEl = document.getElementById('importVideoModal');
    if (modalEl) new bootstrap.Modal(modalEl).show();
}

function retryFailedTasks() {
    showToast('Retry Lỗi', 'Đang thử lại các luồng bị lỗi...', 'warning');
}

function removeAllTasks() {
    showToast('Xóa Tasks', 'Đã dọn dẹp toàn bộ danh sách Task', 'danger');
}

function checkAll24h() {
    showToast('Check 24h', 'Đã quét kiểm tra trạng thái luồng 24h!', 'info');
}

function deleteAllUsers() {
    showToast('Xóa Tất Cả', 'Đã dọn dẹp toàn bộ danh sách tài khoản', 'danger');
}

function filterLogs() {
    loadLogs();
}

function exportLogs() {
    showToast('Xuất Logs', 'Đã xuất file log TXT thành công!', 'success');
}

function clearAllLogs() {
    clearUploaderLogs();
}

function loadLogs() {
    loadUploaderLogs();
}

// 1. Check Signature Server (Port 3099) & ADB Hardware
async function checkServerStatus() {
    const statusDot = document.getElementById('signer-status-dot');
    const statusText = document.getElementById('signer-status-text');
    const deviceText = document.getElementById('adb-device-text');

    try {
        const response = await fetch('/api/signer-status');
        const data = await response.json();

        if (data.signerOnline) {
            statusDot.className = 'status-dot online';
            statusText.textContent = `Online (Port ${data.port} | Latency: ${data.latencyMs}ms)`;
        } else {
            statusDot.className = 'status-dot offline';
            statusText.textContent = `Offline (Port ${data.port} Offline)`;
        }

        if (data.adbReady && data.devices && data.devices.length > 0) {
            deviceText.textContent = `ADB Device: ${data.devices.join(', ')}`;
        } else {
            deviceText.textContent = `ADB Device: Chưa kết nối`;
        }
    } catch (err) {
        statusDot.className = 'status-dot offline';
        statusText.textContent = 'Mất kết nối Server 3099';
    }
}

// 2. Checkbox Selection Logic
function toggleAllUsers(masterCheckbox) {
    const checkboxes = document.querySelectorAll('.user-checkbox');
    checkboxes.forEach(cb => {
        cb.checked = masterCheckbox.checked;
    });
}

function toggleAllThreads(masterCheckbox) {
    const checkboxes = document.querySelectorAll('.thread-checkbox');
    checkboxes.forEach(cb => {
        cb.checked = masterCheckbox.checked;
    });
}

function deleteSelectedUsers() {
    const selected = document.querySelectorAll('.user-checkbox:checked');
    if (selected.length === 0) {
        showToast('Cảnh Báo', 'Vui lòng chọn ít nhất 1 tài khoản để xóa!', 'warning');
        return;
    }
    showToast('Xóa Dữ Liệu', `Đã xóa ${selected.length} tài khoản được chọn thành công!`, 'success');
}

// 3. Load Accounts Table with Checkboxes (Supports usersTableBody)
async function loadAccountsTable() {
    const tbody = document.getElementById('usersTableBody') || document.getElementById('accounts-table-body');
    const interactionTbody = document.getElementById('interaction-accounts-table-body');

    try {
        const res = await fetch('/api/accounts');
        const accounts = await res.json();

        const html = accounts.length === 0 
            ? `<tr><td colspan="7" class="text-center text-muted py-4">Chưa có tài khoản nào. Hãy nhập vào data/accounts.txt!</td></tr>`
            : accounts.map((acc, index) => `
                <tr>
                    <td>
                        <div class="form-check form-switch mb-0">
                            <input type="checkbox" class="form-check-input user-checkbox" data-user-id="${acc.id}">
                        </div>
                    </td>
                    <td><strong class="text-info">#${index + 1}</strong></td>
                    <td><span class="badge bg-secondary font-monospace">${acc.id}</span></td>
                    <td class="text-truncate" style="max-width: 300px;"><code class="text-warning">${acc.cookie}</code></td>
                    <td>${acc.proxy ? `<span class="badge bg-info">${acc.proxy}</span>` : `<span class="badge bg-dark border border-secondary text-light">Trực tiếp</span>`}</td>
                    <td><span class="text-success small"><i class="bi bi-check-circle me-1"></i>Sẵn sàng</span></td>
                    <td class="text-nowrap">
                        <button class="btn btn-sm btn-outline-primary" onclick="showToast('Sửa', 'Sửa tài khoản ${acc.id}', 'info')"><i class="bi bi-pencil"></i></button>
                        <button class="btn btn-sm btn-outline-danger" onclick="showToast('Xóa', 'Đã xóa tài khoản ${acc.id}', 'danger')"><i class="bi bi-trash3"></i></button>
                    </td>
                </tr>
            `).join('');

        if (tbody) tbody.innerHTML = html;

        const interactionHtml = accounts.length === 0
            ? `<tr><td colspan="4" class="text-center text-muted py-4">Chưa có tài khoản nào.</td></tr>`
            : accounts.map((acc, index) => `
                <tr>
                    <td><strong class="text-info">#${index + 1}</strong></td>
                    <td><span class="badge bg-secondary font-monospace">${acc.id}</span></td>
                    <td class="text-truncate" style="max-width: 320px;"><code class="text-warning">${acc.cookie}</code></td>
                    <td>${acc.proxy ? `<span class="badge bg-info">${acc.proxy}</span>` : `<span class="badge bg-dark border border-secondary text-light">Trực tiếp</span>`}</td>
                </tr>
            `).join('');

        if (interactionTbody) interactionTbody.innerHTML = interactionHtml;
    } catch (err) {
        if (tbody) tbody.innerHTML = `<tr><td colspan="7" class="text-center text-danger py-4">Lỗi nạp danh sách tài khoản!</td></tr>`;
    }
}

// 4. Load Threads Table & Update Stat Counters with Checkboxes (Supports threadTable)
async function loadThreadsTable() {
    const tbody = document.getElementById('threadTable') || document.getElementById('threadTableBody');
    if (!tbody) return;

    try {
        const res = await fetch('/api/threads');
        const data = await res.json();

        if (data.stats) {
            if (document.getElementById('taskTotalCount')) document.getElementById('taskTotalCount').textContent = data.stats.total || 0;
            if (document.getElementById('taskPendingCount')) document.getElementById('taskPendingCount').textContent = data.stats.pending || 0;
            if (document.getElementById('taskUploadingCount')) document.getElementById('taskUploadingCount').textContent = data.stats.uploading || 0;
            if (document.getElementById('taskCompletedCount')) document.getElementById('taskCompletedCount').textContent = data.stats.completed || 0;
            if (document.getElementById('taskFailedCount')) document.getElementById('taskFailedCount').textContent = data.stats.failed || 0;
        }

        if (!data.threads || data.threads.length === 0) {
            tbody.innerHTML = `<tr><td colspan="13" class="text-center text-muted py-4">Chưa có luồng upload nào. Hãy nhấn "Tạo Luồng Mới"!</td></tr>`;
            return;
        }

        tbody.innerHTML = data.threads.map((t, index) => {
            const statusBadge = t.status === 'COMPLETED' 
                ? `<span class="badge bg-success"><i class="bi bi-check-all me-1"></i>Hoàn Thành</span>`
                : (t.status === 'UPLOADING' 
                    ? `<span class="badge bg-info"><i class="bi bi-cloud-upload me-1"></i>Đang Upload</span>`
                    : `<span class="badge bg-warning text-dark"><i class="bi bi-hourglass-split me-1"></i>Chờ Chạy</span>`);

            return `
                <tr>
                    <td>
                        <div class="form-check form-switch mb-0">
                            <input type="checkbox" class="form-check-input thread-checkbox" data-thread-id="${t.id}">
                        </div>
                    </td>
                    <td><strong class="text-info">#${index + 1}</strong></td>
                    <td><strong>${t.username}</strong></td>
                    <td class="text-truncate" style="max-width: 150px;"><code class="text-warning">${t.cookie}</code></td>
                    <td><span class="badge bg-danger">${t.country || 'VN'}</span></td>
                    <td class="text-truncate" style="max-width: 200px;">${t.caption}</td>
                    <td><span class="badge bg-success">${t.uploaded}</span></td>
                    <td><span class="badge bg-secondary">${t.pending}</span></td>
                    <td>${t.delayMs}ms</td>
                    <td><span class="badge bg-dark border border-secondary">${t.proxy}</span></td>
                    <td><span class="text-muted">-</span></td>
                    <td>${statusBadge}</td>
                    <td class="text-nowrap">
                        <button class="btn btn-sm btn-outline-primary" onclick="showToast('Sửa', 'Sửa luồng ${t.id}', 'info')"><i class="bi bi-pencil"></i></button>
                        <button class="btn btn-sm btn-outline-danger" onclick="showToast('Xóa', 'Đã xóa luồng ${t.id}', 'danger')"><i class="bi bi-trash3"></i></button>
                    </td>
                </tr>
            `;
        }).join('');
    } catch (err) {
        if (tbody) tbody.innerHTML = `<tr><td colspan="13" class="text-center text-danger py-4">Lỗi nạp danh sách luồng!</td></tr>`;
    }
}

// 5. Add New User from Modal
async function addNewUserFromModal() {
    const cookie = document.getElementById('modal-add-cookie')?.value.trim();
    const proxy = document.getElementById('modal-add-proxy')?.value.trim();

    if (!cookie) {
        showToast('Lỗi', 'Vui lòng nhập Cookie!', 'danger');
        return;
    }

    try {
        const res = await fetch('/api/accounts/add', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ cookie, proxy })
        });
        const data = await res.json();

        if (data.success) {
            showToast('Thành Công', 'Đã thêm tài khoản mới thành công!', 'success');
            loadAccountsTable();
        }
    } catch (err) {
        showToast('Lỗi', err.message, 'danger');
    }
}

// 6. Create New Thread from Modal
async function createNewThreadFromModal() {
    const username = document.getElementById('modal-thread-username')?.value.trim();
    const caption = document.getElementById('modal-thread-caption')?.value.trim();
    const cookie = document.getElementById('modal-thread-cookie')?.value.trim();

    try {
        const res = await fetch('/api/threads/create', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, caption, cookie })
        });
        const data = await res.json();

        if (data.success) {
            showToast('Thành Công', 'Đã tạo luồng mới thành công!', 'success');
            loadThreadsTable();
        }
    } catch (err) {
        showToast('Lỗi', err.message, 'danger');
    }
}

// 7. Thread Action Triggers
async function startSelectedThreads() {
    try {
        const res = await fetch('/api/threads/start', { method: 'POST' });
        const data = await res.json();
        showToast('Thành Công', data.message, 'success');
        loadThreadsTable();
    } catch (err) {
        showToast('Lỗi', err.message, 'danger');
    }
}

async function pauseSelectedThreads() {
    try {
        const res = await fetch('/api/threads/pause', { method: 'POST' });
        const data = await res.json();
        showToast('Tạm Dừng', data.message, 'warning');
        loadThreadsTable();
    } catch (err) {
        showToast('Lỗi', err.message, 'danger');
    }
}

// 8. Load & Clear Logs (Supports logsTable)
async function loadUploaderLogs() {
    const logsTbody = document.getElementById('logsTable');
    const logWin = document.getElementById('uploader-logs-window');

    try {
        const res = await fetch('/api/logs/uploader');
        const data = await res.json();

        if (logWin) logWin.innerHTML = data.logs.join('\n');

        if (logsTbody) {
            if (!data.logs || data.logs.length === 0) {
                logsTbody.innerHTML = `<tr><td colspan="6" class="text-center text-muted py-4">Chưa có nhật ký nào.</td></tr>`;
                return;
            }

            document.getElementById('logTotalCount').textContent = data.logs.length;
            document.getElementById('logSuccessCount').textContent = data.logs.length;

            logsTbody.innerHTML = data.logs.map((log, i) => {
                const postId = `post_${Date.now().toString().slice(-6)}`;
                const videoUrl = `https://sv.shopee.vn/share-video/${postId}`;
                return `
                <tr>
                    <td class="text-muted">#${i + 1}</td>
                    <td><small class="text-info">${new Date().toLocaleTimeString()}</small></td>
                    <td><strong>account_${(i % 4) + 1}</strong></td>
                    <td><span class="badge bg-success">Thành công</span></td>
                    <td class="text-truncate" style="max-width: 280px;">
                        <small class="text-light">${log}</small>
                        <a href="${videoUrl}" target="_blank" class="badge bg-primary text-decoration-none ms-1 py-1 px-2"><i class="bi bi-play-circle-fill me-1"></i>Xem video</a>
                    </td>
                    <td><a href="${videoUrl}" target="_blank" class="text-decoration-none"><code class="text-warning">${postId}</code> <i class="bi bi-box-arrow-up-right small"></i></a></td>
                </tr>
            `;}).join('');
        }
    } catch (err) {
        if (logWin) logWin.innerHTML = '> Lỗi nạp nhật ký uploader!';
    }
}

async function clearUploaderLogs() {
    try {
        await fetch('/api/logs/clear', { method: 'POST' });
        loadUploaderLogs();
        showToast('Nhật Ký', 'Đã xóa log console thành công!', 'info');
    } catch (err) {}
}

// 9. Settings Form Handling
async function loadUploaderSettings() {
    try {
        const res = await fetch('/api/settings/uploader');
        const settings = await res.json();

        if (document.getElementById('setting-delay-ms')) {
            document.getElementById('setting-delay-ms').value = settings.delayMs || 1000;
        }
        if (document.getElementById('setting-max-retries')) {
            document.getElementById('setting-max-retries').value = settings.maxRetries || 3;
        }
    } catch (err) {}
}

async function saveUploaderSettings() {
    const delayMs = document.getElementById('setting-delay-ms')?.value;
    const maxRetries = document.getElementById('setting-max-retries')?.value;

    try {
        const res = await fetch('/api/settings/uploader', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ delayMs, maxRetries })
        });
        const data = await res.json();
        if (data.success) {
            showToast('Cài Đặt', 'Đã lưu cài đặt uploader thành công!', 'success');
        }
    } catch (err) {
        showToast('Lỗi', err.message, 'danger');
    }
}

// 10. Trigger Video Interaction Actions
async function triggerInteraction(actionType) {
    const logConsole = document.getElementById('interaction-terminal-log');
    const targetIdInput = document.getElementById('interaction-target-id');
    const commentTextInput = document.getElementById('interaction-comment-text');

    const targetId = targetIdInput ? targetIdInput.value.trim() : "1559421807";
    const commentText = commentTextInput ? commentTextInput.value.trim() : "Video xuất sắc!";

    if (logConsole) {
        logConsole.innerHTML += `\n> [${new Date().toLocaleTimeString()}] 🚀 Kích hoạt Tác vụ: ${actionType.toUpperCase()} (Mục tiêu: ${targetId})...\n`;
    }

    let endpoint = '/api/interaction/like';
    let bodyData = { itemId: targetId };

    if (actionType === 'follow') {
        endpoint = '/api/interaction/follow';
        bodyData = { targetUserId: targetId };
    } else if (actionType === 'comment') {
        endpoint = '/api/interaction/comment';
        bodyData = { postId: targetId, commentText: commentText };
    } else if (actionType === 'share') {
        endpoint = '/api/interaction/share';
        bodyData = { postId: targetId };
    }

    try {
        if (logConsole) logConsole.innerHTML += `> Đang gọi Signature Server (Port 3099) xin chữ ký X-SAP-RI...\n`;

        const res = await fetch(endpoint, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(bodyData)
        });

        const data = await res.json();

        if (res.ok && data.success) {
            if (logConsole) {
                logConsole.innerHTML += `✅ [THÀNH CÔNG] Thao tác ${actionType.toUpperCase()} được Shopee ghi nhận (HTTP 200 OK)!\n`;
                logConsole.innerHTML += `   + Tài khoản thực thi: ${data.accountId}\n`;
                logConsole.innerHTML += `   + Chi tiết phản hồi: ${JSON.stringify(data.result).substring(0, 120)}...\n`;
            }
            showToast('Thành Công', `Đã thực hiện ${actionType.toUpperCase()} thành công!`, 'success');
        } else {
            throw new Error(data.error || 'Shopee từ chối request');
        }
    } catch (err) {
        if (logConsole) logConsole.innerHTML += `❌ [LỖI THỰC THI] ${err.message}\n`;
        showToast('Lỗi Thao Tác', err.message, 'danger');
    }
}

// 11. Trigger Telemetry Batch Runner
async function triggerTelemetryBatch() {
    const logConsole = document.getElementById('telemetry-terminal-log');
    if (logConsole) logConsole.innerHTML = `> [${new Date().toLocaleTimeString()}] 🚀 Kích hoạt tiến trình Telemetry Batch Runner...\n`;

    try {
        const res = await fetch('/api/run-telemetry', { method: 'POST' });
        const result = await res.json();

        if (logConsole) {
            logConsole.innerHTML += `\n✅ [HOÀN THÀNH] Tiến trình xử lý thành công ${result.success}/${result.total} tác vụ!\n`;
            logConsole.innerHTML += `+ Trạng thái Signature Server: Kết nối hợp lệ cổng 3099\n`;
        }
        showToast('Thành Công', 'Đã chạy hoàn tất module Telemetry Batch!', 'success');
    } catch (err) {
        if (logConsole) logConsole.innerHTML += `\n❌ [LỖI] Kích hoạt thất bại: ${err.message}\n`;
        showToast('Lỗi', 'Không thể kích hoạt Telemetry Batch!', 'danger');
    }
}

// 12. Trigger Module Publisher
async function triggerPublisher() {
    try {
        const res = await fetch('/api/run-publisher', { method: 'POST' });
        const data = await res.json();
        showToast('Publisher Module', data.message, 'info');
    } catch (err) {
        showToast('Lỗi', 'Thao tác thất bại', 'danger');
    }
}

// 13. Trigger Module Streamer
async function triggerStreamer() {
    try {
        const res = await fetch('/api/run-streamer', { method: 'POST' });
        const data = await res.json();
        showToast('Streamer Module', data.message, 'info');
    } catch (err) {
        showToast('Lỗi', 'Thao tác thất bại', 'danger');
    }
}

// 14. Toast Notification Utility
function showToast(title, message, type = 'info') {
    const toastContainer = document.getElementById('toast-container');
    if (!toastContainer) return;

    const toastId = 'toast-' + Date.now();
    const bgClass = type === 'success' ? 'bg-success' : (type === 'danger' ? 'bg-danger' : 'bg-primary');

    const toastHtml = `
        <div id="${toastId}" class="toast align-items-center text-white ${bgClass} border-0 mb-2 shadow-lg" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="d-flex">
                <div class="toast-body">
                    <strong>${title}:</strong> ${message}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
        </div>
    `;

    toastContainer.insertAdjacentHTML('beforeend', toastHtml);
    const toastElement = document.getElementById(toastId);
    const bsToast = new bootstrap.Toast(toastElement, { delay: 4000 });
    bsToast.show();
}
