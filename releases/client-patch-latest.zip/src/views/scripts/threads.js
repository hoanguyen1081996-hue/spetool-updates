const a0_0x25f3c7=a0_0x4f86;(function(_0x219519,_0x3c2059){const _0x5eed0c=a0_0x4f86,_0x1b3aa4=_0x219519();while(!![]){try{const _0x4994c1=parseInt(_0x5eed0c(0x253))/0x1+-parseInt(_0x5eed0c(0x198))/0x2+-parseInt(_0x5eed0c(0x15c))/0x3+parseInt(_0x5eed0c(0x16f))/0x4+-parseInt(_0x5eed0c(0x197))/0x5+-parseInt(_0x5eed0c(0x174))/0x6+-parseInt(_0x5eed0c(0x209))/0x7*(parseInt(_0x5eed0c(0x242))/0x8);if(_0x4994c1===_0x3c2059)break;else _0x1b3aa4['push'](_0x1b3aa4['shift']());}catch(_0xaa2169){_0x1b3aa4['push'](_0x1b3aa4['shift']());}}}(a0_0x5428,0x30474));const COUNTRY_LIST=[{'code':'vn','flag':a0_0x25f3c7(0x251),'name':'Việt\x20Nam','tld':'vn'},{'code':'sg','flag':'🇸🇬','name':a0_0x25f3c7(0x1c7),'tld':'sg'},{'code':'ph','flag':a0_0x25f3c7(0x1aa),'name':'Philippines','tld':'ph'},{'code':'id','flag':a0_0x25f3c7(0x202),'name':a0_0x25f3c7(0x1a5),'tld':'co.id'},{'code':'th','flag':a0_0x25f3c7(0x1dd),'name':a0_0x25f3c7(0x237),'tld':a0_0x25f3c7(0x15e)},{'code':'my','flag':a0_0x25f3c7(0x26d),'name':a0_0x25f3c7(0x234),'tld':'com.my'},{'code':'br','flag':'🇧🇷','name':a0_0x25f3c7(0x245),'tld':a0_0x25f3c7(0x161)}];function getCountryDisplay(_0x488048){const _0x4e5e00=a0_0x25f3c7,_0x324b9f=COUNTRY_LIST[_0x4e5e00(0x16e)](_0x4e748e=>_0x4e748e['code']===(_0x488048||'vn')[_0x4e5e00(0x1fa)]())||COUNTRY_LIST[0x0];return _0x324b9f[_0x4e5e00(0x1c0)]+'\x20'+_0x324b9f[_0x4e5e00(0x213)]['toUpperCase']();}const _check24hCache={};function check24h(_0x41d3ee){const _0x2b0912=a0_0x25f3c7,_0x1b235d=document[_0x2b0912(0x1d3)](_0x2b0912(0x113)+_0x41d3ee),_0x4c525a=document[_0x2b0912(0x1d3)](_0x2b0912(0x201)+_0x41d3ee);if(_0x1b235d)_0x1b235d['disabled']=!![];if(_0x4c525a)_0x4c525a[_0x2b0912(0x17f)]='...';fetch(_0x2b0912(0x12a)+_0x41d3ee+_0x2b0912(0x112))['then'](_0x5a7ad0=>_0x5a7ad0[_0x2b0912(0x1a0)]())[_0x2b0912(0x232)](_0x1bd616=>{const _0xc4673e=_0x2b0912;if(_0x1bd616[_0xc4673e(0x127)]){_check24hCache[_0x41d3ee]={'count':_0x1bd616[_0xc4673e(0x195)],'userName':_0x1bd616[_0xc4673e(0x1cd)],'canPost':_0x1bd616[_0xc4673e(0x1ad)],'success':!![]},applyCheck24hResult(_0x41d3ee);const _0x4feb44=_0x1bd616[_0xc4673e(0x1ad)]?'':'\x20|\x20BỊ\x20HẠN\x20CHẾ';showToast(_0x1bd616['userName']+':\x20'+_0x1bd616[_0xc4673e(0x195)]+'\x20video/24h'+_0x4feb44,_0x1bd616[_0xc4673e(0x1ad)]?_0x1bd616[_0xc4673e(0x195)]>=0x14?_0xc4673e(0x183):_0xc4673e(0x127):_0xc4673e(0x1d2));}else{const _0xdeb017=(_0x1bd616[_0xc4673e(0x1d2)]||'')['includes'](_0xc4673e(0x1f6))||(_0x1bd616[_0xc4673e(0x1d2)]||'')[_0xc4673e(0x159)](_0xc4673e(0x1ef))||(_0x1bd616[_0xc4673e(0x1d2)]||'')['includes'](_0xc4673e(0x23a));_check24hCache[_0x41d3ee]={'error':_0x1bd616[_0xc4673e(0x1d2)],'success':![],'banned':_0xdeb017},applyCheck24hResult(_0x41d3ee),showToast(_0x1bd616[_0xc4673e(0x1d2)],'error');}})[_0x2b0912(0x21d)](()=>{_check24hCache[_0x41d3ee]={'error':'Lỗi\x20kết\x20nối','success':![]},applyCheck24hResult(_0x41d3ee),showToast('Lỗi\x20kết\x20nối\x20check\x2024h','error');})[_0x2b0912(0x219)](()=>{const _0x4d4afc=_0x2b0912;if(_0x1b235d)_0x1b235d[_0x4d4afc(0x176)]=![];});}function applyCheck24hResult(_0x77f514){const _0x3a611e=a0_0x25f3c7,_0x2cbc9b=_check24hCache[_0x77f514];if(!_0x2cbc9b)return;const _0x1f5dfa=document[_0x3a611e(0x1d3)](_0x3a611e(0x113)+_0x77f514),_0x4d62ed=document['getElementById']('check24hResult_'+_0x77f514);if(!_0x1f5dfa||!_0x4d62ed)return;if(_0x2cbc9b[_0x3a611e(0x127)]){const _0x417fcb=_0x2cbc9b[_0x3a611e(0x20a)];!_0x2cbc9b[_0x3a611e(0x1ad)]?(_0x1f5dfa[_0x3a611e(0x247)]='btn\x20btn-sm\x20btn-dark',_0x4d62ed[_0x3a611e(0x17f)]=_0x417fcb+_0x3a611e(0x1e0),_0x1f5dfa[_0x3a611e(0x25f)]=_0x2cbc9b[_0x3a611e(0x1cd)]+':\x20'+_0x417fcb+'\x20video/24h\x20-\x20BỊ\x20HẠN\x20CHẾ\x20ĐĂNG'):(_0x1f5dfa[_0x3a611e(0x247)]=_0x3a611e(0x1a1)+(_0x417fcb>=0x14?'btn-danger':_0x417fcb>=0xa?'btn-warning':_0x3a611e(0x185)),_0x4d62ed['textContent']=_0x417fcb,_0x1f5dfa[_0x3a611e(0x25f)]=_0x2cbc9b[_0x3a611e(0x1cd)]+':\x20'+_0x417fcb+_0x3a611e(0x1c1));}else _0x2cbc9b[_0x3a611e(0x1bd)]?(_0x1f5dfa['className']=_0x3a611e(0x1e9),_0x4d62ed[_0x3a611e(0x17f)]='BAN',_0x1f5dfa[_0x3a611e(0x25f)]=_0x2cbc9b['error']):(_0x1f5dfa[_0x3a611e(0x247)]='btn\x20btn-sm\x20btn-outline-danger',_0x4d62ed[_0x3a611e(0x17f)]='!',_0x1f5dfa['title']=_0x2cbc9b[_0x3a611e(0x1d2)]);}function restoreAllCheck24h(){for(const _0x23be12 of Object['keys'](_check24hCache)){applyCheck24hResult(_0x23be12);}}async function checkAll24h(){const _0x40bc7c=a0_0x25f3c7,_0x560570=Array[_0x40bc7c(0x26c)](document['querySelectorAll']('.thread-checkbox:checked'))[_0x40bc7c(0x188)](_0x5e7798=>_0x5e7798['dataset'][_0x40bc7c(0x1c8)])[_0x40bc7c(0x173)](_0x256f41=>_0x256f41!==undefined);if(_0x560570[_0x40bc7c(0x192)]===0x0){showToast(_0x40bc7c(0x1bb),_0x40bc7c(0x183));return;}showToast(_0x40bc7c(0x222)+_0x560570[_0x40bc7c(0x192)]+_0x40bc7c(0x1a2),_0x40bc7c(0x278));for(const _0x2ef4aa of _0x560570){check24h(_0x2ef4aa),await new Promise(_0x8e340d=>setTimeout(_0x8e340d,0x1f4));}}function updateCountdowns(){const _0x4c5a9d=a0_0x25f3c7,_0x50e647=Math[_0x4c5a9d(0x143)](Date[_0x4c5a9d(0x151)]()/0x3e8);document[_0x4c5a9d(0x18d)](_0x4c5a9d(0x265))[_0x4c5a9d(0x23b)](_0x2b30d6=>{const _0x48e965=_0x4c5a9d,_0x138f53=parseInt(_0x2b30d6[_0x48e965(0x1c2)][_0x48e965(0x256)]||'0'),_0x510142=_0x138f53-_0x50e647;_0x510142>0x0?(_0x2b30d6[_0x48e965(0x17f)]=_0x510142+'s',_0x2b30d6['className']=_0x48e965(0x181),_0x2b30d6[_0x48e965(0x1f1)][_0x48e965(0x1f7)]=_0x48e965(0x171)):(_0x2b30d6[_0x48e965(0x17f)]=_0x48e965(0x240),_0x2b30d6[_0x48e965(0x247)]=_0x48e965(0x203),_0x2b30d6[_0x48e965(0x1f1)][_0x48e965(0x1f7)]=_0x48e965(0x171));});}setInterval(updateCountdowns,0x3e8);function showCreateThreadModal(){const _0x16fb23=a0_0x25f3c7,_0x581a7b=new bootstrap[(_0x16fb23(0x18c))](document[_0x16fb23(0x1d3)](_0x16fb23(0x134)));_0x581a7b[_0x16fb23(0x210)]();}function loadThreads(){const _0x43d9e6=a0_0x25f3c7,_0x577f82=Array[_0x43d9e6(0x26c)](document[_0x43d9e6(0x18d)](_0x43d9e6(0x21a)))[_0x43d9e6(0x188)](_0x36697d=>_0x36697d[_0x43d9e6(0x1c2)]['threadId']);fetch(_0x43d9e6(0x1a8))[_0x43d9e6(0x232)](_0x48f8bf=>_0x48f8bf['json']())['then'](_0x34b882=>{const _0x3cca26=_0x43d9e6,_0xc43701=document[_0x3cca26(0x1d3)]('threadTable');_0xc43701[_0x3cca26(0x18a)]=_0x34b882[_0x3cca26(0x188)]((_0x4cc05e,_0x272839)=>{const _0x1a1981=_0x3cca26;let _0x338c08='-',_0x38457c=![];if(_0x4cc05e['proxy_host']&&_0x4cc05e[_0x1a1981(0x23e)]){_0x338c08=_0x4cc05e[_0x1a1981(0x11c)]+':'+_0x4cc05e[_0x1a1981(0x23e)];if(_0x4cc05e['proxy_username'])_0x338c08+=':'+_0x4cc05e['proxy_username']+_0x1a1981(0x139);}else{if(_0x4cc05e[_0x1a1981(0x227)]){const _0x13de2c=String(_0x4cc05e[_0x1a1981(0x227)]);let _0x228c87='';for(const _0x56f549 of[_0x1a1981(0x1eb),_0x1a1981(0x221),_0x1a1981(0x20b),_0x1a1981(0x1d0),'https://']){if(_0x13de2c[_0x1a1981(0x1fa)]()[_0x1a1981(0x115)](_0x56f549)){_0x228c87=_0x56f549;break;}}const _0x1a302f=_0x13de2c[_0x1a1981(0x17b)](_0x228c87['length']),_0x1ad11b=_0x1a302f['split'](':');_0x1ad11b['length']===0x4?_0x338c08=''+_0x228c87+_0x1ad11b[0x0]+':'+_0x1ad11b[0x1]+':'+_0x1ad11b[0x2]+_0x1a1981(0x139):_0x338c08=_0x13de2c,_0x38457c=!![];}}const _0x5e5809={'stop':{'badge':'bg-secondary','icon':_0x1a1981(0x17a),'label':_0x1a1981(0x25c)},'done':{'badge':_0x1a1981(0x238),'icon':_0x1a1981(0x25e),'label':'Xong'},'error':{'badge':_0x1a1981(0x252),'icon':_0x1a1981(0x199),'label':_0x1a1981(0x231)},'inprogress':{'badge':_0x1a1981(0x269),'icon':'bi-play-circle','label':_0x1a1981(0x131)}},_0x5b83a7=_0x5e5809[_0x4cc05e[_0x1a1981(0x1cf)]]||{'badge':'bg-secondary','icon':'','label':_0x4cc05e[_0x1a1981(0x1cf)]},_0x5cc7a6=_0x577f82[_0x1a1981(0x159)](_0x4cc05e['id'][_0x1a1981(0x16a)]())?'checked':'',_0x47c844=[_0x1a1981(0x1be),_0x1a1981(0x21f),_0x1a1981(0x1d2)][_0x1a1981(0x159)](_0x4cc05e[_0x1a1981(0x1cf)]),_0x2888ab=_0x4cc05e['cookie']?_0x4cc05e['cookie'][_0x1a1981(0x116)](0x0,0x19)+_0x1a1981(0x1a6):'-';return _0x1a1981(0x19d)+_0x4cc05e['id']+'\x22\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20data-thread-status=\x22'+_0x4cc05e['status']+_0x1a1981(0x13a)+_0x4cc05e['id']+'\x22\x20'+_0x5cc7a6+_0x1a1981(0x14d)+(_0x272839+0x1)+_0x1a1981(0x24d)+_0x4cc05e[_0x1a1981(0x1b7)]+_0x1a1981(0x164)+_0x4cc05e[_0x1a1981(0x19c)]+_0x1a1981(0x1e2)+(_0x4cc05e['upload_mode']==='duet'?'\x20<span\x20class=\x22badge\x20bg-info\x22\x20style=\x22font-size:0.6rem\x22>DUET</span>':_0x4cc05e['upload_mode']===_0x1a1981(0x257)?'\x20<span\x20class=\x22badge\x20bg-warning\x20text-dark\x22\x20style=\x22font-size:0.6rem\x22>AUTO</span>':'')+(_0x4cc05e[_0x1a1981(0x279)]?_0x1a1981(0x20e):'')+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20class=\x22btn\x20btn-sm\x20p-0\x20text-primary\x22\x20onclick=\x22toggleEditUsername('+_0x4cc05e['user_id']+_0x1a1981(0x25d)+_0x4cc05e['username']+'\x27)\x22\x20title=\x22Sửa\x20username\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<i\x20class=\x22bi\x20bi-pencil-square\x22\x20style=\x22font-size:0.7rem\x22></i>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20id=\x22usernameEdit_'+_0x4cc05e['user_id']+_0x1a1981(0x167)+_0x4cc05e[_0x1a1981(0x19c)]+'\x22\x20id=\x22usernameInput_'+_0x4cc05e[_0x1a1981(0x1b7)]+_0x1a1981(0x177)+_0x4cc05e['user_id']+')\x22><i\x20class=\x22bi\x20bi-check\x22></i></button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20class=\x22btn\x20btn-secondary\x20btn-sm\x22\x20onclick=\x22cancelEditUsername('+_0x4cc05e[_0x1a1981(0x1b7)]+')\x22><i\x20class=\x22bi\x20bi-x\x22></i></button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</td>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<td>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22d-flex\x20align-items-center\x20gap-1\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<code\x20class=\x22small\x20text-truncate\x22\x20style=\x22max-width:130px;display:inline-block\x22\x20title=\x22'+_0x2888ab+'\x22>'+_0x2888ab+_0x1a1981(0x22f)+_0x4cc05e[_0x1a1981(0x1b7)]+_0x1a1981(0x25d)+_0x4cc05e[_0x1a1981(0x19c)]+_0x1a1981(0x17e)+_0x4cc05e['id']+_0x1a1981(0x15f)+(_0x4cc05e[_0x1a1981(0x249)]||'vn')['toUpperCase']()+'\x22>'+getCountryDisplay(_0x4cc05e[_0x1a1981(0x249)])+_0x1a1981(0x184)+_0x4cc05e['id']+_0x1a1981(0x25d)+(_0x4cc05e[_0x1a1981(0x249)]||'vn')+_0x1a1981(0x24e)+_0x4cc05e['id']+_0x1a1981(0x18b)+_0x4cc05e['id']+_0x1a1981(0x144)+COUNTRY_LIST[_0x1a1981(0x188)](_0x4e1e5c=>_0x1a1981(0x128)+_0x4e1e5c[_0x1a1981(0x213)]+'\x22\x20'+((_0x4cc05e[_0x1a1981(0x249)]||'vn')===_0x4e1e5c['code']?_0x1a1981(0x186):'')+'>'+_0x4e1e5c['flag']+'\x20'+_0x4e1e5c[_0x1a1981(0x213)][_0x1a1981(0x129)]()+_0x1a1981(0x26b))[_0x1a1981(0x1ea)]('')+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</select>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20class=\x22btn\x20btn-success\x20btn-sm\x22\x20onclick=\x22saveThreadCountry('+_0x4cc05e['id']+_0x1a1981(0x1b1)+_0x4cc05e['id']+_0x1a1981(0x149)+_0x4cc05e[_0x1a1981(0x1b7)]+_0x1a1981(0x25d)+_0x4cc05e[_0x1a1981(0x19c)]+_0x1a1981(0x20d)+_0x4cc05e[_0x1a1981(0x150)]+_0x1a1981(0x172)+_0x4cc05e['videos_uploaded']+_0x1a1981(0x1b0)+_0x4cc05e[_0x1a1981(0x150)]+_0x1a1981(0x165)+(_0x4cc05e[_0x1a1981(0x150)]-_0x4cc05e['videos_uploaded']>0x0?_0x1a1981(0x13f):'bg-success')+'\x22>'+Math['max'](0x0,_0x4cc05e[_0x1a1981(0x150)]-_0x4cc05e[_0x1a1981(0x23d)])+_0x1a1981(0x136)+(_0x4cc05e[_0x1a1981(0x19a)]||0x3c)+'-'+(_0x4cc05e[_0x1a1981(0x246)]||0xb4)+_0x1a1981(0x273)+(_0x4cc05e[_0x1a1981(0x1cf)]===_0x1a1981(0x1af)?'<br><span\x20class=\x22badge\x20bg-warning\x20text-dark\x22\x20style=\x22font-size:0.6rem\x22\x20id=\x22countdown_'+_0x4cc05e['id']+_0x1a1981(0x11d)+(_0x4cc05e[_0x1a1981(0x191)]||0x0)+_0x1a1981(0x141):'')+_0x1a1981(0x160)+_0x4cc05e['id']+'\x22\x20class=\x22d-flex\x20align-items-center\x20gap-1\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<code\x20class=\x22small\x22>'+_0x338c08+'</code>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+(_0x38457c?_0x1a1981(0x179):'')+_0x1a1981(0x1da)+_0x4cc05e['id']+_0x1a1981(0x25d)+(_0x4cc05e['proxy_host']||'')+_0x1a1981(0x1bc)+(_0x4cc05e[_0x1a1981(0x23e)]||'')+_0x1a1981(0x1bc)+(_0x4cc05e[_0x1a1981(0x1df)]||'')+_0x1a1981(0x1bc)+(_0x4cc05e[_0x1a1981(0x271)]||'')+'\x27)\x22\x20title=\x22Sửa\x20proxy\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<i\x20class=\x22bi\x20bi-pencil-square\x22\x20style=\x22font-size:0.7rem\x22></i>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20id=\x22proxyEdit_'+_0x4cc05e['id']+_0x1a1981(0x140)+_0x4cc05e['id']+'\x22\x20placeholder=\x22IP:PORT:USER:PASS\x22\x20style=\x22min-width:120px\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20class=\x22btn\x20btn-success\x20btn-sm\x22\x20onclick=\x22saveThreadProxy('+_0x4cc05e['id']+_0x1a1981(0x1b2)+_0x4cc05e['id']+_0x1a1981(0x155)+(_0x4cc05e[_0x1a1981(0x1d2)]||'')+'\x22>'+(_0x4cc05e[_0x1a1981(0x1d2)]||_0x1a1981(0x122))+_0x1a1981(0x1b9)+_0x5b83a7[_0x1a1981(0x1c4)]+_0x1a1981(0x261)+_0x5b83a7[_0x1a1981(0x1d6)]+_0x1a1981(0x21e)+_0x5b83a7[_0x1a1981(0x1d8)]+_0x1a1981(0x1e7)+(_0x47c844?_0x1a1981(0x196):_0x1a1981(0x15d))+_0x1a1981(0x12b)+_0x4cc05e['id']+_0x1a1981(0x1d1)+(_0x47c844?'Bắt\x20đầu':'Dừng')+_0x1a1981(0x261)+(_0x47c844?_0x1a1981(0x26e):_0x1a1981(0x25a))+_0x1a1981(0x22e)+_0x4cc05e['id']+_0x1a1981(0x24f)+_0x4cc05e['id']+_0x1a1981(0x170)+_0x4cc05e['id']+_0x1a1981(0x190)+_0x4cc05e['id']+_0x1a1981(0x22c);})[_0x3cca26(0x1ea)]('');const _0x537db0=document[_0x3cca26(0x1d3)](_0x3cca26(0x243)),_0x1fb8d1=document['querySelectorAll'](_0x3cca26(0x1db));_0x537db0[_0x3cca26(0x1ab)]=_0x1fb8d1[_0x3cca26(0x192)]>0x0&&Array[_0x3cca26(0x26c)](_0x1fb8d1)[_0x3cca26(0x12f)](_0x596960=>_0x577f82['includes'](_0x596960['dataset'][_0x3cca26(0x1c8)])),restoreAllCheck24h(),updateCountdowns();})[_0x43d9e6(0x21d)](_0x524d63=>console[_0x43d9e6(0x1d2)](_0x43d9e6(0x241),_0x524d63));}function toggleEditUsername(_0x596d05,_0x3a8ddd){const _0x53ccea=a0_0x25f3c7;document[_0x53ccea(0x1d3)](_0x53ccea(0x15b)+_0x596d05)[_0x53ccea(0x1c3)][_0x53ccea(0x148)](_0x53ccea(0x124)),document[_0x53ccea(0x1d3)]('usernameEdit_'+_0x596d05)[_0x53ccea(0x1c3)][_0x53ccea(0x217)](_0x53ccea(0x124)),document[_0x53ccea(0x1d3)](_0x53ccea(0x12c)+_0x596d05)[_0x53ccea(0x135)]=_0x3a8ddd,document[_0x53ccea(0x1d3)](_0x53ccea(0x12c)+_0x596d05)['focus']();}function cancelEditUsername(_0x423834){const _0x51a32e=a0_0x25f3c7;document[_0x51a32e(0x1d3)]('usernameDisplay_'+_0x423834)[_0x51a32e(0x1c3)]['remove'](_0x51a32e(0x124)),document[_0x51a32e(0x1d3)](_0x51a32e(0x11f)+_0x423834)[_0x51a32e(0x1c3)]['add'](_0x51a32e(0x124));}function saveThreadUsername(_0x3c329b){const _0x3151e8=a0_0x25f3c7,_0x3738c4=document[_0x3151e8(0x1d3)]('usernameInput_'+_0x3c329b)[_0x3151e8(0x135)][_0x3151e8(0x1ae)]();if(!_0x3738c4){showToast(_0x3151e8(0x1e6),_0x3151e8(0x1d2));return;}fetch(_0x3151e8(0x200)+_0x3c329b,{'method':_0x3151e8(0x119),'headers':{'Content-Type':'application/json'},'body':JSON[_0x3151e8(0x20f)]({'username':_0x3738c4})})[_0x3151e8(0x232)](_0x58d53a=>_0x58d53a[_0x3151e8(0x1a0)]())[_0x3151e8(0x232)](_0x192021=>{const _0xcce906=_0x3151e8;_0x192021[_0xcce906(0x127)]?(showToast('Cập\x20nhật\x20username\x20thành\x20công',_0xcce906(0x127)),loadThreads(),loadUsers()):showToast(_0x192021[_0xcce906(0x1b6)]||_0xcce906(0x1a3),_0xcce906(0x1d2));})[_0x3151e8(0x21d)](()=>showToast(_0x3151e8(0x1a3),_0x3151e8(0x1d2)));}function toggleEditUploaded(_0x341f9a,_0x2cb5f5){const _0x11c4ac=a0_0x25f3c7;document[_0x11c4ac(0x1d3)](_0x11c4ac(0x214)+_0x341f9a)[_0x11c4ac(0x1c3)][_0x11c4ac(0x148)](_0x11c4ac(0x124)),document[_0x11c4ac(0x1d3)](_0x11c4ac(0x14f)+_0x341f9a)['classList'][_0x11c4ac(0x217)]('d-none'),document[_0x11c4ac(0x1d3)]('uploadedInput_'+_0x341f9a)[_0x11c4ac(0x135)]=_0x2cb5f5,document['getElementById'](_0x11c4ac(0x267)+_0x341f9a)[_0x11c4ac(0x1d7)]();}function cancelEditUploaded(_0x234955){const _0xbb8462=a0_0x25f3c7;document[_0xbb8462(0x1d3)](_0xbb8462(0x214)+_0x234955)[_0xbb8462(0x1c3)][_0xbb8462(0x217)](_0xbb8462(0x124)),document[_0xbb8462(0x1d3)](_0xbb8462(0x14f)+_0x234955)[_0xbb8462(0x1c3)][_0xbb8462(0x148)](_0xbb8462(0x124));}function saveThreadUploaded(_0x3b0adb){const _0x3c1b77=a0_0x25f3c7,_0x435136=parseInt(document['getElementById'](_0x3c1b77(0x267)+_0x3b0adb)[_0x3c1b77(0x135)],0xa);if(isNaN(_0x435136)||_0x435136<0x0){showToast(_0x3c1b77(0x121),_0x3c1b77(0x1d2));return;}fetch('/api/threads/'+_0x3b0adb+_0x3c1b77(0x153),{'method':'PUT','headers':{'Content-Type':_0x3c1b77(0x157)},'body':JSON['stringify']({'videos_uploaded':_0x435136})})['then'](_0x440af6=>_0x440af6['json']())[_0x3c1b77(0x232)](_0x32fd5a=>{const _0x57fa6b=_0x3c1b77;_0x32fd5a[_0x57fa6b(0x127)]?(showToast('Đã\x20cập\x20nhật\x20uploaded\x20=\x20'+_0x435136,_0x57fa6b(0x127)),loadThreads()):showToast(_0x32fd5a['error']||'Lỗi\x20cập\x20nhật',_0x57fa6b(0x1d2));})[_0x3c1b77(0x21d)](()=>showToast('Lỗi\x20cập\x20nhật','error'));}function toggleEditCountry(_0x48d715,_0xa1676a){const _0x177a8d=a0_0x25f3c7;document['getElementById']('countryDisplay_'+_0x48d715)[_0x177a8d(0x1c3)]['add'](_0x177a8d(0x124)),document['getElementById']('countryEdit_'+_0x48d715)['classList']['remove'](_0x177a8d(0x124));const _0x428f67=document[_0x177a8d(0x1d3)](_0x177a8d(0x277)+_0x48d715);if(_0x428f67)_0x428f67[_0x177a8d(0x135)]=_0xa1676a||'vn';}function cancelEditCountry(_0x13e3f3){const _0x3944c7=a0_0x25f3c7;document['getElementById']('countryDisplay_'+_0x13e3f3)[_0x3944c7(0x1c3)][_0x3944c7(0x217)](_0x3944c7(0x124)),document[_0x3944c7(0x1d3)]('countryEdit_'+_0x13e3f3)[_0x3944c7(0x1c3)]['add'](_0x3944c7(0x124));}function saveThreadCountry(_0x1a832a){const _0x34f42b=a0_0x25f3c7,_0x3d2bcb=document[_0x34f42b(0x1d3)](_0x34f42b(0x277)+_0x1a832a)[_0x34f42b(0x135)];fetch('/api/threads/'+_0x1a832a+_0x34f42b(0x1e4),{'method':_0x34f42b(0x119),'headers':{'Content-Type':_0x34f42b(0x157)},'body':JSON[_0x34f42b(0x20f)]({'country':_0x3d2bcb})})[_0x34f42b(0x232)](_0x550b25=>_0x550b25[_0x34f42b(0x1a0)]())[_0x34f42b(0x232)](_0x553ee4=>{const _0x7d9422=_0x34f42b;_0x553ee4[_0x7d9422(0x127)]?(showToast('Cập\x20nhật\x20quốc\x20gia\x20thành\x20công',_0x7d9422(0x127)),loadThreads()):showToast(_0x553ee4['error']||_0x7d9422(0x216),_0x7d9422(0x1d2));})[_0x34f42b(0x21d)](()=>showToast(_0x34f42b(0x216),'error'));}function toggleEditProxy(_0x564739,_0x91eb56,_0x38d492,_0x8ff50c,_0x1dab20){const _0xbe7a28=a0_0x25f3c7;document[_0xbe7a28(0x1d3)]('proxyDisplay_'+_0x564739)[_0xbe7a28(0x1c3)][_0xbe7a28(0x148)]('d-none'),document['getElementById'](_0xbe7a28(0x133)+_0x564739)[_0xbe7a28(0x1c3)][_0xbe7a28(0x217)]('d-none');const _0x3e0de8=document[_0xbe7a28(0x1d3)](_0xbe7a28(0x1fc)+_0x564739);if(_0x91eb56&&_0x38d492){let _0x1e9514=_0x91eb56+':'+_0x38d492;if(_0x8ff50c&&_0x1dab20)_0x1e9514+=':'+_0x8ff50c+':'+_0x1dab20;_0x3e0de8[_0xbe7a28(0x135)]=_0x1e9514;}else _0x3e0de8[_0xbe7a28(0x135)]='';_0x3e0de8['focus']();}function cancelEditProxy(_0x39d15d){const _0x48e46e=a0_0x25f3c7;document['getElementById'](_0x48e46e(0x142)+_0x39d15d)[_0x48e46e(0x1c3)][_0x48e46e(0x217)](_0x48e46e(0x124)),document['getElementById'](_0x48e46e(0x133)+_0x39d15d)['classList'][_0x48e46e(0x148)]('d-none');}function saveThreadProxy(_0x1127e7){const _0x5114f6=a0_0x25f3c7,_0x53609e=document[_0x5114f6(0x1d3)]('proxyInput_'+_0x1127e7)[_0x5114f6(0x135)][_0x5114f6(0x1ae)]();fetch(_0x5114f6(0x12a)+_0x1127e7+_0x5114f6(0x168),{'method':_0x5114f6(0x119),'headers':{'Content-Type':_0x5114f6(0x157)},'body':JSON['stringify']({'proxy':_0x53609e})})[_0x5114f6(0x232)](_0x125839=>_0x125839['json']())[_0x5114f6(0x232)](_0x27b32c=>{const _0x166de7=_0x5114f6;_0x27b32c[_0x166de7(0x127)]?(showToast(_0x166de7(0x266),_0x166de7(0x127)),loadThreads()):showToast(_0x27b32c[_0x166de7(0x1d2)]||'Lỗi\x20cập\x20nhật\x20proxy',_0x166de7(0x1d2));})[_0x5114f6(0x21d)](()=>showToast(_0x5114f6(0x248),'error'));}function deleteThread(_0x3fbcbb){const _0x245503=a0_0x25f3c7;confirm(_0x245503(0x117))&&fetch(_0x245503(0x12a)+_0x3fbcbb,{'method':_0x245503(0x19e)})['then'](_0x4616de=>_0x4616de[_0x245503(0x1a0)]())['then'](_0x1c82a6=>{const _0x4caa8c=_0x245503;loadUsers(),loadThreads(),showToast(_0x4caa8c(0x21c),'success');})[_0x245503(0x21d)](_0x281584=>{const _0x2b053e=_0x245503;console[_0x2b053e(0x1d2)]('Error:',_0x281584),showToast(_0x2b053e(0x211),_0x2b053e(0x1d2));});}function toggleThreadStatus(_0x12fc2c){const _0x3ac4ef=a0_0x25f3c7;fetch(_0x3ac4ef(0x12a)+_0x12fc2c+_0x3ac4ef(0x23f),{'method':_0x3ac4ef(0x119)})[_0x3ac4ef(0x232)](_0x3a3ae1=>_0x3a3ae1[_0x3ac4ef(0x1a0)]())[_0x3ac4ef(0x232)](_0x30b909=>{const _0x2f5195=_0x3ac4ef;loadUsers(),loadThreads(),showToast(_0x2f5195(0x22a),'success');})[_0x3ac4ef(0x21d)](_0x2ac130=>{const _0x34f967=_0x3ac4ef;console[_0x34f967(0x1d2)](_0x34f967(0x241),_0x2ac130),showToast(_0x34f967(0x276),'error');});}function toggleAllThreads(_0x4526d6){const _0x2d1893=a0_0x25f3c7,_0x4f7e2e=document[_0x2d1893(0x18d)](_0x2d1893(0x1db));_0x4f7e2e[_0x2d1893(0x23b)](_0x539088=>{const _0x500624=_0x2d1893;_0x539088[_0x500624(0x1ab)]=_0x4526d6[_0x500624(0x1ab)];});}function startSelectedThreads(){const _0x16ed89=a0_0x25f3c7,_0x25b8b6=Array[_0x16ed89(0x26c)](document[_0x16ed89(0x18d)](_0x16ed89(0x21a)))['filter'](_0x38dad3=>_0x38dad3[_0x16ed89(0x1c2)][_0x16ed89(0x24c)]!==_0x16ed89(0x1af))[_0x16ed89(0x188)](_0x20d3a5=>_0x20d3a5[_0x16ed89(0x1c2)]['threadId'])[_0x16ed89(0x173)](_0x436873=>_0x436873!==undefined);if(_0x25b8b6[_0x16ed89(0x192)]===0x0){showToast(_0x16ed89(0x156),_0x16ed89(0x183));return;}Promise[_0x16ed89(0x13e)](_0x25b8b6['map'](_0x58460c=>fetch(_0x16ed89(0x12a)+_0x58460c+_0x16ed89(0x23f),{'method':_0x16ed89(0x119)})[_0x16ed89(0x232)](_0x46aec1=>_0x46aec1[_0x16ed89(0x1a0)]())))['then'](()=>{const _0xf3a34=_0x16ed89;loadUsers(),loadThreads(),showToast('Các\x20luồng\x20đã\x20chọn\x20được\x20bắt\x20đầu\x20thành\x20công',_0xf3a34(0x127)),document[_0xf3a34(0x1d3)](_0xf3a34(0x243))[_0xf3a34(0x1ab)]=![];})[_0x16ed89(0x21d)](_0x164731=>{const _0xab6908=_0x16ed89;console[_0xab6908(0x1d2)]('Error:',_0x164731),showToast(_0xab6908(0x1d5),_0xab6908(0x1d2));});}function pauseSelectedThreads(){const _0x7ab927=a0_0x25f3c7,_0x4068db=Array[_0x7ab927(0x26c)](document[_0x7ab927(0x18d)](_0x7ab927(0x21a)))[_0x7ab927(0x173)](_0x2add3a=>_0x2add3a['dataset']['threadStatus']===_0x7ab927(0x1af))[_0x7ab927(0x188)](_0x135dc1=>_0x135dc1['dataset'][_0x7ab927(0x1c8)])[_0x7ab927(0x173)](_0x3f1811=>_0x3f1811!==undefined);if(_0x4068db[_0x7ab927(0x192)]===0x0){showToast(_0x7ab927(0x23c),_0x7ab927(0x183));return;}Promise[_0x7ab927(0x13e)](_0x4068db[_0x7ab927(0x188)](_0x29c5f8=>fetch(_0x7ab927(0x12a)+_0x29c5f8+_0x7ab927(0x23f),{'method':_0x7ab927(0x119)})[_0x7ab927(0x232)](_0x29d10b=>_0x29d10b['json']())))['then'](()=>{const _0x12821f=_0x7ab927;loadUsers(),loadThreads(),showToast(_0x12821f(0x1ce),_0x12821f(0x127)),document[_0x12821f(0x1d3)](_0x12821f(0x243))[_0x12821f(0x1ab)]=![];})[_0x7ab927(0x21d)](_0x2b3344=>{const _0x43ad80=_0x7ab927;console[_0x43ad80(0x1d2)](_0x43ad80(0x241),_0x2b3344),showToast(_0x43ad80(0x1ee),'error');});}function deleteSelectedThreads(){const _0x388e3b=a0_0x25f3c7,_0x4263cf=Array[_0x388e3b(0x26c)](document['querySelectorAll'](_0x388e3b(0x21a)))[_0x388e3b(0x188)](_0x2af7c6=>_0x2af7c6[_0x388e3b(0x1c2)][_0x388e3b(0x1c8)])['filter'](_0x994cbc=>_0x994cbc!==undefined);if(_0x4263cf[_0x388e3b(0x192)]===0x0){showToast('Vui\x20lòng\x20chọn\x20ít\x20nhất\x20một\x20luồng\x20để\x20xóa',_0x388e3b(0x183));return;}confirm(_0x388e3b(0x1f2))&&Promise[_0x388e3b(0x13e)](_0x4263cf[_0x388e3b(0x188)](_0x453d61=>fetch(_0x388e3b(0x12a)+_0x453d61,{'method':_0x388e3b(0x19e)})['then'](_0x11b8d6=>_0x11b8d6[_0x388e3b(0x1a0)]())))[_0x388e3b(0x232)](()=>{const _0x58a785=_0x388e3b;loadUsers(),loadThreads(),showToast('Các\x20luồng\x20đã\x20chọn\x20được\x20xóa\x20thành\x20công',_0x58a785(0x127)),document['getElementById']('selectAllThreads')[_0x58a785(0x1ab)]=![];})['catch'](_0x4d0adb=>{const _0x25a517=_0x388e3b;console[_0x25a517(0x1d2)](_0x25a517(0x241),_0x4d0adb),showToast(_0x25a517(0x1c6),_0x25a517(0x1d2));});}function showThreadTasks(_0x32438a,_0x2412fe){const _0x5de60f=a0_0x25f3c7;fetch(_0x5de60f(0x1ac)+_0x32438a)[_0x5de60f(0x232)](_0x1becd8=>_0x1becd8[_0x5de60f(0x1a0)]())['then'](_0x22069a=>{const _0x2a621d=_0x5de60f,_0x8e02ac={'pending':'⏳','uploading':'🔄','completed':'✅','failed':'❌'},_0x44295f=_0x22069a['map']((_0x20c553,_0x1e6cb6)=>_0x2a621d(0x236)+(_0x20c553[_0x2a621d(0x1cf)]===_0x2a621d(0x16b)?_0x2a621d(0x1e5):_0x20c553[_0x2a621d(0x1cf)]==='completed'?'table-success':'')+_0x2a621d(0x235)+(_0x1e6cb6+0x1)+'</td>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<td\x20class=\x22small\x22>'+_0x20c553[_0x2a621d(0x16d)]+_0x2a621d(0x1f9)+(_0x20c553[_0x2a621d(0x14c)]||'')[_0x2a621d(0x1b4)](/"/g,_0x2a621d(0x145))+'\x22>'+(_0x20c553[_0x2a621d(0x14c)]||'-')[_0x2a621d(0x116)](0x0,0x3c)+((_0x20c553[_0x2a621d(0x14c)]||'')[_0x2a621d(0x192)]>0x3c?_0x2a621d(0x1a6):'')+'</td>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<td\x20class=\x22small\x22>'+(_0x20c553[_0x2a621d(0x239)]?JSON['parse'](typeof _0x20c553[_0x2a621d(0x239)]===_0x2a621d(0x1fd)?_0x20c553[_0x2a621d(0x239)]:'[]')['length']:0x0)+_0x2a621d(0x1c9)+(_0x8e02ac[_0x20c553[_0x2a621d(0x1cf)]]||'')+_0x2a621d(0x120)+_0x20c553[_0x2a621d(0x1cf)]+'</small></td>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<td\x20class=\x22small\x20text-danger\x22\x20style=\x22max-width:200px;\x22\x20title=\x22'+(_0x20c553[_0x2a621d(0x1d2)]||'')[_0x2a621d(0x1b4)](/"/g,'&quot;')+'\x22>'+(_0x20c553[_0x2a621d(0x1d2)]?_0x20c553[_0x2a621d(0x1d2)]['substring'](0x0,0x32)+_0x2a621d(0x1a6):'-')+_0x2a621d(0x207)+(_0x20c553[_0x2a621d(0x162)]?'<a\x20href=\x22'+_0x20c553[_0x2a621d(0x162)]+_0x2a621d(0x272):'-')+_0x2a621d(0x18f))[_0x2a621d(0x1ea)](''),_0x5f4144=_0x2a621d(0x259)+_0x2412fe+'\x20('+_0x22069a[_0x2a621d(0x192)]+_0x2a621d(0x1fb)+_0x44295f+_0x2a621d(0x138);document[_0x2a621d(0x1d3)](_0x2a621d(0x263))?.[_0x2a621d(0x217)](),document['body'][_0x2a621d(0x178)](_0x2a621d(0x268),_0x5f4144),new bootstrap[(_0x2a621d(0x18c))](document[_0x2a621d(0x1d3)](_0x2a621d(0x263)))[_0x2a621d(0x210)]();})[_0x5de60f(0x21d)](()=>showToast(_0x5de60f(0x1c5),_0x5de60f(0x1d2)));}function scanVideoFolder(){const _0x470a1c=a0_0x25f3c7,_0x302c5f=document[_0x470a1c(0x1d3)](_0x470a1c(0x230))?.['value']?.[_0x470a1c(0x1ae)](),_0x468d99=document[_0x470a1c(0x1d3)](_0x470a1c(0x194));if(!_0x302c5f){showToast(_0x470a1c(0x163),_0x470a1c(0x183));return;}_0x468d99[_0x470a1c(0x18a)]=_0x470a1c(0x1e8),fetch(_0x470a1c(0x180),{'method':_0x470a1c(0x1ed),'headers':{'Content-Type':_0x470a1c(0x157)},'body':JSON[_0x470a1c(0x20f)]({'folderPath':_0x302c5f})})['then'](_0x5de601=>_0x5de601[_0x470a1c(0x1a0)]())[_0x470a1c(0x232)](_0x47225c=>{const _0x448a90=_0x470a1c;_0x47225c[_0x448a90(0x127)]?_0x468d99[_0x448a90(0x18a)]='<span\x20class=\x22badge\x20bg-success\x22>'+_0x47225c[_0x448a90(0x1a9)]+_0x448a90(0x1b5)+_0x47225c[_0x448a90(0x1f0)]+_0x448a90(0x1f5):_0x468d99[_0x448a90(0x18a)]=_0x448a90(0x26f)+_0x47225c['error']+_0x448a90(0x12d);})['catch'](()=>{const _0x801e46=_0x470a1c;_0x468d99[_0x801e46(0x18a)]='<span\x20class=\x22badge\x20bg-danger\x22>Lỗi\x20kết\x20nối</span>';});}function showImportExcelModal(){const _0xc3ea8a=a0_0x25f3c7,_0x333daf=new bootstrap['Modal'](document[_0xc3ea8a(0x1d3)](_0xc3ea8a(0x14b))),_0x10726e=document[_0xc3ea8a(0x1d3)]('importResultSection');if(_0x10726e)_0x10726e[_0xc3ea8a(0x1f1)]['display']=_0xc3ea8a(0x26a);const _0x21b26b=document['getElementById'](_0xc3ea8a(0x19b));if(_0x21b26b)_0x21b26b[_0xc3ea8a(0x1cb)]();const _0x254355=document[_0xc3ea8a(0x1d3)](_0xc3ea8a(0x206));_0x254355&&(_0x254355['disabled']=![],_0x254355[_0xc3ea8a(0x18a)]=_0xc3ea8a(0x228));const _0x50be06=document[_0xc3ea8a(0x1d3)]('videoFolderInfo');if(_0x50be06)_0x50be06[_0xc3ea8a(0x18a)]='';_0x333daf[_0xc3ea8a(0x210)]();}function a0_0x5428(){const _0x4d5a2d=['hạn\x20chế','fontSize','/api/videos/tasks/retry','</td>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<td\x20class=\x22small\x22\x20style=\x22max-width:250px;word-break:break-all;\x22\x20title=\x22','toLowerCase','\x20video)</h6>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20type=\x22button\x22\x20class=\x22btn-close\x22\x20data-bs-dismiss=\x22modal\x22></button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22modal-body\x20p-0\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22table-responsive\x22\x20style=\x22max-height:500px;\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<table\x20class=\x22table\x20table-sm\x20table-hover\x20mb-0\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<thead\x20class=\x22table-light\x20sticky-top\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<tr><th>#</th><th>Video</th><th>Caption</th><th>SP</th><th>Trạng\x20thái</th><th>Lỗi</th><th>Link</th></tr>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</thead>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<tbody>','proxyInput_','string','Xoá\x20tất\x20cả\x20tasks?\x20(không\x20ảnh\x20hưởng\x20luồng)','Lỗi\x20khi\x20tạo\x20luồng','/api/users/','check24hResult_','🇮🇩','badge\x20bg-success','Lỗi\x20khi\x20cập\x20nhật\x20thời\x20gian','videoFilesInFolder','importExcelSubmitBtn','</td>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<td\x20class=\x22small\x22>','/api/config/running-time-again','137977knUBTv','count','socks4://','</div>','\x27);\x20return\x20false;\x22\x20title=\x22Xem\x20danh\x20sách\x20video\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<i\x20class=\x22bi\x20bi-list-ul\x20me-1\x22></i>','\x20<span\x20class=\x22badge\x20bg-success\x22\x20style=\x22font-size:0.6rem\x22>+SP</span>','stringify','show','Lỗi\x20khi\x20xóa\x20luồng','<div\x20class=\x22alert\x20alert-info\x20py-2\x20small\x20mb-2\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<strong>Luồng:</strong>\x20','code','uploadedDisplay_','\x20video\x20files\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<br><strong>Sản\x20phẩm:</strong>\x20','Lỗi\x20cập\x20nhật\x20quốc\x20gia','remove','editThreadUserCookieModal','finally','.thread-checkbox:checked','importResultContent','Xóa\x20luồng\x20thành\x20công','catch','\x20me-1\x22></i>','done','Vui\x20lòng\x20chọn\x20người\x20dùng','socks5h://','Đang\x20check\x20','\x20không\x20SP\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>','submit','false','append','user_proxy','<i\x20class=\x22bi\x20bi-upload\x20me-1\x22></i>Nhập\x20&\x20Tạo\x20Luồng','row','Trạng\x20thái\x20luồng\x20được\x20cập\x20nhật\x20thành\x20công','preventDefault',')\x22\x20title=\x22Xóa\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<i\x20class=\x22bi\x20bi-trash3\x22></i>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</td>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</tr>','threadsCreated','\x22></i>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20class=\x22btn\x20btn-sm\x20btn-outline-info\x22\x20onclick=\x22check24h(','</code>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20class=\x22btn\x20btn-sm\x20p-0\x20text-primary\x22\x20onclick=\x22editThreadUserCookieForm(','videoFolderInput','Lỗi','then','\x20tasks\x20lỗi','Malaysia','\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<td\x20class=\x22small\x22>','\x0a\x20\x20\x20\x20\x20\x20\x20\x20<tr\x20class=\x22','Thailand','bg-success','products','ban','forEach','Vui\x20lòng\x20chọn\x20ít\x20nhất\x20một\x20luồng\x20để\x20tạm\x20dừng','videos_uploaded','proxy_port','/toggle-status','Sẵn\x20sàng','Error:','8tMSqKn','selectAllThreads','<tr\x20class=\x22table-danger\x22><td>','Brazil','delay_max','className','Lỗi\x20cập\x20nhật\x20proxy','country','userSelectForThread','\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22alert\x20','threadStatus','</td>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<td>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20id=\x22usernameDisplay_','\x27)\x22\x20title=\x22Đổi\x20nước\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<i\x20class=\x22bi\x20bi-pencil-square\x22\x20style=\x22font-size:0.7rem\x22></i>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20id=\x22countryEdit_',')\x22\x20title=\x22Check\x20video\x2024h\x22\x20id=\x22check24hBtn_','\x20|\x20<span\x20class=\x22badge\x20bg-success\x22>Đang\x20chạy</span>','🇻🇳','bg-danger','259541qUdJfb','editThreadUsernameInput','\x20py-2\x20small\x20mb-2\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<strong>Tasks:</strong>\x20','next','auto','alert-warning','\x0a\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22modal\x20fade\x22\x20id=\x22taskListModal\x22\x20tabindex=\x22-1\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22modal-dialog\x20modal-xl\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22modal-content\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22modal-header\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<h6\x20class=\x22modal-title\x22><i\x20class=\x22bi\x20bi-list-ul\x20me-2\x22></i>Tasks:\x20','bi-pause-fill','Đã\x20xoá\x20tất\x20cả\x20tasks','Dừng',',\x20\x27','bi-check-circle','title','Modal\x20element\x20not\x20found','\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<i\x20class=\x22bi\x20','entries','taskListModal','excelFileInput','[id^=\x22countdown_\x22]','Cập\x20nhật\x20proxy\x20thành\x20công','uploadedInput_','beforeend','bg-primary','none','</option>','from','🇲🇾','bi-play-fill','<span\x20class=\x22badge\x20bg-danger\x22>','<details\x20class=\x22small\x20mb-1\x22><summary\x20class=\x22text-danger\x20fw-semibold\x22>Chi\x20tiết\x20loại\x20bỏ\x20(','proxy_password','\x22\x20target=\x22_blank\x22>Link</a>','s</small>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20','withProducts','excelDelayMin','Lỗi\x20khi\x20cập\x20nhật\x20trạng\x20thái\x20luồng','countryInput_','info','auto_fill_products','/check-24h','check24hBtn_','runningTimeAgain','startsWith','substring','Bạn\x20có\x20chắc\x20chắn\x20muốn\x20xóa\x20luồng\x20này\x20không?','addEventListener','PUT','runningTimeAgainInput','Error\x20loading\x20running\x20time:','proxy_host','\x22\x20data-next=\x22','180','usernameEdit_','\x20<small>','Số\x20không\x20hợp\x20lệ','<span\x20class=\x22text-muted\x22>-</span>','editThreadUserCookieInput','d-none','resolve','excelDriveLink','success','<option\x20value=\x22','toUpperCase','/api/threads/','\x22\x20onclick=\x22toggleThreadStatus(','usernameInput_','</span>','excelDelayMax','every','withoutProducts','Đang\x20chạy','proxyInputForThread','proxyEdit_','createThreadModal','value','</span></td>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<td>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<small>','<span\x20class=\x22spinner-border\x20spinner-border-sm\x20me-1\x22></span>Đang\x20xử\x20lý...','</tbody>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</table>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20</div>',':***','\x22\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20id=\x22threadCheckbox','Chọn\x20file\x20Excel\x20hoặc\x20nhập\x20link\x20Google\x20Drive','\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20','delayMax','all','bg-warning\x20text-dark','\x22\x20class=\x22d-none\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22input-group\x20input-group-sm\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<input\x20type=\x22text\x22\x20class=\x22form-control\x20form-control-sm\x22\x20id=\x22proxyInput_','\x22></span>','proxyDisplay_','floor','\x22\x20style=\x22min-width:80px\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20','&quot;','invalid','getInstance','add',')\x22><i\x20class=\x22bi\x20bi-x\x22></i></button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</td>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<td>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<a\x20href=\x22#\x22\x20class=\x22text-decoration-none\x20small\x22\x20onclick=\x22showThreadTasks(','<div\x20class=\x22alert\x20alert-danger\x20py-2\x20small\x20mb-0\x22>','importVideoModal','caption','>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</td>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<td\x20class=\x22text-muted\x22>','Nhập\x20đường\x20dẫn\x20folder\x20video','uploadedEdit_','count_video_upload','now','delayMin','/videos-uploaded','countVideoUploadInput',')\x22><i\x20class=\x22bi\x20bi-x\x22></i></button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</td>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<td\x20class=\x22log-error-cell\x22\x20title=\x22','Vui\x20lòng\x20chọn\x20ít\x20nhất\x20một\x20luồng\x20để\x20bắt\x20đầu','application/json','/api/videos/tasks','includes','countrySelectForThread','usernameDisplay_','213309QaUEoq','btn-warning','co.th','\x22\x20class=\x22d-flex\x20align-items-center\x20gap-1\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22badge\x20bg-light\x20text-dark\x20border\x22\x20title=\x22','\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</td>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<td>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20id=\x22proxyDisplay_','com.br','video_link','Nhập\x20đường\x20dẫn\x20folder','\x22\x20class=\x22d-flex\x20align-items-center\x20gap-1\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<strong>','</small>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</td>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<td><span\x20class=\x22badge\x20','Nhập\x20','\x22\x20class=\x22d-none\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22input-group\x20input-group-sm\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<input\x20type=\x22text\x22\x20class=\x22form-control\x20form-control-sm\x22\x20value=\x22','/proxy','\x20|\x20<span\x20class=\x22text-danger\x22>Loại\x20bỏ:\x20','toString','failed','threadsExisted','video_filename','find','613420tqYQOY','\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<i\x20class=\x22bi\x20bi-clock-history\x22></i>\x20<span\x20id=\x22check24hResult_','0.6rem','\x20video\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</a>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</td>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<td>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<strong>','filter','53466Ocfbeg','alert-success','disabled','\x22\x20style=\x22min-width:70px\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20class=\x22btn\x20btn-success\x20btn-sm\x22\x20onclick=\x22saveThreadUsername(','insertAdjacentHTML','<span\x20class=\x22badge\x20bg-info\x20text-dark\x22\x20style=\x22font-size:0.55rem\x22\x20title=\x22Proxy\x20thừa\x20hưởng\x20từ\x20user\x22>↪user</span>','bi-stop-circle','slice','account','driveLink','\x27)\x22\x20title=\x22Sửa\x20cookie\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<i\x20class=\x22bi\x20bi-pencil-square\x22\x20style=\x22font-size:0.7rem\x22></i>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</td>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<td>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20id=\x22countryDisplay_','textContent','/api/videos/scan-folder','badge\x20bg-warning\x20text-dark','imported','warning','</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20class=\x22btn\x20btn-sm\x20p-0\x20text-primary\x22\x20onclick=\x22toggleEditCountry(','btn-outline-info','selected','<div\x20class=\x22small\x20text-muted\x20mb-2\x22>Cột\x20nhận\x20diện:\x20','map','Luồng\x20được\x20tạo\x20thành\x20công','innerHTML','\x22\x20class=\x22d-none\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22input-group\x20input-group-sm\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<select\x20class=\x22form-select\x20form-select-sm\x22\x20id=\x22countryInput_','Modal','querySelectorAll','\x20có\x20SP\x20|\x20','</td>\x0a\x20\x20\x20\x20\x20\x20\x20\x20</tr>\x0a\x20\x20\x20\x20\x20\x20','\x22></span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20class=\x22btn\x20btn-sm\x20btn-outline-danger\x22\x20onclick=\x22deleteThread(','next_run_at','length','captionInputForThread','videoFolderInfo','count24h','btn-success','300020Asnric','110838BhOuZD','bi-x-circle','delay_min','importExcelForm','username','\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<tr>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<td>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22form-check\x20form-switch\x20mb-0\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<input\x20type=\x22checkbox\x22\x20class=\x22form-check-input\x20thread-checkbox\x22\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20data-thread-id=\x22','DELETE','colMap','json','btn\x20btn-sm\x20','\x20luồng...','Lỗi\x20cập\x20nhật\x20username','Lỗi\x20retry','Indonesia','...','summary','/api/threads','videoCount','🇵🇭','checked','/api/videos/tasks?userId=','canPost','trim','inprogress','</strong><small\x20class=\x22text-muted\x22>/',')\x22><i\x20class=\x22bi\x20bi-check\x22></i></button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20class=\x22btn\x20btn-secondary\x20btn-sm\x22\x20onclick=\x22cancelEditCountry(',')\x22><i\x20class=\x22bi\x20bi-check\x22></i></button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20class=\x22btn\x20btn-secondary\x20btn-sm\x22\x20onclick=\x22cancelEditProxy(','\x20OK\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20','replace','\x20video</span>\x20<span\x20class=\x22text-muted\x20small\x22>/\x20','message','user_id','\x20|\x20','</td>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<td>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22badge\x20','hide','Chọn\x20ít\x20nhất\x201\x20luồng\x20để\x20check','\x27,\x20\x27','banned','stop','importResultSection','flag','\x20video\x20trong\x2024h','dataset','classList','badge','Lỗi\x20tải\x20danh\x20sách\x20tasks','Lỗi\x20khi\x20xóa\x20các\x20luồng','Singapore','threadId','\x20SP</td>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<td>','video','reset','Lỗi\x20khi\x20cập\x20nhật\x20cookie','userName','Các\x20luồng\x20đã\x20chọn\x20được\x20tạm\x20dừng\x20thành\x20công','status','http://',')\x22\x20title=\x22','error','getElementById','autoFillProductsCheckbox','Lỗi\x20khi\x20bắt\x20đầu\x20các\x20luồng','icon','focus','label','\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>','\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20class=\x22btn\x20btn-sm\x20p-0\x20text-primary\x22\x20onclick=\x22toggleEditProxy(','.thread-checkbox:not(:disabled)','editThreadUserIdInput','🇹🇭','Lỗi\x20kết\x20nối','proxy_username','/BAN','Cập\x20nhật\x20thời\x20gian\x20chạy\x20lại\x20thành\x20công','</strong>','excelAutoStart','/country','table-danger','Username\x20không\x20được\x20để\x20trống','\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</td>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<td\x20class=\x22text-nowrap\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20class=\x22btn\x20btn-sm\x20','<span\x20class=\x22spinner-border\x20spinner-border-sm\x20me-1\x22></span>Đang\x20scan...','btn\x20btn-sm\x20btn-dark','join','socks5://','</td><td>','POST','Lỗi\x20khi\x20tạm\x20dừng\x20các\x20luồng','khóa','total','style','Bạn\x20có\x20chắc\x20chắn\x20muốn\x20xóa\x20các\x20luồng\x20đã\x20chọn\x20không?','files','<i\x20class=\x22bi\x20bi-check-lg\x20me-1\x22></i>Đã\x20nhập\x20xong','\x20files\x20trong\x20folder</span>'];a0_0x5428=function(){return _0x4d5a2d;};return a0_0x5428();}function retryFailedTasks(){const _0x175ff9=a0_0x25f3c7;fetch(_0x175ff9(0x1f8),{'method':_0x175ff9(0x1ed)})[_0x175ff9(0x232)](_0x1fe3a9=>_0x1fe3a9[_0x175ff9(0x1a0)]())[_0x175ff9(0x232)](_0x4e2ac6=>{const _0x84f5b1=_0x175ff9;_0x4e2ac6[_0x84f5b1(0x127)]?(showToast('Đã\x20retry\x20'+_0x4e2ac6[_0x84f5b1(0x20a)]+_0x84f5b1(0x233),_0x84f5b1(0x127)),updateTaskStats()):showToast(_0x4e2ac6[_0x84f5b1(0x1d2)]||_0x84f5b1(0x1a4),'error');})[_0x175ff9(0x21d)](()=>showToast(_0x175ff9(0x1de),'error'));}function removeAllTasks(){const _0x1366f7=a0_0x25f3c7;confirm(_0x1366f7(0x1fe))&&fetch(_0x1366f7(0x158),{'method':_0x1366f7(0x19e)})['then'](_0x2b16ae=>_0x2b16ae[_0x1366f7(0x1a0)]())['then'](_0x40c79a=>{const _0x1bd4a1=_0x1366f7;_0x40c79a[_0x1bd4a1(0x127)]&&(showToast(_0x1bd4a1(0x25b),_0x1bd4a1(0x127)),updateTaskStats());})[_0x1366f7(0x21d)](()=>showToast(_0x1366f7(0x1de),_0x1366f7(0x1d2)));}function _noop(){return;}function loadImportBlacklist(){_noop();}function a0_0x4f86(_0x4a366c,_0x3e92c3){const _0x5428d9=a0_0x5428();return a0_0x4f86=function(_0x4f86fa,_0x4e4bff){_0x4f86fa=_0x4f86fa-0x112;let _0x3aa5a8=_0x5428d9[_0x4f86fa];return _0x3aa5a8;},a0_0x4f86(_0x4a366c,_0x3e92c3);}function updateImportBlacklistCount(){_noop();}function saveImportBlacklist(){const _0x208a7a=a0_0x25f3c7;return Promise[_0x208a7a(0x125)]();}function loadUsersForAssignment(){return Promise['resolve']([]);}function renderFileAssignmentTable(){_noop();}function getFileAssignments(){return{};}function editThreadUserCookieForm(_0x4339f7,_0x2c79b0){const _0x641816=a0_0x25f3c7,_0x254cd1=document['getElementById']('editThreadUserCookieModal');if(!_0x254cd1){console[_0x641816(0x1d2)](_0x641816(0x260));return;}const _0x1c0ae1=new bootstrap[(_0x641816(0x18c))](_0x254cd1,{'backdrop':!![],'keyboard':!![]});document[_0x641816(0x1d3)](_0x641816(0x1dc))[_0x641816(0x135)]=_0x4339f7,document[_0x641816(0x1d3)](_0x641816(0x254))[_0x641816(0x135)]=_0x2c79b0,document[_0x641816(0x1d3)](_0x641816(0x123))[_0x641816(0x135)]='',_0x1c0ae1[_0x641816(0x210)]();}function updateRunningTimeAgain(){const _0x1e348f=a0_0x25f3c7,_0x3f1eae=document[_0x1e348f(0x1d3)](_0x1e348f(0x11a))[_0x1e348f(0x135)];fetch('/api/config/running-time-again',{'method':_0x1e348f(0x1ed),'headers':{'Content-Type':_0x1e348f(0x157)},'body':JSON[_0x1e348f(0x20f)]({'runningTimeAgain':_0x3f1eae})})[_0x1e348f(0x232)](_0x215f0b=>_0x215f0b[_0x1e348f(0x1a0)]())[_0x1e348f(0x232)](_0x8da9b1=>{const _0x41805f=_0x1e348f;_0x8da9b1[_0x41805f(0x127)]?showToast(_0x41805f(0x1e1),_0x41805f(0x127)):showToast(_0x41805f(0x204),_0x41805f(0x1d2));})[_0x1e348f(0x21d)](_0x3df086=>{const _0x4963f7=_0x1e348f;console[_0x4963f7(0x1d2)](_0x4963f7(0x241),_0x3df086),showToast(_0x4963f7(0x204),_0x4963f7(0x1d2));});}function removeAllVideos(){removeAllTasks();}document[a0_0x25f3c7(0x118)]('DOMContentLoaded',()=>{const _0x241fd2=a0_0x25f3c7;document['getElementById']('createThreadForm')[_0x241fd2(0x118)](_0x241fd2(0x224),function(_0x582fc3){const _0x14cddf=_0x241fd2;_0x582fc3[_0x14cddf(0x22b)]();const _0x3b0fac=Number(document[_0x14cddf(0x1d3)](_0x14cddf(0x24a))[_0x14cddf(0x135)]),_0x5695af=parseInt(document[_0x14cddf(0x1d3)]('delayMinInput')[_0x14cddf(0x135)],0xa),_0x333fad=parseInt(document[_0x14cddf(0x1d3)]('delayMaxInput')[_0x14cddf(0x135)],0xa),_0x1605fd=parseInt(document[_0x14cddf(0x1d3)](_0x14cddf(0x154))[_0x14cddf(0x135)],0xa),_0x2d2970=document[_0x14cddf(0x1d3)](_0x14cddf(0x132))[_0x14cddf(0x135)]||null,_0x1c7c61=document[_0x14cddf(0x1d3)](_0x14cddf(0x193))['value']||null,_0x1b2752=document[_0x14cddf(0x1d3)]('uploadModeSelect')[_0x14cddf(0x135)],_0x506a3e=document['getElementById'](_0x14cddf(0x1d4))[_0x14cddf(0x1ab)],_0x5a7b10=document[_0x14cddf(0x1d3)](_0x14cddf(0x15a))?.[_0x14cddf(0x135)]||'vn';if(!_0x3b0fac){showToast(_0x14cddf(0x220),_0x14cddf(0x1d2));return;}if(isNaN(_0x5695af)||_0x5695af<0xa||isNaN(_0x333fad)||_0x333fad<_0x5695af){showToast('Thời\x20gian\x20chờ\x20không\x20hợp\x20lệ\x20(min\x20>=\x2010,\x20max\x20>=\x20min)',_0x14cddf(0x1d2));return;}if(isNaN(_0x1605fd)||_0x1605fd<=0x0){showToast('Số\x20lượng\x20video\x20phải\x20lớn\x20hơn\x200','error');return;}fetch(_0x14cddf(0x1a8),{'method':'POST','headers':{'Content-Type':_0x14cddf(0x157)},'body':JSON[_0x14cddf(0x20f)]({'userId':_0x3b0fac,'delay_min':_0x5695af,'delay_max':_0x333fad,'proxy':_0x2d2970,'count_video_upload':_0x1605fd,'caption':_0x1c7c61,'upload_mode':_0x1b2752,'auto_fill_products':_0x506a3e,'country':_0x5a7b10})})['then'](_0x41fbbd=>_0x41fbbd['json']())['then'](_0x3ed9ca=>{const _0x8089d4=_0x14cddf;if(_0x3ed9ca['error']){showToast(_0x3ed9ca[_0x8089d4(0x1d2)],'error');return;}loadUsers(),loadThreads();const _0x302cfb=bootstrap[_0x8089d4(0x18c)][_0x8089d4(0x147)](document[_0x8089d4(0x1d3)]('createThreadModal'));_0x302cfb['hide'](),showToast(_0x8089d4(0x189),_0x8089d4(0x127));})[_0x14cddf(0x21d)](_0x3698fa=>{const _0x2e3d4b=_0x14cddf;console[_0x2e3d4b(0x1d2)](_0x2e3d4b(0x241),_0x3698fa),showToast(_0x2e3d4b(0x1ff),_0x2e3d4b(0x1d2));});}),loadThreads();const _0x58a326=document[_0x241fd2(0x1d3)](_0x241fd2(0x19b));_0x58a326&&_0x58a326[_0x241fd2(0x118)](_0x241fd2(0x224),function(_0x4edcd5){const _0x32c207=_0x241fd2;_0x4edcd5[_0x32c207(0x22b)]();const _0x780397=new FormData(this),_0x4bc557=document[_0x32c207(0x1d3)](_0x32c207(0x230))?.['value']?.[_0x32c207(0x1ae)]();if(!_0x4bc557){showToast(_0x32c207(0x14e),'warning');return;}const _0xd2dd1b=document[_0x32c207(0x1d3)](_0x32c207(0x126))?.['value']?.[_0x32c207(0x1ae)]()||'',_0x221b81=document[_0x32c207(0x1d3)](_0x32c207(0x264))?.[_0x32c207(0x1f3)]?.[_0x32c207(0x192)]>0x0;if(!_0x221b81&&!_0xd2dd1b){showToast(_0x32c207(0x13b),_0x32c207(0x183));return;}_0x780397['append']('videoFolder',_0x4bc557),_0x780397[_0x32c207(0x226)](_0x32c207(0x17d),_0xd2dd1b),_0x780397[_0x32c207(0x226)](_0x32c207(0x152),document['getElementById'](_0x32c207(0x275))?.['value']||'60'),_0x780397[_0x32c207(0x226)](_0x32c207(0x13d),document[_0x32c207(0x1d3)](_0x32c207(0x12e))?.['value']||_0x32c207(0x11e)),_0x780397[_0x32c207(0x226)]('country',document['getElementById']('excelCountry')?.[_0x32c207(0x135)]||'vn'),_0x780397['append']('autoStart',document[_0x32c207(0x1d3)](_0x32c207(0x1e3))?.['checked']?'true':_0x32c207(0x225));const _0x46b925=document[_0x32c207(0x1d3)](_0x32c207(0x206));_0x46b925&&(_0x46b925['disabled']=!![],_0x46b925[_0x32c207(0x18a)]=_0x32c207(0x137)),fetch('/api/videos/import-excel',{'method':_0x32c207(0x1ed),'body':_0x780397})[_0x32c207(0x232)](_0x1ba1f2=>_0x1ba1f2[_0x32c207(0x1a0)]())['then'](_0x2187ff=>{const _0x401d22=_0x32c207,_0x498b3b=document[_0x401d22(0x1d3)](_0x401d22(0x1bf)),_0x1bb768=document[_0x401d22(0x1d3)](_0x401d22(0x21b));if(_0x498b3b&&_0x1bb768){_0x498b3b[_0x401d22(0x1f1)]['display']='';if(_0x2187ff[_0x401d22(0x127)]){const _0x4d7c35=_0x2187ff[_0x401d22(0x1a7)],_0x248ca1=_0x2187ff[_0x401d22(0x19f)]?Object[_0x401d22(0x262)](_0x2187ff[_0x401d22(0x19f)])[_0x401d22(0x188)](([_0xbb62c0,_0x5c325c])=>_0xbb62c0+'=\x22'+_0x5c325c+'\x22')[_0x401d22(0x1ea)](',\x20'):'';let _0x19ca3f=_0x401d22(0x24b)+(_0x2187ff['imported']>0x0?_0x401d22(0x175):_0x401d22(0x258))+_0x401d22(0x255)+_0x2187ff[_0x401d22(0x182)]+_0x401d22(0x1b3)+(_0x4d7c35[_0x401d22(0x146)]>0x0?_0x401d22(0x169)+_0x4d7c35[_0x401d22(0x146)]+_0x401d22(0x12d):'')+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20|\x20Folder:\x20'+_0x4d7c35[_0x401d22(0x205)]+_0x401d22(0x215)+(_0x2187ff[_0x401d22(0x274)]||0x0)+_0x401d22(0x18e)+(_0x2187ff[_0x401d22(0x130)]||0x0)+_0x401d22(0x223);_0x248ca1&&(_0x19ca3f+=_0x401d22(0x187)+_0x248ca1+_0x401d22(0x20c)),(_0x2187ff[_0x401d22(0x22d)]>0x0||_0x2187ff[_0x401d22(0x16c)]>0x0)&&(_0x19ca3f+=_0x401d22(0x212)+_0x2187ff['threadsCreated']+'\x20tạo\x20mới\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+(_0x2187ff[_0x401d22(0x16c)]>0x0?_0x401d22(0x1b8)+_0x2187ff[_0x401d22(0x16c)]+'\x20đã\x20tồn\x20tại\x20(auto-start)':'')+_0x401d22(0x13c)+(_0x2187ff['autoStarted']?_0x401d22(0x250):'\x20|\x20<span\x20class=\x22badge\x20bg-secondary\x22>Chờ\x20bắt\x20đầu</span>')+_0x401d22(0x1d9)),_0x2187ff[_0x401d22(0x146)]&&_0x2187ff['invalid'][_0x401d22(0x192)]>0x0&&(_0x19ca3f+=_0x401d22(0x270)+_0x2187ff[_0x401d22(0x146)]['length']+')</summary>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20style=\x22max-height:150px;overflow-y:auto;\x22\x20class=\x22mt-1\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<table\x20class=\x22table\x20table-sm\x20table-bordered\x20mb-0\x20small\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<thead\x20class=\x22table-light\x22><tr><th>Row</th><th>Account</th><th>Video</th><th>Lỗi</th></tr></thead>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<tbody>'+_0x2187ff[_0x401d22(0x146)][_0x401d22(0x188)](_0x430868=>_0x401d22(0x244)+_0x430868[_0x401d22(0x229)]+_0x401d22(0x1ec)+_0x430868[_0x401d22(0x17c)]+_0x401d22(0x1ec)+_0x430868[_0x401d22(0x1ca)]+_0x401d22(0x1ec)+_0x430868[_0x401d22(0x1d2)]+'</td></tr>')[_0x401d22(0x1ea)]('')+'</tbody>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</table></div></details>'),_0x1bb768[_0x401d22(0x18a)]=_0x19ca3f,_0x2187ff[_0x401d22(0x182)]>0x0&&(showToast(_0x401d22(0x166)+_0x2187ff[_0x401d22(0x182)]+'\x20tasks,\x20tạo\x20'+_0x2187ff[_0x401d22(0x22d)]+'\x20luồng'+(_0x2187ff['autoStarted']?'\x20—\x20đang\x20chạy':''),'success'),updateTaskStats(),loadThreads(),setTimeout(()=>{const _0x11b500=_0x401d22,_0x24ae98=bootstrap[_0x11b500(0x18c)][_0x11b500(0x147)](document[_0x11b500(0x1d3)](_0x11b500(0x14b)));if(_0x24ae98)_0x24ae98['hide']();},0x7d0),_0x46b925&&(_0x46b925[_0x401d22(0x176)]=!![],_0x46b925[_0x401d22(0x18a)]=_0x401d22(0x1f4)));}else _0x1bb768['innerHTML']=_0x401d22(0x14a)+_0x2187ff[_0x401d22(0x1b6)]+_0x401d22(0x20c),showToast(_0x2187ff[_0x401d22(0x1b6)],'error');}})[_0x32c207(0x21d)](()=>showToast(_0x32c207(0x1de),'error'))[_0x32c207(0x219)](()=>{const _0x26a159=_0x32c207;_0x46b925&&(_0x46b925['disabled']=![],_0x46b925[_0x26a159(0x18a)]='<i\x20class=\x22bi\x20bi-upload\x20me-1\x22></i>Nhập\x20&\x20Validate');});}),document[_0x241fd2(0x1d3)]('editThreadUserCookieForm')[_0x241fd2(0x118)](_0x241fd2(0x224),function(_0x280aa3){const _0x3f3ece=_0x241fd2;_0x280aa3[_0x3f3ece(0x22b)]();const _0x348545=document[_0x3f3ece(0x1d3)](_0x3f3ece(0x1dc))['value'],_0xa14b37=document[_0x3f3ece(0x1d3)](_0x3f3ece(0x123))[_0x3f3ece(0x135)][_0x3f3ece(0x1ae)]();if(!_0xa14b37){showToast('Vui\x20lòng\x20nhập\x20cookie','warning');return;}fetch('/api/users/'+_0x348545,{'method':_0x3f3ece(0x119),'headers':{'Content-Type':_0x3f3ece(0x157)},'body':JSON[_0x3f3ece(0x20f)]({'cookie':_0xa14b37})})[_0x3f3ece(0x232)](_0x215754=>_0x215754['json']())[_0x3f3ece(0x232)](_0x39bbdb=>{const _0x13df25=_0x3f3ece;if(_0x39bbdb[_0x13df25(0x127)]){loadUsers(),loadThreads();const _0x250427=bootstrap[_0x13df25(0x18c)][_0x13df25(0x147)](document['getElementById'](_0x13df25(0x218)));_0x250427[_0x13df25(0x1ba)](),showToast('Cập\x20nhật\x20cookie\x20thành\x20công',_0x13df25(0x127));}else showToast(_0x39bbdb[_0x13df25(0x1b6)]||_0x13df25(0x1cc),_0x13df25(0x1d2));})[_0x3f3ece(0x21d)](_0xec30bf=>{const _0x2e3e93=_0x3f3ece;console['error'](_0x2e3e93(0x241),_0xec30bf),showToast(_0x2e3e93(0x1cc),'error');});}),fetch(_0x241fd2(0x208))[_0x241fd2(0x232)](_0x65e33=>_0x65e33['json']())[_0x241fd2(0x232)](_0x400cce=>{const _0x29051f=_0x241fd2;_0x400cce['runningTimeAgain']&&(document[_0x29051f(0x1d3)](_0x29051f(0x11a))['value']=_0x400cce[_0x29051f(0x114)]);})[_0x241fd2(0x21d)](_0x220982=>{const _0x76f75b=_0x241fd2;console['error'](_0x76f75b(0x11b),_0x220982);});});

// =========================================================================
// BỘ HIỂN THỊ BẢNG LUỒNG CUỘN TOÀN BỘ SIÊU MƯỢT (0 HIDDEN INPUTS + DIFF TỪNG DÒNG)
// =========================================================================
window._allThreadsList = [];
window._filteredThreadsList = [];
window._selectedThreadIds = new Set();
window._renderedThreadSigs = new Map();
window._renderedThreadOrder = '';
let _fetchingThreadsPromise = null;

function escapeThreadHtml(str) {
    return String(str || '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function getSelectedThreadObjects() {
    const idSet = window._selectedThreadIds;
    if (idSet && idSet.size > 0) {
        return window._allThreadsList.filter(t => idSet.has(String(t.id)));
    }
    const checkedDomIds = new Set(
        Array.from(document.querySelectorAll('.thread-checkbox:checked'))
            .filter(el => el.id !== 'selectAllThreads')
            .map(el => String(el.dataset.threadId))
            .filter(Boolean)
    );
    return window._allThreadsList.filter(t => checkedDomIds.has(String(t.id)));
}

function updateSelectedThreadsBadge() {
    const badge = document.getElementById('selectedThreadsBadge');
    const total = window._allThreadsList.length;
    const count = window._selectedThreadIds.size;
    if (badge) {
        badge.textContent = `Đã chọn: ${count} / ${total}`;
        badge.className = count > 0
            ? 'badge bg-primary text-white ms-1'
            : 'badge bg-secondary-subtle text-dark border ms-1';
    }
    const selectAll = document.getElementById('selectAllThreads');
    if (selectAll) {
        const filtered = window._filteredThreadsList || [];
        selectAll.checked = filtered.length > 0 && filtered.every(t => window._selectedThreadIds.has(String(t.id)));
    }
}

window.onThreadCheckboxChange = function(cb) {
    const tid = String(cb.dataset.threadId || '');
    if (!tid) return;
    if (cb.checked) {
        window._selectedThreadIds.add(tid);
    } else {
        window._selectedThreadIds.delete(tid);
    }
    window._renderedThreadSigs.delete(tid);
    updateSelectedThreadsBadge();
};

window.toggleAllThreads = toggleAllThreads = function(checkbox) {
    const filtered = window._filteredThreadsList || [];
    if (checkbox.checked) {
        filtered.forEach(t => window._selectedThreadIds.add(String(t.id)));
    } else {
        filtered.forEach(t => window._selectedThreadIds.delete(String(t.id)));
    }
    document.querySelectorAll('.thread-checkbox:not(:disabled)').forEach(box => {
        if (box.id !== 'selectAllThreads') box.checked = checkbox.checked;
        const tid = String(box.dataset.threadId || '');
        if (tid && window._renderedThreadSigs.has(tid)) {
            window._renderedThreadSigs.delete(tid);
        }
    });
    updateSelectedThreadsBadge();
};

window.filterAndRenderThreads = function() {
    const q = (document.getElementById('threadSearchInput')?.value || '').trim().toLowerCase();
    if (!q) {
        window._filteredThreadsList = window._allThreadsList;
    } else {
        window._filteredThreadsList = window._allThreadsList.filter(t =>
            String(t.username || '').toLowerCase().includes(q) ||
            String(t.error || '').toLowerCase().includes(q) ||
            String(t.proxy_host || t.user_proxy || '').toLowerCase().includes(q) ||
            String(t.status || '').toLowerCase().includes(q) ||
            String(t.country || '').toLowerCase().includes(q)
        );
    }
    renderThreadsAll();
};

function formatThreadProxyDisplay(t) {
    if (t.proxy_host && t.proxy_port) {
        let s = `${t.proxy_host}:${t.proxy_port}`;
        if (t.proxy_username) s += `:${t.proxy_username}:***`;
        return { text: s, inherited: false };
    }
    if (t.user_proxy) {
        const raw = String(t.user_proxy);
        let prefix = '';
        for (const p of ['socks5h://', 'socks5://', 'socks4://', 'http://', 'https://']) {
            if (raw.toLowerCase().startsWith(p)) { prefix = p; break; }
        }
        const rest = raw.slice(prefix.length);
        const parts = rest.split(':');
        const masked = parts.length === 4 ? `${prefix}${parts[0]}:${parts[1]}:${parts[2]}:***` : raw;
        return { text: masked, inherited: true };
    }
    return { text: '-', inherited: false };
}

function classifyCreditError(errText) {
    if (!errText) return null;
    const isNetworkDisconnect = (
        errText.includes('ENOTFOUND') ||
        errText.includes('ECONNREFUSED') ||
        errText.includes('ETIMEDOUT') ||
        errText.includes('Không thể kết nối về cụm máy chủ') ||
        errText.includes('gián đoạn tạm thời')
    );
    if (isNetworkDisconnect) return null;
    if (
        errText.includes('API Key không tồn tại') ||
        errText.includes('không hợp lệ') ||
        errText.includes('Chưa nhập API Key') ||
        errText.includes('Chưa gắn API Key')
    ) {
        return 'invalid_key';
    }
    if (
        errText.includes('hết Credit') ||
        errText.includes('Hết Credit') ||
        errText.includes('0 điểm') ||
        errText.includes('hết thời hạn')
    ) {
        return 'out_of_credit';
    }
    return null;
}

function getThreadRowSig(t, rowNum) {
    const tid = String(t.id);
    const checked = window._selectedThreadIds.has(tid) ? '1' : '0';
    return `${rowNum}|${checked}|${t.status}|${t.videos_uploaded}|${t.count_video_upload}|${t.next_run_at || 0}|${t.error || ''}|${t.country || 'vn'}|${t.proxy_host || ''}|${t.proxy_port || ''}|${t.user_proxy || ''}|${t.username || ''}|${t.cookie || ''}`;
}

function buildThreadRowHtml(t, rowNum) {
    const statusMeta = {
        stop: { badge: 'bg-secondary', icon: 'bi-stop-circle', label: 'Dừng' },
        done: { badge: 'bg-success', icon: 'bi-check-circle', label: 'Xong' },
        error: { badge: 'bg-danger', icon: 'bi-x-circle', label: 'Lỗi' },
        inprogress: { badge: 'bg-primary', icon: 'bi-play-circle', label: 'Đang chạy' }
    };
    const tid = String(t.id);
    const uid = Number(t.user_id);
    const isChecked = window._selectedThreadIds.has(tid) ? 'checked' : '';
    const st = statusMeta[t.status] || { badge: 'bg-secondary', icon: '', label: t.status || '-' };
    const isStopped = ['stop', 'done', 'error'].includes(t.status);
    const cookieShort = escapeThreadHtml(t.cookie ? t.cookie.substring(0, 25) + '...' : '-');
    const unEsc = escapeThreadHtml(t.username);
    const countryCode = (t.country || 'vn').toLowerCase();
    const countryDisp = getCountryDisplay(countryCode);
    const uploaded = Number(t.videos_uploaded || 0);
    const totalTarget = Number(t.count_video_upload || 0);
    const pending = Math.max(0, totalTarget - uploaded);
    const pxInfo = formatThreadProxyDisplay(t);
    const rawErr = String(t.error || '').trim();
    const errEsc = escapeThreadHtml(rawErr);
    const creditKind = classifyCreditError(rawErr);

    const modeBadge = t.upload_mode === 'duet'
        ? ' <span class="badge bg-info" style="font-size:0.6rem">DUET</span>'
        : (t.upload_mode === 'auto' ? ' <span class="badge bg-warning text-dark" style="font-size:0.6rem">AUTO</span>' : '');
    const spBadge = t.auto_fill_products ? ' <span class="badge bg-success" style="font-size:0.6rem">+SP</span>' : '';
    const countdownHtml = t.status === 'inprogress'
        ? `<br><span class="badge bg-warning text-dark" style="font-size:0.6rem" id="countdown_${tid}" data-next="${t.next_run_at || 0}"></span>`
        : '';

    const errCellStyle = creditKind ? ' style="color:#b91c1c;font-weight:600;"' : '';
    const statusBadgeHtml = creditKind
        ? `<span class="badge bg-danger text-wrap" style="font-size:0.72rem;line-height:1.25;" title="${errEsc}">${creditKind === 'invalid_key' ? '<i class="bi bi-key-fill me-1"></i>Sai/Thiếu Key' : '<i class="bi bi-exclamation-triangle-fill me-1"></i>Hết Credit'}</span>`
        : `<span class="badge ${st.badge}"><i class="bi ${st.icon} me-1"></i>${st.label}</span>`;

    return `<tr id="threadRow_${tid}">
<td><div class="form-check form-switch mb-0"><input type="checkbox" class="form-check-input thread-checkbox" data-thread-id="${tid}" data-thread-status="${escapeThreadHtml(t.status)}" id="threadCheckbox${tid}" ${isChecked} onchange="onThreadCheckboxChange(this)"></div></td>
<td class="text-muted">${rowNum}</td>
<td id="usernameCell_${uid}"><span id="usernameDisplay_${uid}" class="d-flex align-items-center gap-1"><strong>${unEsc}</strong>${modeBadge}${spBadge}<button type="button" class="btn btn-sm p-0 text-primary" onclick="toggleEditUsername(${uid})" title="Sửa username"><i class="bi bi-pencil-square" style="font-size:0.7rem"></i></button></span></td>
<td><div class="d-flex align-items-center gap-1"><code class="small text-truncate" style="max-width:130px;display:inline-block" title="${cookieShort}">${cookieShort}</code><button type="button" class="btn btn-sm p-0 text-primary" onclick="editThreadUserCookieForm(${uid}, '${unEsc}')" title="Sửa cookie"><i class="bi bi-pencil-square" style="font-size:0.7rem"></i></button></div></td>
<td id="countryCell_${tid}"><span id="countryDisplay_${tid}" class="d-flex align-items-center gap-1"><span class="badge bg-light text-dark border" title="${countryCode.toUpperCase()}">${countryDisp}</span><button type="button" class="btn btn-sm p-0 text-primary" onclick="toggleEditCountry(${t.id})" title="Đổi nước"><i class="bi bi-pencil-square" style="font-size:0.7rem"></i></button></span></td>
<td><a href="#" class="text-decoration-none small" onclick="showThreadTasks(${uid}, '${unEsc}'); return false;" title="Xem danh sách video"><i class="bi bi-list-ul me-1"></i>${totalTarget} video</a></td>
<td id="uploadedCell_${tid}"><span id="uploadedDisplay_${tid}" class="d-flex align-items-center gap-1"><strong>${uploaded}</strong><small class="text-muted">/${totalTarget}</small><button type="button" class="btn btn-sm p-0 text-primary" onclick="toggleEditUploaded(${t.id})" title="Sửa uploaded"><i class="bi bi-pencil-square" style="font-size:0.7rem"></i></button></span></td>
<td><span class="badge ${pending > 0 ? 'bg-warning text-dark' : 'bg-success'}">${pending}</span></td>
<td><small>${t.delay_min || 60}-${t.delay_max || 180}s</small>${countdownHtml}</td>
<td id="proxyCell_${tid}"><span id="proxyDisplay_${tid}" class="d-flex align-items-center gap-1"><code class="small">${escapeThreadHtml(pxInfo.text)}</code>${pxInfo.inherited ? '<span class="badge bg-info text-dark" style="font-size:0.55rem" title="Proxy thừa hưởng từ user">↪user</span>' : ''}<button type="button" class="btn btn-sm p-0 text-primary" onclick="toggleEditProxy(${t.id})" title="Sửa proxy"><i class="bi bi-pencil-square" style="font-size:0.7rem"></i></button></span></td>
<td class="log-error-cell"${errCellStyle} title="${errEsc}">${errEsc || '<span class="text-muted">-</span>'}</td>
<td>${statusBadgeHtml}</td>
<td class="text-nowrap"><button type="button" class="btn btn-sm ${isStopped ? 'btn-success' : 'btn-warning'}" onclick="toggleThreadStatus(${t.id})" title="${isStopped ? 'Bắt đầu' : 'Dừng'}"><i class="bi ${isStopped ? 'bi-play-fill' : 'bi-pause-fill'}"></i></button> <button type="button" class="btn btn-sm btn-outline-info" onclick="check24h(${t.id})" title="Check video 24h" id="check24hBtn_${t.id}"><i class="bi bi-clock-history"></i> <span id="check24hResult_${t.id}"></span></button> <button type="button" class="btn btn-sm btn-outline-danger" onclick="deleteThread(${t.id})" title="Xóa"><i class="bi bi-trash3"></i></button></td>
</tr>`;
}

function syncCreditAlertBar() {
    const alertBar = document.getElementById('creditOutAlertBar');
    const alertText = document.getElementById('creditOutAlertText');
    if (!alertBar) return;
    let sampleMsg = '';
    for (const t of window._allThreadsList) {
        const rawErr = String(t.error || '').trim();
        if (classifyCreditError(rawErr)) {
            sampleMsg = rawErr;
            break;
        }
    }
    if (sampleMsg) {
        alertBar.classList.remove('d-none');
        alertBar.classList.add('d-flex');
        if (alertText) alertText.textContent = sampleMsg;
    } else {
        alertBar.classList.add('d-none');
        alertBar.classList.remove('d-flex');
    }
}

function renderThreadsAll() {
    const tbody = document.getElementById('threadTable');
    if (!tbody) return;

    // Không ghi đè bảng khi người dùng đang gõ trong ô sửa nhanh
    if (document.activeElement && tbody.contains(document.activeElement) && /^(INPUT|SELECT|TEXTAREA)$/.test(document.activeElement.tagName)) {
        return;
    }

    const list = window._filteredThreadsList || [];
    const totalAll = window._allThreadsList.length;
    const totalFiltered = list.length;

    const infoEl = document.getElementById('threadTotalInfo');
    if (infoEl) {
        infoEl.textContent = totalFiltered === totalAll
            ? ''
            : `(Lọc: ${totalFiltered}/${totalAll})`;
    }

    syncCreditAlertBar();

    if (totalFiltered === 0) {
        tbody.innerHTML = '<tr><td colspan="13" class="text-center text-muted py-4">Chưa có luồng nào phù hợp</td></tr>';
        window._renderedThreadOrder = '';
        window._renderedThreadSigs.clear();
        updateSelectedThreadsBadge();
        return;
    }

    const orderKey = list.map(t => t.id).join(',');
    if (orderKey === window._renderedThreadOrder && tbody.children.length === totalFiltered) {
        for (let i = 0; i < totalFiltered; i++) {
            const t = list[i];
            const tid = String(t.id);
            const sig = getThreadRowSig(t, i + 1);
            if (window._renderedThreadSigs.get(tid) !== sig) {
                const rowEl = document.getElementById('threadRow_' + tid);
                if (rowEl) {
                    rowEl.outerHTML = buildThreadRowHtml(t, i + 1);
                    window._renderedThreadSigs.set(tid, sig);
                    if (_check24hCache[t.id]) applyCheck24hResult(t.id);
                }
            }
        }
        updateSelectedThreadsBadge();
        if (typeof updateCountdowns === 'function') updateCountdowns();
        return;
    }

    const scrollBox = document.getElementById('threadsScrollContainer');
    const prevScrollTop = scrollBox ? scrollBox.scrollTop : 0;

    const rowsHtml = new Array(totalFiltered);
    const nextSigs = new Map();
    for (let i = 0; i < totalFiltered; i++) {
        const t = list[i];
        const tid = String(t.id);
        rowsHtml[i] = buildThreadRowHtml(t, i + 1);
        nextSigs.set(tid, getThreadRowSig(t, i + 1));
    }

    tbody.innerHTML = rowsHtml.join('');
    window._renderedThreadOrder = orderKey;
    window._renderedThreadSigs = nextSigs;
    if (scrollBox && prevScrollTop > 0) {
        scrollBox.scrollTop = prevScrollTop;
    }

    updateSelectedThreadsBadge();
    if (typeof restoreAllCheck24h === 'function') restoreAllCheck24h();
    if (typeof updateCountdowns === 'function') updateCountdowns();
}

window.loadThreads = loadThreads = function(forceRender = false) {
    const pane = document.getElementById('threads-content');
    const isVisible = Boolean(pane && (pane.classList.contains('active') || pane.classList.contains('show')));
    if (!forceRender && !isVisible && window._allThreadsList.length > 0) {
        return Promise.resolve();
    }
    if (_fetchingThreadsPromise) return _fetchingThreadsPromise;

    _fetchingThreadsPromise = fetch('/api/threads')
        .then(r => r.json())
        .then(data => {
            if (!Array.isArray(data)) return;
            window._allThreadsList = data;
            const validIds = new Set(data.map(t => String(t.id)));
            for (const id of Array.from(window._selectedThreadIds)) {
                if (!validIds.has(id)) window._selectedThreadIds.delete(id);
            }
            if (forceRender || isVisible) {
                filterAndRenderThreads();
            } else {
                updateSelectedThreadsBadge();
            }
        })
        .catch(err => console.error('Error loading threads:', err))
        .finally(() => {
            _fetchingThreadsPromise = null;
        });
    return _fetchingThreadsPromise;
};

// === Các hàm sửa inline tạo ô input theo yêu cầu (0 hidden inputs trên bảng) ===
window.toggleEditUsername = toggleEditUsername = function(userId) {
    const tObj = window._allThreadsList.find(t => Number(t.user_id) === Number(userId));
    const cell = document.getElementById('usernameCell_' + userId);
    const disp = document.getElementById('usernameDisplay_' + userId);
    if (disp) disp.classList.add('d-none');
    let edit = document.getElementById('usernameEdit_' + userId);
    if (!edit && cell) {
        edit = document.createElement('div');
        edit.id = 'usernameEdit_' + userId;
        edit.innerHTML = `<div class="input-group input-group-sm"><input type="text" class="form-control form-control-sm" id="usernameInput_${userId}" autocomplete="off" data-lpignore="true" data-1p-ignore="true" style="min-width:75px"><button type="button" class="btn btn-success btn-sm" onclick="saveThreadUsername(${userId})"><i class="bi bi-check"></i></button><button type="button" class="btn btn-secondary btn-sm" onclick="cancelEditUsername(${userId})"><i class="bi bi-x"></i></button></div>`;
        cell.appendChild(edit);
    }
    const inp = document.getElementById('usernameInput_' + userId);
    if (inp) { inp.value = tObj?.username || ''; inp.focus(); }
};
window.cancelEditUsername = cancelEditUsername = function(userId) {
    document.getElementById('usernameDisplay_' + userId)?.classList.remove('d-none');
    document.getElementById('usernameEdit_' + userId)?.remove();
};

window.toggleEditCountry = toggleEditCountry = function(threadId) {
    const tObj = window._allThreadsList.find(t => Number(t.id) === Number(threadId));
    const cur = (tObj?.country || 'vn').toLowerCase();
    const cell = document.getElementById('countryCell_' + threadId);
    document.getElementById('countryDisplay_' + threadId)?.classList.add('d-none');
    let edit = document.getElementById('countryEdit_' + threadId);
    if (!edit && cell) {
        edit = document.createElement('div');
        edit.id = 'countryEdit_' + threadId;
        const opts = COUNTRY_LIST.map(c => `<option value="${c.code}" ${c.code === cur ? 'selected' : ''}>${c.flag} ${c.code.toUpperCase()}</option>`).join('');
        edit.innerHTML = `<div class="input-group input-group-sm"><select class="form-select form-select-sm" id="countryInput_${threadId}" style="min-width:85px">${opts}</select><button type="button" class="btn btn-success btn-sm" onclick="saveThreadCountry(${threadId})"><i class="bi bi-check"></i></button><button type="button" class="btn btn-secondary btn-sm" onclick="cancelEditCountry(${threadId})"><i class="bi bi-x"></i></button></div>`;
        cell.appendChild(edit);
    }
};
window.cancelEditCountry = cancelEditCountry = function(threadId) {
    document.getElementById('countryDisplay_' + threadId)?.classList.remove('d-none');
    document.getElementById('countryEdit_' + threadId)?.remove();
};

window.toggleEditUploaded = toggleEditUploaded = function(threadId) {
    const tObj = window._allThreadsList.find(t => Number(t.id) === Number(threadId));
    const cell = document.getElementById('uploadedCell_' + threadId);
    document.getElementById('uploadedDisplay_' + threadId)?.classList.add('d-none');
    let edit = document.getElementById('uploadedEdit_' + threadId);
    if (!edit && cell) {
        edit = document.createElement('div');
        edit.id = 'uploadedEdit_' + threadId;
        edit.innerHTML = `<div class="input-group input-group-sm"><input type="number" class="form-control form-control-sm" id="uploadedInput_${threadId}" min="0" style="width:65px"><button type="button" class="btn btn-success btn-sm" onclick="saveThreadUploaded(${threadId})"><i class="bi bi-check"></i></button><button type="button" class="btn btn-secondary btn-sm" onclick="cancelEditUploaded(${threadId})"><i class="bi bi-x"></i></button></div>`;
        cell.appendChild(edit);
    }
    const inp = document.getElementById('uploadedInput_' + threadId);
    if (inp) { inp.value = tObj?.videos_uploaded || 0; inp.focus(); }
};
window.cancelEditUploaded = cancelEditUploaded = function(threadId) {
    document.getElementById('uploadedDisplay_' + threadId)?.classList.remove('d-none');
    document.getElementById('uploadedEdit_' + threadId)?.remove();
};

window.toggleEditProxy = toggleEditProxy = function(threadId) {
    const tObj = window._allThreadsList.find(t => Number(t.id) === Number(threadId));
    const cell = document.getElementById('proxyCell_' + threadId);
    document.getElementById('proxyDisplay_' + threadId)?.classList.add('d-none');
    let edit = document.getElementById('proxyEdit_' + threadId);
    if (!edit && cell) {
        edit = document.createElement('div');
        edit.id = 'proxyEdit_' + threadId;
        edit.innerHTML = `<div class="input-group input-group-sm"><input type="text" class="form-control form-control-sm" id="proxyInput_${threadId}" placeholder="IP:PORT:USER:PASS" autocomplete="off" data-lpignore="true" data-1p-ignore="true" style="min-width:125px"><button type="button" class="btn btn-success btn-sm" onclick="saveThreadProxy(${threadId})"><i class="bi bi-check"></i></button><button type="button" class="btn btn-secondary btn-sm" onclick="cancelEditProxy(${threadId})"><i class="bi bi-x"></i></button></div>`;
        cell.appendChild(edit);
    }
    const inp = document.getElementById('proxyInput_' + threadId);
    if (inp) {
        let cur = '';
        if (tObj?.proxy_host && tObj?.proxy_port) {
            cur = `${tObj.proxy_host}:${tObj.proxy_port}`;
            if (tObj.proxy_username && tObj.proxy_password) cur += `:${tObj.proxy_username}:${tObj.proxy_password}`;
        }
        inp.value = cur;
        inp.focus();
    }
};
window.cancelEditProxy = cancelEditProxy = function(threadId) {
    document.getElementById('proxyDisplay_' + threadId)?.classList.remove('d-none');
    document.getElementById('proxyEdit_' + threadId)?.remove();
};

// === Thao tác hàng loạt xuyên trang ===
window.checkAll24h = checkAll24h = async function() {
    const selected = getSelectedThreadObjects().map(t => t.id);
    if (selected.length === 0) {
        showToast('Chọn ít nhất 1 luồng để check', 'warning');
        return;
    }
    showToast(`Đang check ${selected.length} luồng...`, 'info');
    for (const tid of selected) {
        check24h(tid);
        await new Promise(r => setTimeout(r, 500));
    }
};

window.startSelectedThreads = startSelectedThreads = function() {
    const selectedIds = getSelectedThreadObjects()
        .filter(t => t.status !== 'inprogress')
        .map(t => t.id);

    if (selectedIds.length === 0) {
        showToast('Vui lòng chọn ít nhất một luồng đang dừng để bắt đầu', 'warning');
        return;
    }

    fetch('/api/threads/start-selected', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ threadIds: selectedIds })
    })
    .then(r => r.json())
    .then(res => {
        if (res.success) {
            loadUsers();
            loadThreads(true);
            showToast(`Đã khởi động ${selectedIds.length} luồng thành công`, 'success');
        } else {
            showToast(res.error || 'Lỗi khi khởi động luồng', 'error');
        }
    })
    .catch(() => showToast('Lỗi khi khởi động các luồng đã chọn', 'error'));
};

window.pauseSelectedThreads = pauseSelectedThreads = function() {
    const selectedIds = getSelectedThreadObjects()
        .filter(t => t.status === 'inprogress')
        .map(t => t.id);

    if (selectedIds.length === 0) {
        showToast('Vui lòng chọn ít nhất một luồng đang chạy để tạm dừng', 'warning');
        return;
    }

    fetch('/api/threads/pause-selected', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ threadIds: selectedIds })
    })
    .then(r => r.json())
    .then(res => {
        if (res.success) {
            loadUsers();
            loadThreads(true);
            showToast(`Đã tạm dừng ${selectedIds.length} luồng thành công`, 'success');
        } else {
            showToast(res.error || 'Lỗi khi tạm dừng các luồng', 'error');
        }
    })
    .catch(() => showToast('Lỗi khi tạm dừng các luồng đã chọn', 'error'));
};

window.toggleThreadStatus = toggleThreadStatus = function(threadId) {
    fetch('/api/threads/' + threadId + '/toggle-status', { method: 'POST' })
    .then(r => r.json())
    .then(res => {
        if (res.success) {
            loadUsers();
            loadThreads(true);
            const actionText = res.status === 'stop' ? 'tạm dừng' : 'bắt đầu';
            showToast(`Luồng #${threadId} đã được ${actionText} thành công`, 'success');
        } else {
            showToast(res.error || 'Lỗi khi cập nhật trạng thái luồng', 'error');
        }
    })
    .catch(() => showToast('Lỗi khi cập nhật trạng thái luồng', 'error'));
};

window.deleteSelectedThreads = deleteSelectedThreads = function() {
    const selectedIds = getSelectedThreadObjects().map(t => t.id);
    if (selectedIds.length === 0) {
        showToast('Vui lòng chọn ít nhất một luồng để xóa', 'warning');
        return;
    }
    if (!confirm(`Bạn có chắc chắn muốn xóa ${selectedIds.length} luồng đã chọn không?`)) {
        return;
    }

    fetch('/api/threads/delete-selected', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ threadIds: selectedIds })
    })
    .then(r => r.json())
    .then(res => {
        if (res.success) {
            selectedIds.forEach(id => window._selectedThreadIds.delete(String(id)));
            loadUsers();
            loadThreads(true);
            showToast(`Đã xóa ${selectedIds.length} luồng thành công`, 'success');
        } else {
            showToast(res.error || 'Lỗi khi xóa các luồng', 'error');
        }
    })
    .catch(() => showToast('Lỗi khi xóa các luồng đã chọn', 'error'));
};

// Tối ưu updateCountdowns: chỉ chạy khi tab Quản Lý Luồng đang hiển thị
const _origUpdateCountdowns = typeof updateCountdowns === 'function' ? updateCountdowns : null;
if (_origUpdateCountdowns) {
    window.updateCountdowns = updateCountdowns = function() {
        const pane = document.getElementById('threads-content');
        if (!pane || (!pane.classList.contains('active') && !pane.classList.contains('show'))) return;
        _origUpdateCountdowns();
    };
}