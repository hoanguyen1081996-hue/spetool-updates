/**
 * src/views/scripts/reup.js
 * Giao diện quản lý Reup Video Shopee
 * (Giữ nguyên mã JS sạch trên trình duyệt theo quy tắc AGENTS.md)
 */

'use strict';

let _reupCurrentJobId = null;
let _reupPollTimer = null;
let _reupUsersInitialized = false;
let _reupSavedTargetUserIds = null;
let _reupSaveTimer = null;
let _reupApplyingSettings = false;
const REUP_SETTINGS_LS_KEY = 'spetool_reup_settings_v1';

function reupEscapeHtml(str) {
    return String(str || '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function reupSetSavedBadge(text, highlight = false) {
    const badge = document.getElementById('reupSettingsSavedBadge');
    if (!badge) return;
    badge.innerHTML = `<i class="bi bi-check2-circle me-1"></i>${reupEscapeHtml(text)}`;
    badge.style.color = highlight ? '#3d6b60' : '';
}

function reupCollectSettings() {
    const maxInput = document.getElementById('reupMaxVideosInput');
    const maxRaw = (maxInput?.value || '30').trim();
    const isAll = maxInput?.dataset.mode === 'all' || /^(?:tất\s*cả|tat\s*ca|all|toàn\s*kênh)$/i.test(maxRaw);

    const targetUserIds = _reupUsersInitialized
        ? Array.from(document.querySelectorAll('.reup-user-checkbox:checked'))
            .map((el) => parseInt(el.value, 10))
            .filter((n) => Number.isFinite(n) && n > 0)
        : (Array.isArray(_reupSavedTargetUserIds) ? _reupSavedTargetUserIds : []);

    return {
        channelUrls: document.getElementById('reupChannelUrls')?.value || '',
        maxVideosMode: isAll ? 'all' : 'number',
        maxVideosValue: isAll ? 'Tất cả' : (maxRaw.replace(/\D+/g, '') || '30'),
        minViews: Number(document.getElementById('reupMinViews')?.value || 0),
        onlyWithProducts: Boolean(document.getElementById('reupOnlyWithProducts')?.checked),
        skipAlreadyReupped: Boolean(document.getElementById('reupHideAlreadyReupped')?.checked),
        presetMode: document.getElementById('reupFpPreset')?.value || 'standard',
        mirrorFlip: Boolean(document.getElementById('reupMirrorFlip')?.checked),
        voiceMode: document.getElementById('reupVoiceMode')?.value || 'natural',
        productMode: document.getElementById('reupProductMode')?.value || 'keep_original',
        customProductLinks: document.getElementById('reupCustomProductLinks')?.value || '',
        stripOldHashtags: Boolean(document.getElementById('reupStripOldHashtags')?.checked),
        prefixText: document.getElementById('reupPrefixCaption')?.value || '',
        appendHashtags: document.getElementById('reupAppendHashtags')?.value || '',
        distributionMode: document.getElementById('reupDistributionMode')?.value || 'round_robin',
        delayMin: Math.max(10, parseInt(document.getElementById('reupDelayMin')?.value, 10) || 60),
        delayMax: Math.max(10, parseInt(document.getElementById('reupDelayMax')?.value, 10) || 180),
        autoStartThreads: Boolean(document.getElementById('reupAutoStartThreads')?.checked),
        targetUserIds
    };
}

function reupApplySavedSettings(cfg) {
    if (!cfg || typeof cfg !== 'object' || Object.keys(cfg).length === 0) return;
    _reupApplyingSettings = true;
    try {
        const setVal = (id, val) => {
            const el = document.getElementById(id);
            if (el && val !== undefined && val !== null) el.value = String(val);
        };
        const setChk = (id, val) => {
            const el = document.getElementById(id);
            if (el && typeof val === 'boolean') el.checked = val;
        };

        if (cfg.channelUrls !== undefined) setVal('reupChannelUrls', cfg.channelUrls);
        if (cfg.maxVideosMode === 'all') {
            reupPickMaxVideos('all', true);
        } else if (cfg.maxVideosValue !== undefined) {
            reupPickMaxVideos(cfg.maxVideosValue, true);
        }

        if (cfg.minViews !== undefined) setVal('reupMinViews', cfg.minViews);
        setChk('reupOnlyWithProducts', cfg.onlyWithProducts);
        setChk('reupHideAlreadyReupped', cfg.skipAlreadyReupped);
        if (cfg.presetMode) setVal('reupFpPreset', cfg.presetMode);
        setChk('reupMirrorFlip', cfg.mirrorFlip);
        if (cfg.voiceMode) setVal('reupVoiceMode', cfg.voiceMode);
        if (cfg.productMode) setVal('reupProductMode', cfg.productMode);
        if (cfg.customProductLinks !== undefined) setVal('reupCustomProductLinks', cfg.customProductLinks);
        setChk('reupStripOldHashtags', cfg.stripOldHashtags);
        if (cfg.prefixText !== undefined) setVal('reupPrefixCaption', cfg.prefixText);
        if (cfg.appendHashtags !== undefined) setVal('reupAppendHashtags', cfg.appendHashtags);
        if (cfg.distributionMode) setVal('reupDistributionMode', cfg.distributionMode);
        if (cfg.delayMin !== undefined) setVal('reupDelayMin', cfg.delayMin);
        if (cfg.delayMax !== undefined) setVal('reupDelayMax', cfg.delayMax);
        setChk('reupAutoStartThreads', cfg.autoStartThreads);

        if (Array.isArray(cfg.targetUserIds)) {
            _reupSavedTargetUserIds = cfg.targetUserIds;
        }
        reupOnProductModeChange();
    } finally {
        _reupApplyingSettings = false;
    }
}

async function reupSaveSettingsNow(showFeedback = false) {
    const cfg = reupCollectSettings();
    if (Array.isArray(cfg.targetUserIds)) {
        _reupSavedTargetUserIds = cfg.targetUserIds;
    }
    try { localStorage.setItem(REUP_SETTINGS_LS_KEY, JSON.stringify(cfg)); } catch (_) {}

    try {
        const res = await fetch('/api/reup/settings', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(cfg)
        });
        const data = await res.json();
        if (!res.ok || !data.success) {
            throw new Error(data.error || 'Không lưu được cài đặt');
        }
        reupSetSavedBadge('Đã lưu cài đặt', true);
        if (showFeedback && typeof showToast === 'function') {
            showToast('Đã lưu cài đặt Reup thành công!', 'success');
        }
    } catch (err) {
        if (showFeedback && typeof showToast === 'function') {
            showToast(err.message, 'error');
        }
    }
}

function reupScheduleSaveSettings() {
    if (_reupApplyingSettings) return;
    const cfg = reupCollectSettings();
    try { localStorage.setItem(REUP_SETTINGS_LS_KEY, JSON.stringify(cfg)); } catch (_) {}
    reupSetSavedBadge('Đang lưu...');
    if (_reupSaveTimer) clearTimeout(_reupSaveTimer);
    _reupSaveTimer = setTimeout(() => {
        reupSaveSettingsNow(false);
    }, 350);
}

async function reupLoadSavedSettings() {
    let loaded = null;
    try {
        const res = await fetch('/api/reup/settings');
        const data = await res.json();
        if (res.ok && data.success && data.settings && Object.keys(data.settings).length > 0) {
            loaded = data.settings;
        }
    } catch (_) {}

    if (!loaded) {
        try {
            const rawLs = localStorage.getItem(REUP_SETTINGS_LS_KEY);
            if (rawLs) loaded = JSON.parse(rawLs);
        } catch (_) {}
    }

    if (loaded && typeof loaded === 'object' && Object.keys(loaded).length > 0) {
        reupApplySavedSettings(loaded);
        reupSetSavedBadge('Đã khôi phục cài đặt', true);
    }
}

function reupOnMaxVideosFocus(el) {
    if (!el) return;
    if (el.dataset.mode === 'all' || !/^\d+$/.test(el.value.trim())) {
        setTimeout(() => { try { el.select(); } catch (_) {} }, 0);
    }
}

function reupOnMaxVideosTyped(el) {
    if (!el) return;
    const raw = el.value.trim();
    if (!raw) {
        el.dataset.mode = 'number';
        reupScheduleSaveSettings();
        return;
    }
    if (/^(?:tất\s*cả|tat\s*ca|all|toàn\s*kênh)$/i.test(raw)) {
        el.dataset.mode = 'all';
        reupScheduleSaveSettings();
        return;
    }
    const digits = raw.replace(/\D+/g, '');
    el.dataset.mode = 'number';
    if (digits !== raw) {
        el.value = digits;
    }
    reupScheduleSaveSettings();
}

function reupOnMaxVideosBlur(el) {
    if (!el) return;
    if (el.dataset.mode === 'all' || /^(?:tất\s*cả|tat\s*ca|all|toàn\s*kênh)$/i.test(el.value.trim())) {
        el.value = 'Tất cả';
        el.dataset.mode = 'all';
        reupScheduleSaveSettings();
        return;
    }
    const num = parseInt(el.value.replace(/\D+/g, ''), 10);
    if (!Number.isFinite(num) || num <= 0) {
        el.value = '30';
    } else if (num > 5000) {
        el.value = '5000';
    } else {
        el.value = String(num);
    }
    el.dataset.mode = 'number';
    reupScheduleSaveSettings();
}

function reupPickMaxVideos(val, skipSave = false) {
    const input = document.getElementById('reupMaxVideosInput');
    if (!input) return;
    if (val === 'all') {
        input.value = 'Tất cả';
        input.dataset.mode = 'all';
    } else {
        const n = Math.min(5000, Math.max(1, parseInt(val, 10) || 30));
        input.value = String(n);
        input.dataset.mode = 'number';
    }
    if (!skipSave) reupScheduleSaveSettings();
}

function reupGetRequestedMaxVideos() {
    const input = document.getElementById('reupMaxVideosInput');
    const raw = (input?.value || '').trim();
    if (input?.dataset.mode === 'all' || /^(?:tất\s*cả|tat\s*ca|all|toàn\s*kênh)$/i.test(raw)) {
        return 'all';
    }
    const parsed = parseInt(raw.replace(/\D+/g, ''), 10);
    if (Number.isFinite(parsed) && parsed > 0) {
        return Math.min(5000, parsed);
    }
    return 30;
}

function reupOnProductModeChange() {
    const mode = document.getElementById('reupProductMode')?.value || 'keep_original';
    const wrap = document.getElementById('reupCustomProductsWrap');
    if (!wrap) return;
    if (mode === 'replace_custom' || mode === 'merge_custom_first') {
        wrap.classList.remove('d-none');
    } else {
        wrap.classList.add('d-none');
    }
}

async function reupLoadTargetUsers() {
    const container = document.getElementById('reupTargetUsersList');
    if (!container) return;

    const prevChecked = new Set(
        Array.from(document.querySelectorAll('.reup-user-checkbox:checked')).map((el) => String(el.value))
    );

    try {
        const res = await fetch('/api/users?light=1');
        const users = await res.json();
        if (!Array.isArray(users) || users.length === 0) {
            container.innerHTML = '<div class="text-danger small">Chưa có tài khoản Shopee nào. Hãy thêm Cookie ở tab Quản Lý Người Dùng trước!</div>';
            reupUpdateSelectedUsersCount();
            return;
        }

        const hasSavedUsers = Array.isArray(_reupSavedTargetUserIds);
        const savedSet = hasSavedUsers ? new Set(_reupSavedTargetUserIds.map(String)) : null;
        const allowDefaultSelectAll = !hasSavedUsers && !_reupUsersInitialized && users.length <= 3;

        container.innerHTML = users.map((u) => {
            const uid = String(u.id);
            const isChecked = _reupUsersInitialized
                ? prevChecked.has(uid)
                : (hasSavedUsers ? savedSet.has(uid) : allowDefaultSelectAll);
            const checkedAttr = isChecked ? 'checked' : '';
            const statusHint = u.thread_error ? '<span class="badge border text-secondary bg-light ms-1">Lỗi luồng</span>' : '';
            const searchKey = reupEscapeHtml(`${u.username || ''} ${u.proxy || ''}`.toLowerCase());
            return `
                <div class="reup-user-row border-bottom" data-search="${searchKey}">
                    <label class="d-flex align-items-center justify-content-between py-1 px-1 w-100 mb-0" style="cursor:pointer;">
                        <span class="d-flex align-items-center gap-2">
                            <input type="checkbox" class="form-check-input m-0 reup-user-checkbox" value="${uid}" ${checkedAttr} onchange="reupUpdateSelectedUsersCount(); reupScheduleSaveSettings();">
                            <strong class="font-monospace">${reupEscapeHtml(u.username)}</strong>
                            ${statusHint}
                        </span>
                        <span class="text-muted small font-monospace">${reupEscapeHtml(u.proxy || 'IP máy')}</span>
                    </label>
                </div>
            `;
        }).join('');
        _reupUsersInitialized = true;
        reupFilterTargetUsers();
        reupUpdateSelectedUsersCount();
    } catch (err) {
        container.innerHTML = `<div class="text-danger small">Lỗi tải danh sách tài khoản: ${reupEscapeHtml(err.message)}</div>`;
    }
}

function reupFilterTargetUsers() {
    const q = (document.getElementById('reupUserFilterInput')?.value || '').trim().toLowerCase();
    document.querySelectorAll('.reup-user-row').forEach((row) => {
        const hay = row.getAttribute('data-search') || '';
        row.classList.toggle('d-none', Boolean(q && !hay.includes(q)));
    });
}

function reupUpdateSelectedUsersCount() {
    const cnt = document.querySelectorAll('.reup-user-checkbox:checked').length;
    const el = document.getElementById('reupSelectedUsersCount');
    if (el) el.textContent = String(cnt);
}

function reupSelectAllUsers(select) {
    const q = (document.getElementById('reupUserFilterInput')?.value || '').trim();
    const selector = q ? '.reup-user-row:not(.d-none) .reup-user-checkbox' : '.reup-user-checkbox';
    document.querySelectorAll(selector).forEach((cb) => {
        cb.checked = Boolean(select);
    });
    reupUpdateSelectedUsersCount();
    reupScheduleSaveSettings();
}

async function reupStartJob(targetMode) {
    const urlsText = (document.getElementById('reupChannelUrls')?.value || '').trim();
    if (!urlsText) {
        showToast('Vui lòng dán ít nhất 1 link Kênh hoặc Video Shopee ở Bước 1!', 'warning');
        return;
    }

    const targetUserIds = Array.from(document.querySelectorAll('.reup-user-checkbox:checked')).map((el) => Number(el.value));
    if (targetMode === 'push_to_threads' && targetUserIds.length === 0) {
        showToast('Vui lòng chọn ít nhất 1 Tài Khoản Shopee nhận đăng ở Bước 2!', 'warning');
        return;
    }

    reupSaveSettingsNow(false);

    const btnPush = document.getElementById('btnReupPushThreads');
    const btnExp = document.getElementById('btnReupExportExcel');
    if (btnPush) btnPush.disabled = true;
    if (btnExp) btnExp.disabled = true;

    try {
        const res = await fetch('/api/reup/start', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                urls: urlsText,
                maxVideos: reupGetRequestedMaxVideos(),
                minViews: Number(document.getElementById('reupMinViews')?.value || 0),
                onlyWithProducts: Boolean(document.getElementById('reupOnlyWithProducts')?.checked),
                skipAlreadyReupped: Boolean(document.getElementById('reupHideAlreadyReupped')?.checked),
                targetMode,
                processingMode: targetMode === 'export_excel' ? 'download_only' : 'full',
                targetUserIds,
                distributionMode: document.getElementById('reupDistributionMode')?.value || 'round_robin',
                presetMode: document.getElementById('reupFpPreset')?.value || 'standard',
                voiceMode: document.getElementById('reupVoiceMode')?.value || 'natural',
                mirrorFlip: Boolean(document.getElementById('reupMirrorFlip')?.checked),
                productMode: document.getElementById('reupProductMode')?.value || 'keep_original',
                customProductLinks: document.getElementById('reupCustomProductLinks')?.value || '',
                stripOldHashtags: Boolean(document.getElementById('reupStripOldHashtags')?.checked),
                prefixText: document.getElementById('reupPrefixCaption')?.value || '',
                appendHashtags: document.getElementById('reupAppendHashtags')?.value || '',
                delayMin: Number(document.getElementById('reupDelayMin')?.value || 60),
                delayMax: Number(document.getElementById('reupDelayMax')?.value || 180),
                autoStartThreads: Boolean(document.getElementById('reupAutoStartThreads')?.checked)
            })
        });
        const data = await res.json();
        if (!res.ok || !data.success) {
            throw new Error(data.error || 'Không thể khởi động tác vụ Reup');
        }

        _reupCurrentJobId = data.jobId;
        reupShowProgressPanel();
        reupPollJobStatus(data.jobId);
        showToast(
            targetMode === 'export_excel'
                ? 'Chế độ 2: Đang tải nhanh video gốc & xuất Excel chuẩn Tool Upload...'
                : 'Chế độ 1: Đang xử lý đầy đủ hình ảnh + âm thanh & đẩy luồng đăng...',
            'info'
        );
    } catch (err) {
        showToast(err.message, 'error');
        if (btnPush) btnPush.disabled = false;
        if (btnExp) btnExp.disabled = false;
    }
}

function reupShowProgressPanel() {
    const panel = document.getElementById('reupProgressPanel');
    if (panel) panel.classList.remove('d-none');
    const btnCancel = document.getElementById('btnReupCancelJob');
    if (btnCancel) btnCancel.classList.remove('d-none');
    const btnDl = document.getElementById('btnReupDownloadExcel');
    if (btnDl) btnDl.classList.add('d-none');
}

function reupRenderJob(job) {
    if (!job) return;
    const panel = document.getElementById('reupProgressPanel');
    if (panel) panel.classList.remove('d-none');

    const doneTotal = (job.completed || 0) + (job.failed || 0);
    const isScanningPhase = job.status === 'running' && (job.total || 0) === 0;
    const pct = job.total > 0 ? Math.min(100, Math.round((doneTotal / job.total) * 100)) : 0;

    const bar = document.getElementById('reupJobProgressBar');
    if (bar) {
        bar.style.width = isScanningPhase ? '100%' : `${pct}%`;
        bar.textContent = isScanningPhase ? 'Đang lấy danh sách video...' : `${pct}%`;
        if (job.status !== 'running') {
            bar.classList.remove('progress-bar-animated');
        } else {
            bar.classList.add('progress-bar-animated');
        }
    }

    const stepEl = document.getElementById('reupJobStepText');
    if (stepEl) stepEl.textContent = job.currentStep || '';

    const cntEl = document.getElementById('reupJobCounterText');
    if (cntEl) {
        cntEl.textContent = isScanningPhase
            ? 'Đang lấy danh sách...'
            : `Xong: ${job.completed || 0} / ${job.total || 0} | Lỗi: ${job.failed || 0}`;
    }

    const outEl = document.getElementById('reupJobOutputInfo');
    if (outEl) {
        outEl.textContent = job.outputDir ? `Thư mục lưu video: ${job.outputDir}` : '';
    }

    const tbody = document.getElementById('reupJobItemsBody');
    if (tbody && Array.isArray(job.items)) {
        tbody.innerHTML = job.items.map((it) => `
            <tr>
                <td>${it.index}</td>
                <td class="font-monospace">${reupEscapeHtml(it.post_id)}</td>
                <td class="fw-semibold">${reupEscapeHtml(it.target_username || '-')}</td>
                <td>${reupEscapeHtml(it.message || it.status)}</td>
            </tr>
        `).join('');
    }

    const btnCancel = document.getElementById('btnReupCancelJob');
    const btnDl = document.getElementById('btnReupDownloadExcel');
    const btnPush = document.getElementById('btnReupPushThreads');
    const btnExp = document.getElementById('btnReupExportExcel');

    if (job.status !== 'running') {
        if (btnCancel) btnCancel.classList.add('d-none');
        if (btnPush) btnPush.disabled = false;
        if (btnExp) btnExp.disabled = false;
        if (job.excelFile && btnDl) btnDl.classList.remove('d-none');
    } else {
        if (btnCancel) btnCancel.classList.remove('d-none');
    }
}

function reupPollJobStatus(jobId) {
    if (_reupPollTimer) clearInterval(_reupPollTimer);
    let lastQueued = -1;
    const tick = async () => {
        try {
            const res = await fetch(`/api/reup/jobs/${encodeURIComponent(jobId)}`);
            const data = await res.json();
            if (!data.success || !data.job) return;
            reupRenderJob(data.job);
            const curQueued = Number(data.job.queuedTasksCount || 0);
            if (curQueued !== lastQueued) {
                lastQueued = curQueued;
                if (typeof updateTaskStats === 'function') updateTaskStats();
                if (curQueued > 0 && typeof loadThreads === 'function') loadThreads(true);
            }
            if (data.job.status !== 'running') {
                clearInterval(_reupPollTimer);
                _reupPollTimer = null;
                if (typeof loadThreads === 'function') loadThreads(true);
                if (typeof updateTaskStats === 'function') updateTaskStats();
                if (data.job.status === 'completed') {
                    showToast(data.job.currentStep || 'Hoàn tất Reup Video!', 'success');
                }
            }
        } catch (_) {}
    };
    tick();
    _reupPollTimer = setInterval(tick, 1500);
}

async function reupCancelCurrentJob() {
    if (!_reupCurrentJobId) return;
    await fetch(`/api/reup/jobs/${encodeURIComponent(_reupCurrentJobId)}/cancel`, { method: 'POST' }).catch(() => {});
}

function reupDownloadJobExcel() {
    if (!_reupCurrentJobId) return;
    window.location.href = `/api/reup/jobs/${encodeURIComponent(_reupCurrentJobId)}/download-excel`;
}

document.addEventListener('DOMContentLoaded', async () => {
    const pane = document.getElementById('reup-content');
    if (pane) {
        const onFieldInteract = (e) => {
            const id = e?.target?.id || '';
            if (!id || id === 'reupUserFilterInput' || id === 'reupMaxVideosInput') return;
            reupScheduleSaveSettings();
        };
        pane.addEventListener('change', onFieldInteract);
        pane.addEventListener('input', (e) => {
            const id = e?.target?.id || '';
            if (!id || id === 'reupUserFilterInput' || id === 'reupMaxVideosInput') return;
            if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') {
                reupScheduleSaveSettings();
            }
        });
    }

    await reupLoadSavedSettings();
    await reupLoadTargetUsers();

    document.getElementById('reup-tab')?.addEventListener('shown.bs.tab', () => {
        reupLoadTargetUsers();
    });
});
