// Toast function
function showToast(message, type = 'info') {
  const toastEl = document.getElementById('liveToast');
  const toastBody = document.getElementById('toastMessage');
  if (!toastEl || !toastBody) return;
  const toast = new bootstrap.Toast(toastEl);

  toastEl.classList.remove('bg-success', 'bg-danger', 'bg-warning', 'bg-info');

  switch (type) {
    case 'success': toastEl.classList.add('bg-success', 'text-white'); break;
    case 'error': toastEl.classList.add('bg-danger', 'text-white'); break;
    case 'warning': toastEl.classList.add('bg-warning', 'text-dark'); break;
    default: toastEl.classList.add('bg-info', 'text-white');
  }

  toastBody.textContent = message;
  toast.show();
}

// Guard flags
let _fetchingThreads = false;
let _fetchingLogs = false;
let _fetchingTaskStats = false;

function isTabPaneActive(id) {
  const pane = document.getElementById(id);
  return Boolean(pane && (pane.classList.contains('active') || pane.classList.contains('show')));
}

// Periodic updates (chỉ cập nhật bảng đang hiển thị để tránh nghẽn DOM trình duyệt)
setInterval(() => {
  if (document.hidden) return;

  if (isTabPaneActive('threads-content') && !_fetchingThreads && typeof loadThreads === 'function') {
    _fetchingThreads = true;
    try { loadThreads(); } catch(e) {}
    setTimeout(() => { _fetchingThreads = false; }, 5000);
  }

  if (isTabPaneActive('logs-content') && !_fetchingLogs && typeof loadLogs === 'function') {
    _fetchingLogs = true;
    try { loadLogs(); } catch(e) {}
    setTimeout(() => { _fetchingLogs = false; }, 5000);
  }
}, 10000);

// Task stats polling
setInterval(() => {
  if (document.hidden) return;
  if (!isTabPaneActive('threads-content')) return;
  if (_fetchingTaskStats) return;
  _fetchingTaskStats = true;
  updateTaskStats().finally(() => { _fetchingTaskStats = false; });
}, 6000);

function updateTaskStats() {
  return fetch('/api/videos/task-stats')
    .then(res => res.json())
    .then(data => {
      if (!data.success) return;
      const s = data.stats;
      const el = (id) => document.getElementById(id);
      if (el('taskTotalCount')) el('taskTotalCount').textContent = s.total || 0;
      if (el('taskPendingCount')) el('taskPendingCount').textContent = s.pending || 0;
      if (el('taskUploadingCount')) el('taskUploadingCount').textContent = s.uploading || 0;
      if (el('taskCompletedCount')) el('taskCompletedCount').textContent = s.completed || 0;
      if (el('taskFailedCount')) el('taskFailedCount').textContent = s.failed || 0;
    })
    .catch(() => {});
}

// SERVER 3099 CONTROL & MONITORING
async function checkServer3099Status() {
    const badge = document.getElementById('server3099Badge');
    const badgeSub = document.getElementById('server3099BadgeSub');
    if (!badge && !badgeSub) return;
    const statusText = document.getElementById('server3099StatusText');
    const statusTextSub = document.getElementById('server3099StatusTextSub');
    const statusDot = document.getElementById('server3099StatusDot');
    const statusDotSub = document.getElementById('server3099StatusDotSub');

    try {
        const res = await fetch('/api/config/server-3099/status');
        const data = await res.json();
        if (data.running) {
            const deviceName = data.data?.device ? ` (${data.data.device})` : '';
            const isCloud = data.mode === 'CLOUD_DISCOVERY';
            const badgeLabel = isCloud ? '☁️ Cloud Signer (Online)' : '🟢 Online (Port 3099)';
            const textLabel = isCloud ? `Server 3099: Cloud Farm 20 Samsung (${data.pingMs || 0}ms)` : ('Server 3099: Active' + deviceName);

            if (badge) { badge.className = isCloud ? 'badge bg-info text-dark fw-bold' : 'badge bg-success'; badge.textContent = badgeLabel; }
            if (badgeSub) { badgeSub.className = isCloud ? 'badge bg-info text-dark fw-bold fs-6' : 'badge bg-success fs-6'; badgeSub.textContent = badgeLabel; }

            if (statusText) { statusText.className = isCloud ? 'text-info fw-bold' : 'text-success fw-bold'; statusText.textContent = textLabel; }
            if (statusTextSub) { statusTextSub.className = isCloud ? 'text-info fw-bold fs-6' : 'text-success fw-bold fs-6'; statusTextSub.textContent = textLabel; }

            if (statusDot) statusDot.className = 'spinner-grow spinner-grow-sm text-success me-2';
            if (statusDotSub) statusDotSub.className = 'spinner-grow spinner-grow-sm text-success me-2';
        } else {
            if (badge) { badge.className = 'badge bg-danger'; badge.textContent = '🔴 Offline (Chưa bật)'; }
            if (badgeSub) { badgeSub.className = 'badge bg-danger fs-6'; badgeSub.textContent = '🔴 Offline (Chưa bật)'; }

            if (statusText) { statusText.className = 'text-danger fw-bold'; statusText.textContent = 'Server 3099: Chưa Bật — Bấm "🚀 Bật Server 3099" để khởi động!'; }
            if (statusTextSub) { statusTextSub.className = 'text-danger fw-bold fs-6'; statusTextSub.textContent = 'Server 3099: Chưa Bật'; }

            if (statusDot) statusDot.className = 'spinner-grow spinner-grow-sm text-danger me-2';
            if (statusDotSub) statusDotSub.className = 'spinner-grow spinner-grow-sm text-danger me-2';
        }
    } catch (e) {
        if (badge) { badge.className = 'badge bg-danger'; badge.textContent = '🔴 Offline'; }
        if (badgeSub) { badgeSub.className = 'badge bg-danger fs-6'; badgeSub.textContent = '🔴 Offline'; }
    }
}

async function startServer3099() {
    const btn = document.getElementById('btnStart3099');
    const btnSub = document.getElementById('btnStart3099Sub');
    if (btn) { btn.disabled = true; btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span> Đang bật...'; }
    if (btnSub) { btnSub.disabled = true; btnSub.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span> Đang bật...'; }

    try {
        const res = await fetch('/api/config/server-3099/start', { method: 'POST' });
        const data = await res.json();
        if (data.success) {
            showToast(data.message || 'Khởi động Server 3099 thành công!', 'success');
            checkServer3099Status();
            fetchFridaTerminalLogs();
        } else {
            showToast(data.error || 'Lỗi khởi động Server 3099', 'error');
        }
    } catch (e) {
        showToast('Lỗi gửi lệnh bật Server 3099', 'error');
    } finally {
        if (btn) { btn.disabled = false; btn.innerHTML = '<i class="bi bi-play-circle-fill me-1"></i> 🚀 Bật Server 3099'; }
        if (btnSub) { btnSub.disabled = false; btnSub.innerHTML = '<i class="bi bi-play-circle-fill me-1"></i> 🚀 Bật Server 3099'; }
    }
}

async function stopServer3099() {
    if (!confirm('Bạn có chắc chắn muốn tắt Server 3099 không?')) return;
    try {
        const res = await fetch('/api/config/server-3099/stop', { method: 'POST' });
        const data = await res.json();
        if (data.success) {
            showToast(data.message || 'Đã dừng Server 3099!', 'success');
            checkServer3099Status();
            fetchFridaTerminalLogs();
        }
    } catch (e) {
        showToast('Lỗi tắt Server 3099', 'error');
    }
}

async function useServer3099Default() {
    try {
        const res = await fetch('/api/config/server-3099/set-default', { method: 'POST' });
        const data = await res.json();
        if (data.success) {
            showToast(data.message || 'Đã chọn Server 3099 làm mặc định bắn video!', 'success');
        }
    } catch (e) {
        showToast('Lỗi chọn Server 3099', 'error');
    }
}

async function fetchFridaTerminalLogs() {
    const term = document.getElementById('fridaTerminalLogs');
    if (!term) return;

    try {
        const res = await fetch('/api/config/server-3099/logs');
        const data = await res.json();
        if (data.success && Array.isArray(data.logs)) {
            const isScrolledToBottom = term.scrollHeight - term.clientHeight <= term.scrollTop + 60;
            term.textContent = data.logs.join('\n');
            if (isScrolledToBottom) {
                term.scrollTop = term.scrollHeight;
            }
        }
    } catch (e) {}
}

function clearFridaTerminalLogs() {
    const term = document.getElementById('fridaTerminalLogs');
    if (term) term.textContent = '[System] Màn hình log đã được xóa.';
}

// Tự động làm mới dữ liệu khi chuyển tab
document.addEventListener('DOMContentLoaded', () => {
    updateTaskStats();

    document.getElementById('threads-tab')?.addEventListener('shown.bs.tab', () => {
        if (typeof loadThreads === 'function') loadThreads(true);
        updateTaskStats();
    });

    document.getElementById('logs-tab')?.addEventListener('shown.bs.tab', () => {
        if (typeof loadLogs === 'function') loadLogs();
    });

    if (document.getElementById('server3099Badge') || document.getElementById('server3099BadgeSub')) {
        checkServer3099Status();
        setInterval(checkServer3099Status, 5000);
    }
    if (document.getElementById('fridaTerminalLogs')) {
        fetchFridaTerminalLogs();
        setInterval(fetchFridaTerminalLogs, 4000);
    }

    // Tự động kiểm tra bản cập nhật mới từ GitHub OTA
    setTimeout(() => checkClientOta(false), 1200);
    setInterval(() => checkClientOta(false), 300000);
});

// ══════════════════════════════════════════════════════════════════════════
// HỆ THỐNG CẬP NHẬT TỰ ĐỘNG OTA TỪ GITHUB (CLIENT PORT 6868)
// ══════════════════════════════════════════════════════════════════════════
let _latestClientOtaInfo = null;

function renderClientOtaState(info) {
    if (!info) return;
    _latestClientOtaInfo = info;

    const verBadge = document.getElementById('clientVersionBadge');
    if (verBadge && info.currentVersion) {
        verBadge.textContent = 'v' + info.currentVersion;
    }

    const btnNew = document.getElementById('btnClientNewUpdateBadge');
    const shortSpan = document.getElementById('clientNewVerShort');
    const banner = document.getElementById('clientOtaBanner');

    if (info.hasUpdate && info.latestVersion) {
        if (shortSpan) shortSpan.textContent = 'v' + info.latestVersion;
        if (btnNew) btnNew.classList.remove('d-none');
        if (banner) {
            banner.classList.remove('d-none');
            const bVer = document.getElementById('clientBannerNewVer');
            if (bVer) bVer.textContent = 'v' + info.latestVersion;
            const bNotes = document.getElementById('clientBannerNotes');
            if (bNotes) {
                bNotes.textContent = String(info.notes || 'Đã có phiên bản nâng cấp mới nhất từ hệ thống.').split('\n')[0];
            }
        }
    } else {
        if (btnNew) btnNew.classList.add('d-none');
        if (banner) banner.classList.add('d-none');
    }

    const el = (id) => document.getElementById(id);
    if (el('cliOtaCurVer')) el('cliOtaCurVer').textContent = 'v' + (info.currentVersion || '2.1.0');
    if (el('cliOtaLatestVer')) el('cliOtaLatestVer').textContent = 'v' + (info.latestVersion || info.currentVersion || '2.1.0');
    if (el('cliOtaSize')) {
        el('cliOtaSize').textContent = info.sizeBytes
            ? (info.sizeBytes / (1024 * 1024)).toFixed(2) + ' MB'
            : '~1.4 MB';
    }
    if (el('cliOtaNotesBox')) {
        el('cliOtaNotesBox').textContent = info.notes || 'Bản cập nhật tối ưu tốc độ, độ nét video ShopeeHD_v2 & ổn định mới nhất.';
    }
}

function openClientOtaModal() {
    if (_latestClientOtaInfo) renderClientOtaState(_latestClientOtaInfo);
    const modalEl = document.getElementById('clientOtaModal');
    if (!modalEl || typeof bootstrap === 'undefined') return;
    const m = bootstrap.Modal.getOrCreateInstance(modalEl);
    m.show();
}

async function checkClientOta(manual = false) {
    const btn = document.getElementById('btnCheckClientOta');
    if (manual && btn) {
        btn.disabled = true;
        btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span> Đang kiểm tra...';
    }
    try {
        const res = await fetch(manual ? '/api/ota/check' : '/api/ota/status', {
            method: manual ? 'POST' : 'GET'
        });
        const info = await res.json();
        renderClientOtaState(info);
        if (manual) {
            if (!info.ok) {
                showToast('Chưa kết nối được kho cập nhật (' + (info.error || 'Thử lại sau') + ')', 'warning');
            } else if (info.hasUpdate) {
                openClientOtaModal();
            } else {
                showToast(`Tool đang chạy phiên bản mới nhất (v${info.currentVersion})!`, 'success');
            }
        }
    } catch (err) {
        if (manual) showToast('Lỗi kiểm tra cập nhật: ' + err.message, 'error');
    } finally {
        if (manual && btn) {
            btn.disabled = false;
            btn.innerHTML = '<i class="bi bi-arrow-repeat me-1"></i> Kiểm tra cập nhật';
        }
    }
}

async function applyClientOtaUpdate() {
    openClientOtaModal();
    const targetVer = _latestClientOtaInfo?.latestVersion || 'mới';
    const btnConfirm = document.getElementById('btnConfirmClientOtaApply');
    const btnFast = document.getElementById('btnApplyClientOtaFast');
    const progWrap = document.getElementById('cliOtaProgressWrap');
    const progText = document.getElementById('cliOtaProgressText');

    if (btnConfirm) btnConfirm.disabled = true;
    if (btnFast) btnFast.disabled = true;
    if (progWrap) progWrap.classList.remove('d-none');
    if (progText) {
        progText.textContent = `⏳ Đang tải bản v${targetVer} từ GitHub, xác thực SHA-256 & sao lưu bảo vệ dữ liệu gốc...`;
    }

    try {
        const res = await fetch('/api/ota/apply', { method: 'POST' });
        const data = await res.json();
        if (!data.ok) {
            throw new Error(data.error || 'Không thể cài đặt bản cập nhật');
        }
        if (progText) {
            progText.textContent = `✅ Đã cài đặt v${data.newVersion}! Tool đang tự khởi động lại (~3 giây)... Giao diện sẽ tự làm mới ngay khi sẵn sàng.`;
        }
        let tries = 0;
        const pollTimer = setInterval(async () => {
            tries++;
            try {
                const hRes = await fetch('/api/health?t=' + Date.now());
                const hData = await hRes.json();
                if (hData && hData.status === 'ACTIVE' && (!data.newVersion || hData.version === data.newVersion || tries > 5)) {
                    clearInterval(pollTimer);
                    window.location.reload();
                }
            } catch (_) {}
            if (tries > 25) {
                clearInterval(pollTimer);
                window.location.reload();
            }
        }, 1500);
    } catch (err) {
        if (progText) progText.textContent = '❌ Lỗi cập nhật: ' + err.message;
        showToast('Lỗi cập nhật tự động: ' + err.message, 'error');
        if (btnConfirm) btnConfirm.disabled = false;
        if (btnFast) btnFast.disabled = false;
    }
}
