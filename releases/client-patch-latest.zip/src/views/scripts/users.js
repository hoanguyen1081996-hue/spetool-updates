// === Quản lý danh sách người dùng cuộn toàn bộ siêu mượt (0 hidden inputs, giữ vị trí cuộn, diff theo dòng) ===
window._allUsersList = Array.isArray(window.__INITIAL_USERS__) ? window.__INITIAL_USERS__ : [];
window._filteredUsersList = window._allUsersList.slice();
window._selectedUserIds = new Set();
window._renderedUserSigs = new Map();
window._renderedUserOrder = '';

function escapeUserHtml(str) {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function getSelectedUserIds() {
  if (window._selectedUserIds && window._selectedUserIds.size > 0) {
    return Array.from(window._selectedUserIds);
  }
  return Array.from(document.querySelectorAll('.user-checkbox:checked'))
    .map(cb => String(cb.dataset.userId))
    .filter(Boolean);
}

function updateSelectedUsersBadge() {
  const badge = document.getElementById('selectedUsersBadge');
  const total = window._allUsersList.length;
  const selectedCount = window._selectedUserIds.size;
  if (badge) {
    badge.textContent = `Đã chọn: ${selectedCount} / ${total}`;
    badge.className = selectedCount > 0
      ? 'badge bg-primary text-white ms-1'
      : 'badge bg-secondary-subtle text-dark border ms-1';
  }
  const selectAll = document.getElementById('selectAllUsers');
  if (selectAll) {
    const filtered = window._filteredUsersList || [];
    selectAll.checked = filtered.length > 0 && filtered.every(u => window._selectedUserIds.has(String(u.id)));
  }
}

function onUserCheckboxChange(cb) {
  const uid = String(cb.dataset.userId || '');
  if (!uid) return;
  if (cb.checked) {
    window._selectedUserIds.add(uid);
  } else {
    window._selectedUserIds.delete(uid);
  }
  window._renderedUserSigs.delete(uid);
  updateSelectedUsersBadge();
}

function filterAndRenderUsers() {
  const q = (document.getElementById('userSearchInput')?.value || '').trim().toLowerCase();
  if (!q) {
    window._filteredUsersList = window._allUsersList;
  } else {
    window._filteredUsersList = window._allUsersList.filter(u =>
      String(u.username || '').toLowerCase().includes(q) ||
      String(u.proxy || '').toLowerCase().includes(q) ||
      String(u.thread_error || '').toLowerCase().includes(q)
    );
  }
  renderUsersAll();
}

function buildUserRowHtml(user, rowNum) {
  const uidStr = String(user.id);
  const isChecked = window._selectedUserIds.has(uidStr) ? 'checked' : '';
  const unEsc = escapeUserHtml(user.username);
  const pxEsc = escapeUserHtml(user.proxy || '');
  const cookiePreview = escapeUserHtml(user.cookie_preview || (user.cookie ? user.cookie.substring(0, 48) + '...' : '-'));
  const errHtml = user.thread_error
    ? `<small class="text-danger log-error-cell d-inline-block" style="max-width:220px;" title="${escapeUserHtml(user.thread_error)}">${escapeUserHtml(user.thread_error)}</small>`
    : '<span class="text-muted">-</span>';

  return `<tr id="userRow_${uidStr}" data-user-id="${uidStr}" data-username="${unEsc}" data-proxy="${pxEsc}">
<td><div class="form-check form-switch mb-0"><input type="checkbox" class="form-check-input user-checkbox" data-user-id="${uidStr}" id="userCheckbox${uidStr}" ${isChecked} onchange="onUserCheckboxChange(this)"></div></td>
<td class="text-muted">${rowNum}</td>
<td><strong>${unEsc}</strong></td>
<td><code class="small text-muted text-truncate d-inline-block" style="max-width:260px;">${cookiePreview}</code></td>
<td id="proxyUserCell_${uidStr}"><span id="proxyUserDisplay_${uidStr}" class="d-flex align-items-center gap-1"><code class="small">${pxEsc || '-'}</code><button type="button" class="btn btn-sm p-0 text-primary" onclick="toggleEditUserProxy(${user.id})" title="Sửa proxy"><i class="bi bi-pencil-square" style="font-size:0.7rem"></i></button></span></td>
<td>${errHtml}</td>
<td class="text-nowrap"><button type="button" class="btn btn-sm btn-outline-primary" onclick="editUser(${user.id})" title="Sửa"><i class="bi bi-pencil"></i></button> <button type="button" class="btn btn-sm btn-outline-danger" onclick="confirmDeleteUser(${user.id})" title="Xóa"><i class="bi bi-trash3"></i></button></td>
</tr>`;
}

function getUserRowSig(user, rowNum) {
  const uidStr = String(user.id);
  const checked = window._selectedUserIds.has(uidStr) ? '1' : '0';
  return `${rowNum}|${checked}|${user.username || ''}|${user.cookie_preview || ''}|${user.proxy || ''}|${user.thread_error || ''}`;
}

function renderUsersAll() {
  const tbody = document.getElementById('usersTableBody');
  if (!tbody) return;

  if (document.activeElement && tbody.contains(document.activeElement) && /^(INPUT|SELECT|TEXTAREA)$/.test(document.activeElement.tagName)) {
    return;
  }

  const list = window._filteredUsersList || [];
  const totalAll = window._allUsersList.length;
  const totalFiltered = list.length;

  const infoEl = document.getElementById('userTotalInfo');
  if (infoEl) {
    infoEl.textContent = totalFiltered === totalAll
      ? `Tổng: ${totalAll} tài khoản`
      : `Đang lọc: ${totalFiltered} / ${totalAll} tài khoản`;
  }

  if (totalFiltered === 0) {
    tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted py-4">Chưa có người dùng nào phù hợp</td></tr>';
    window._renderedUserOrder = '';
    window._renderedUserSigs.clear();
    updateSelectedUsersBadge();
    return;
  }

  const orderKey = list.map(u => u.id).join(',');
  if (orderKey === window._renderedUserOrder && tbody.children.length === totalFiltered) {
    for (let i = 0; i < totalFiltered; i++) {
      const user = list[i];
      const uidStr = String(user.id);
      const sig = getUserRowSig(user, i + 1);
      if (window._renderedUserSigs.get(uidStr) !== sig) {
        const rowEl = document.getElementById('userRow_' + uidStr);
        if (rowEl) {
          rowEl.outerHTML = buildUserRowHtml(user, i + 1);
          window._renderedUserSigs.set(uidStr, sig);
        }
      }
    }
    updateSelectedUsersBadge();
    return;
  }

  const scrollBox = document.getElementById('usersScrollContainer');
  const prevScrollTop = scrollBox ? scrollBox.scrollTop : 0;

  const rowsHtml = new Array(totalFiltered);
  const nextSigs = new Map();
  for (let i = 0; i < totalFiltered; i++) {
    const user = list[i];
    const uidStr = String(user.id);
    rowsHtml[i] = buildUserRowHtml(user, i + 1);
    nextSigs.set(uidStr, getUserRowSig(user, i + 1));
  }

  tbody.innerHTML = rowsHtml.join('');
  window._renderedUserOrder = orderKey;
  window._renderedUserSigs = nextSigs;
  if (scrollBox && prevScrollTop > 0) {
    scrollBox.scrollTop = prevScrollTop;
  }
  updateSelectedUsersBadge();
}

// === User proxy inline edit (khởi tạo ô input theo yêu cầu, không tạo sẵn hàng nghìn DOM ẩn) ===
function toggleEditUserProxy(userId, currentProxy) {
  const userObj = window._allUsersList.find(u => String(u.id) === String(userId));
  const proxyVal = currentProxy !== undefined ? currentProxy : (userObj?.proxy || '');
  const cell = document.getElementById('proxyUserCell_' + userId);
  const displayEl = document.getElementById('proxyUserDisplay_' + userId);
  if (displayEl) displayEl.classList.add('d-none');

  let editEl = document.getElementById('proxyUserEdit_' + userId);
  if (!editEl && cell) {
    editEl = document.createElement('div');
    editEl.id = 'proxyUserEdit_' + userId;
    editEl.innerHTML = `<div class="input-group input-group-sm">
      <input type="text" class="form-control form-control-sm" id="proxyUserInput_${userId}" placeholder="IP:PORT:USER:PASS">
      <button type="button" class="btn btn-success btn-sm" onclick="saveUserProxy(${userId})"><i class="bi bi-check"></i></button>
      <button type="button" class="btn btn-secondary btn-sm" onclick="cancelEditUserProxy(${userId})"><i class="bi bi-x"></i></button>
    </div>`;
    cell.appendChild(editEl);
  } else if (editEl) {
    editEl.classList.remove('d-none');
  }

  const inputEl = document.getElementById('proxyUserInput_' + userId);
  if (inputEl) {
    inputEl.value = proxyVal || '';
    inputEl.focus();
  }
}

function cancelEditUserProxy(userId) {
  const displayEl = document.getElementById('proxyUserDisplay_' + userId);
  const editEl = document.getElementById('proxyUserEdit_' + userId);
  if (displayEl) displayEl.classList.remove('d-none');
  if (editEl) editEl.remove();
}

function saveUserProxy(userId) {
  const inputEl = document.getElementById('proxyUserInput_' + userId);
  const proxy = inputEl ? inputEl.value.trim() : '';
  fetch(`/api/users/${userId}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ proxy }),
  })
    .then(res => res.json())
    .then(data => {
      if (data.success) {
        showToast('Cập nhật proxy thành công', 'success');
        loadUsers();
      } else {
        showToast(data.message || 'Lỗi', 'error');
      }
    })
    .catch(() => showToast('Lỗi kết nối', 'error'));
}

function exportUsersJson() {
  const a = document.createElement('a');
  a.href = '/api/users/export-json';
  a.download = '';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  showToast('Đang tải file JSON...', 'success');
}

function showImportJsonModal() {
  const modal = new bootstrap.Modal(document.getElementById('importJsonModal'));
  modal.show();
}

function showAddModal() {
  const modal = new bootstrap.Modal(document.getElementById('addModal'));
  modal.show();
}

function editUser(id, username, cookie, proxy) {
  const userObj = window._allUsersList.find(u => String(u.id) === String(id));
  const modal = new bootstrap.Modal(document.getElementById('editModal'));
  document.getElementById('editForm').action = `/users/${id}`;
  document.getElementById('editUsername').value = username !== undefined ? username : (userObj?.username || '');
  document.getElementById('editCookie').value = cookie || '';
  document.getElementById('editProxy').value = proxy !== undefined ? proxy : (userObj?.proxy || '');
  modal.show();
  if (!cookie) {
    fetch(`/api/users/${id}`)
      .then(r => r.json())
      .then(found => {
        if (found && found.cookie) {
          document.getElementById('editCookie').value = found.cookie;
        }
      })
      .catch(() => {});
  }
}

function showImportModal() {
  const modal = new bootstrap.Modal(document.getElementById('importModal'));
  modal.show();
}

function showBulkThreadModal() {
  const selectedIds = getSelectedUserIds();
  if (selectedIds.length === 0) {
    showToast('Vui lòng chọn ít nhất một người dùng', 'warning');
    return;
  }
  const modal = new bootstrap.Modal(document.getElementById('bulkThreadModal'));
  modal.show();
}

function toggleAllUsers(checkbox) {
  const filtered = window._filteredUsersList || [];
  if (checkbox.checked) {
    filtered.forEach(u => window._selectedUserIds.add(String(u.id)));
  } else {
    filtered.forEach(u => window._selectedUserIds.delete(String(u.id)));
  }
  window._renderedUserSigs.clear();
  const userCheckboxes = document.querySelectorAll('.user-checkbox:not(:disabled)');
  userCheckboxes.forEach((box) => {
    box.checked = checkbox.checked;
  });
  updateSelectedUsersBadge();
}

// Xóa các tài khoản đã tích chọn
function deleteSelectedUsers() {
  const ids = getSelectedUserIds();

  if (ids.length === 0) {
    showToast('Vui lòng chọn ít nhất một tài khoản', 'warning');
    return;
  }
  if (!confirm(`Bạn có chắc muốn xóa ${ids.length} tài khoản đã chọn không?`)) {
    return;
  }
  fetch('/api/users/bulk-delete', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
    body: JSON.stringify({ ids }),
  })
    .then((res) => res.json())
    .then((data) => {
      if (data.success) {
        ids.forEach(id => window._selectedUserIds.delete(String(id)));
        const selectAll = document.getElementById('selectAllUsers');
        if (selectAll) selectAll.checked = false;
        loadUsers();
        loadThreads();
        showToast(data.message || `Đã xóa ${data.deleted} tài khoản`, 'success');
      } else {
        showToast(data.message || 'Xóa không thành công', 'error');
      }
    })
    .catch(() => showToast('Lỗi khi xóa tài khoản', 'error'));
}

// Xóa TẤT CẢ tài khoản
function deleteAllUsers() {
  if (!confirm('XÓA TẤT CẢ tài khoản? Hành động này KHÔNG THỂ hoàn tác!')) {
    return;
  }
  fetch('/api/users/bulk-delete', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
    body: JSON.stringify({ all: true }),
  })
    .then((res) => res.json())
    .then((data) => {
      if (data.success) {
        window._selectedUserIds.clear();
        const selectAll = document.getElementById('selectAllUsers');
        if (selectAll) selectAll.checked = false;
        loadUsers();
        loadThreads();
        showToast(data.message || `Đã xóa ${data.deleted} tài khoản`, 'success');
      } else {
        showToast(data.message || 'Xóa không thành công', 'error');
      }
    })
    .catch(() => showToast('Lỗi khi xóa tài khoản', 'error'));
}

function confirmDeleteUser(userId) {
  if (confirm('Bạn có chắc chắn muốn xóa người dùng này không?')) {
    fetch(`/api/users/${userId}`, {
      method: 'DELETE',
      headers: {
        Accept: 'application/json',
      },
    })
      .then((response) => {
        if (!response.ok) {
          throw new Error('Phản hồi mạng không thành công');
        }
        return response.json();
      })
      .then((data) => {
        if (data.success) {
          window._selectedUserIds.delete(String(userId));
          loadUsers();
          loadThreads();
          showToast('Xóa người dùng thành công', 'success');
        } else {
          showToast(data.message || 'Xóa người dùng không thành công', 'error');
        }
      })
      .catch((error) => {
        console.error('Error:', error);
        showToast('Lỗi khi xóa người dùng', 'error');
      });
  }
  return false;
}

let _loadingUsersPromise = null;
function loadUsers() {
  if (_loadingUsersPromise) return _loadingUsersPromise;
  _loadingUsersPromise = fetch('/api/users?light=1')
    .then((response) => response.json())
    .then((users) => {
      if (!Array.isArray(users)) return;
      window._allUsersList = users;
      const validSet = new Set(users.map(u => String(u.id)));
      for (const id of Array.from(window._selectedUserIds)) {
        if (!validSet.has(id)) window._selectedUserIds.delete(id);
      }
      filterAndRenderUsers();

      // Update the user select dropdown in the thread creation modal
      const userSelect = document.getElementById('userSelectForThread');
      if (userSelect) {
        userSelect.innerHTML = '<option value="">Select user</option>' +
          users.map(u => `<option value="${u.id}">${escapeUserHtml(u.username)}</option>`).join('');
      }
    })
    .catch((error) => {
      console.error('Error:', error);
      showToast('Tải lại danh sách người dùng không thành công', 'error');
    })
    .finally(() => {
      _loadingUsersPromise = null;
    });
  return _loadingUsersPromise;
}

function updateUserTableDeleteButtons() {
  // No-op: nút xóa đã gắn onclick trực tiếp
}

// Event Listeners for User Management
document.addEventListener('DOMContentLoaded', () => {
  // Khởi tạo bảng người dùng cuộn toàn bộ ngay khi mở trang
  filterAndRenderUsers();

  // Lazy-load danh sách user vào dropdown khi mở modal Tạo Luồng Mới
  document.getElementById('createThreadModal')?.addEventListener('show.bs.modal', () => {
    const userSelect = document.getElementById('userSelectForThread');
    if (userSelect && userSelect.options.length <= 1 && window._allUsersList.length > 0) {
      userSelect.innerHTML = '<option value="">Select user</option>' +
        window._allUsersList.map(u => `<option value="${u.id}">${escapeUserHtml(u.username)}</option>`).join('');
    }
  });

  // Add user form submission
  document
    .querySelector('form[action="/users"]')
    ?.addEventListener('submit', function (event) {
      event.preventDefault();
      const formData = new FormData(this);

      fetch('/api/users', {
        method: 'POST',
        body: JSON.stringify({
          username: formData.get('username'),
          cookie: formData.get('cookie'),
          proxy: formData.get('proxy') || '',
        }),
        headers: {
          'Content-Type': 'application/json',
        },
      })
        .then((response) => response.json())
        .then((data) => {
          if (data.success) {
            loadUsers();
            showToast(data.message, 'success');
            const modal = bootstrap.Modal.getInstance(
              document.getElementById('addModal')
            );
            modal?.hide();
          } else {
            showToast(data.message, 'error');
          }
        })
        .catch((error) => {
          console.error('Error:', error);
          showToast('Đã xảy ra lỗi', 'error');
        });
    });

  // Edit user form submission
  document
    .getElementById('editForm')
    ?.addEventListener('submit', function (event) {
      event.preventDefault();
      const userId = this.action.split('/').pop();
      const formData = new FormData(this);

      fetch(`/api/users/${userId}`, {
        method: 'PUT',
        body: JSON.stringify({
          username: formData.get('username'),
          cookie: formData.get('cookie'),
          proxy: formData.get('proxy') || '',
        }),
        headers: {
          'Content-Type': 'application/json',
        },
      })
        .then((response) => response.json())
        .then((data) => {
          if (data.success) {
            loadUsers();
            showToast(data.message, 'success');
            const modal = bootstrap.Modal.getInstance(
              document.getElementById('editModal')
            );
            modal?.hide();
          } else {
            showToast(data.message, 'error');
          }
        })
        .catch((error) => {
          console.error('Error:', error);
          showToast('Đã xảy ra lỗi', 'error');
        });
    });

  // Import users form submission
  document
    .getElementById('importForm')
    ?.addEventListener('submit', function (event) {
      event.preventDefault();

      const formData = new FormData(this);

      fetch('/api/users/import', {
        method: 'POST',
        body: formData,
      })
        .then((response) => response.json())
        .then((data) => {
          if (data.success) {
            showToast(
              `Đã nhập ${data.results.successful} người dùng (bỏ qua ${data.results.skipped})`,
              'success'
            );
            loadUsers();
            const modal = bootstrap.Modal.getInstance(
              document.getElementById('importModal')
            );
            modal?.hide();
          } else {
            showToast(data.message, 'error');
          }
        })
        .catch((error) => {
          console.error('Error:', error);
          showToast('Đã xảy ra lỗi trong quá trình nhập', 'error');
        });
    });

  // Bulk thread creation (1 request batch duy nhất thay vì bắn 500 request làm đơ trình duyệt)
  document
    .getElementById('bulkThreadForm')
    ?.addEventListener('submit', async function (event) {
      event.preventDefault();

      const selectedUsers = getSelectedUserIds();
      if (selectedUsers.length === 0) {
        showToast('Vui lòng chọn ít nhất một người dùng', 'warning');
        return;
      }

      const delay_min = parseInt(document.getElementById('bulkDelayMin').value, 10) || 60;
      const delay_max = parseInt(document.getElementById('bulkDelayMax').value, 10) || 180;
      const count_video_upload = parseInt(
        document.getElementById('bulkVideoCount').value,
        10
      );
      const proxy = document.getElementById('bulkProxy').value || null;
      const upload_mode = document.getElementById('bulkUploadMode').value;
      const auto_fill_products = document.getElementById('bulkAutoFillProducts').checked;
      const country = document.getElementById('bulkCountry')?.value || 'vn';

      try {
        const res = await fetch('/api/threads/bulk-create', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userIds: selectedUsers.map(Number),
            delay_min,
            delay_max,
            proxy,
            count_video_upload,
            upload_mode,
            auto_fill_products,
            country,
          }),
        });
        const data = await res.json();
        if (!res.ok || data.error) {
          throw new Error(data.error || 'Lỗi tạo luồng hàng loạt');
        }

        loadUsers();
        loadThreads();
        const modal = bootstrap.Modal.getInstance(
          document.getElementById('bulkThreadModal')
        );
        modal?.hide();
        showToast(`Đã tạo ${data.created || 0} luồng thành công${data.skipped ? ` (bỏ qua ${data.skipped} đã tồn tại)` : ''}`, 'success');
      } catch (error) {
        console.error('Error:', error);
        showToast(error.message || 'Lỗi khi tạo luồng hàng loạt', 'error');
      }
    });

  // Import JSON form
  document.getElementById('importJsonForm')?.addEventListener('submit', function (event) {
    event.preventDefault();
    const formData = new FormData(this);

    fetch('/api/users/import-json', { method: 'POST', body: formData })
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          showToast(data.message, 'success');
          loadUsers();
          bootstrap.Modal.getInstance(document.getElementById('importJsonModal'))?.hide();
        } else {
          showToast(data.message || 'Lỗi nhập JSON', 'error');
        }
      })
      .catch(() => showToast('Lỗi nhập JSON', 'error'));
  });
});
