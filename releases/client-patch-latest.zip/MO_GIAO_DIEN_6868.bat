@echo off
setlocal
cd /d "%~dp0"

if /I "%~1"=="WAIT_READY" goto :WAIT_PORT

netstat -aon | findstr ":6868 " | findstr "LISTENING" >nul 2>&1
if errorlevel 1 (
    start "" cmd /c "%~dp0CHAY_TOOL.bat"
    exit /b 0
)
goto :OPEN_UI

:WAIT_PORT
for /L %%i in (1,1,25) do (
    netstat -aon | findstr ":6868 " | findstr "LISTENING" >nul 2>&1
    if not errorlevel 1 goto :OPEN_UI
    ping 127.0.0.1 -n 2 >nul
)

:OPEN_UI
set "PROFILE_DIR=%~dp0data\ui_profile"
if not exist "%PROFILE_DIR%" mkdir "%PROFILE_DIR%" >nul 2>&1

if exist "C:\Program Files\Google\Chrome\Application\chrome.exe" (
    start "" "C:\Program Files\Google\Chrome\Application\chrome.exe" --app=http://127.0.0.1:6868 "--user-data-dir=%PROFILE_DIR%" --no-first-run --no-default-browser-check --hide-crash-restore-bubble --disable-extensions --no-proxy-server --disable-background-timer-throttling --disable-features=Translate --window-size=1440,900
    exit /b 0
)
if exist "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" (
    start "" "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" --app=http://127.0.0.1:6868 "--user-data-dir=%PROFILE_DIR%" --no-first-run --no-default-browser-check --hide-crash-restore-bubble --disable-extensions --no-proxy-server --disable-background-timer-throttling --disable-features=Translate --window-size=1440,900
    exit /b 0
)
if exist "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" (
    start "" "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" --app=http://127.0.0.1:6868 "--user-data-dir=%PROFILE_DIR%" --no-first-run --no-default-browser-check --hide-crash-restore-bubble --disable-extensions --no-proxy-server --window-size=1440,900
    exit /b 0
)
if exist "C:\Program Files\Microsoft\Edge\Application\msedge.exe" (
    start "" "C:\Program Files\Microsoft\Edge\Application\msedge.exe" --app=http://127.0.0.1:6868 "--user-data-dir=%PROFILE_DIR%" --no-first-run --no-default-browser-check --hide-crash-restore-bubble --disable-extensions --no-proxy-server --window-size=1440,900
    exit /b 0
)
start http://127.0.0.1:6868
exit /b 0
