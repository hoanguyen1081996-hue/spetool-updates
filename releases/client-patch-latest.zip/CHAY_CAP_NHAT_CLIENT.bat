@echo off
reg add HKCU\Console /v QuickEdit /t REG_DWORD /d 0 /f >nul 2>&1
cd /d "%~dp0"
echo ===================================================================
echo   TU DONG CAP NHAT TRIET DE TOOL UPLOAD CLIENT (PORT 6868)
echo ===================================================================

echo [1/3] Dang dung tien trinh Tool Upload Client cu (Port 6868)...
taskkill /f /fi "WINDOWTITLE eq SHOPEE_UPLOAD_6868_RUNNER*" /t >nul 2>&1
for /f "tokens=5" %%a in ('netstat -aon ^| findstr ":6868 " ^| findstr "LISTENING" 2^>nul') do (
    if not "%%a"=="0" taskkill /f /t /pid %%a >nul 2>&1
)
ping 127.0.0.1 -n 3 >nul

if exist "tooluploadlocal" (
    rmdir /S /Q "tooluploadlocal" >nul 2>&1
)

if exist "node_modules" goto START_NOW
if exist "..\node_modules" goto COPY_TO_PARENT_1
if exist "..\..\node_modules" goto COPY_TO_PARENT_2
if exist "..\src\start.js" goto COPY_TO_PARENT_1
if exist "..\..\src\start.js" goto COPY_TO_PARENT_2
goto START_NOW

:COPY_TO_PARENT_1
echo [2/3] Dang cap nhat vao thu muc goc Tool Upload (1 cap - Bao toan 100%% Du lieu goc)...
if exist "src" xcopy /E /Y /I "src" "..\src" >nul
if exist "public" xcopy /E /Y /I "public" "..\public" >nul
if exist "app.js" copy /Y "app.js" "..\app.js" >nul 2>&1
if exist "index.js" copy /Y "index.js" "..\index.js" >nul 2>&1
if exist "version.json" copy /Y "version.json" "..\version.json" >nul 2>&1
if exist "CHAY_TOOL.bat" copy /Y "CHAY_TOOL.bat" "..\CHAY_TOOL.bat" >nul 2>&1
if exist "MO_GIAO_DIEN_6868.bat" copy /Y "MO_GIAO_DIEN_6868.bat" "..\MO_GIAO_DIEN_6868.bat" >nul 2>&1
copy /Y "%~f0" "..\CHAY_CAP_NHAT_CLIENT.bat" >nul 2>&1
cd /d ".."
goto START_NOW

:COPY_TO_PARENT_2
echo [2/3] Dang cap nhat vao thu muc goc Tool Upload (2 cap - Bao toan 100%% Du lieu goc)...
if exist "src" xcopy /E /Y /I "src" "..\..\src" >nul
if exist "public" xcopy /E /Y /I "public" "..\..\public" >nul
if exist "app.js" copy /Y "app.js" "..\..\app.js" >nul 2>&1
if exist "index.js" copy /Y "index.js" "..\..\index.js" >nul 2>&1
if exist "version.json" copy /Y "version.json" "..\..\version.json" >nul 2>&1
if exist "CHAY_TOOL.bat" copy /Y "CHAY_TOOL.bat" "..\..\CHAY_TOOL.bat" >nul 2>&1
if exist "MO_GIAO_DIEN_6868.bat" copy /Y "MO_GIAO_DIEN_6868.bat" "..\..\MO_GIAO_DIEN_6868.bat" >nul 2>&1
copy /Y "%~f0" "..\..\CHAY_CAP_NHAT_CLIENT.bat" >nul 2>&1
cd /d "..\.."
goto START_NOW

:START_NOW
echo [3/3] Dang khoi dong lai Tool Upload Client (Port 6868) tu: %CD%
if exist "CHAY_TOOL.bat" (
    start "" cmd /c call "%CD%\CHAY_TOOL.bat"
) else (
    start "SHOPEE_UPLOAD_6868_RUNNER" cmd /k "node src/start.js"
)
echo.
echo [HOAN TAT] Da cap nhat va khoi dong lai Tool Upload Client thanh cong!
ping 127.0.0.1 -n 4 >nul
