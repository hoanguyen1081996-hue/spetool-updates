@echo off
title SHOPEE SIGNATURE SERVER - AUTO-SCALE MULTI-BOX FARM (ALL CONNECTED PHONES)
cd /d "%~dp0"
:: Vo hieu hoa QuickEdit Mode cua Windows CMD de click chuot vao cua so khong bao gio lam dung Server
reg add HKCU\Console /v QuickEdit /t REG_DWORD /d 0 /f >nul 2>&1

:: Neu nguoi dung chay nham tu thu muc con giai nen (khong co node_modules nhung thu muc cha co node_modules) -> Tu dong copy de len thu muc cha va chuyen ra thu muc cha
if not exist "node_modules" (
    if exist "..\node_modules" (
        echo [*] Phat hien dang chay trong thu muc con giai nen, tu dong dong bo ra thu muc goc...
        if exist "src" xcopy /E /Y /I "src" "..\src" >nul 2>&1
        if exist "config" xcopy /E /Y /I "config" "..\config" >nul 2>&1
        if exist "supervisor-3099.js" copy /Y "supervisor-3099.js" "..\supervisor-3099.js" >nul 2>&1
        copy /Y "%~f0" "..\START_SERVER_20BOX.bat" >nul 2>&1
        cd /d ".."
    )
)
cls
echo ===================================================================
echo   SHOPEE STANDALONE SIGNATURE SERVER - AUTO-SCALE MULTI-BOX FARM
echo   Tu Dong: Quet Tat Ca Cong ADB - Kich Hoat Frida Moi May - Cloud Tunnel
echo ===================================================================
echo.

:: 1. KHOI DONG ADB SERVER & LIET KE TAT CA MAY DANG KET NOI (5037 & 5038)
set ADB_BIN=platform-tools\adb.exe
if not exist "%ADB_BIN%" set ADB_BIN=..\platform-tools\adb.exe
if not exist "%ADB_BIN%" set ADB_BIN=adb.exe

echo [1/4] Dang kiem tra va khoi dong ADB...
"%ADB_BIN%" start-server >nul 2>&1
echo [1/4] Danh sach Boxphone dang ket noi (Cong ADB 5037):
"%ADB_BIN%" -P 5037 devices
echo [1/4] Kiem tra cong ADB phu 5038 (Xiaowei / Box 2):
"%ADB_BIN%" -P 5038 devices 2>nul
echo.

:: 2. GIAI PHONG PORT 3099 CU VA DONG CAC SUPERVISOR CU NEU DANG CHAY NGAM
echo [2/4] Dang giai phong cong 3099 va don sach tien trinh Server cu...
powershell -NoProfile -Command "Get-CimInstance Win32_Process -Filter \"Name='node.exe'\" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -match 'supervisor-3099|src[\\/]server\.js|tls-relay-worker' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }" >nul 2>&1
for /f "tokens=5" %%a in ('netstat -aon 2^>nul ^| findstr :3099 ^| findstr LISTENING') do taskkill /f /t /pid %%a >nul 2>&1

:: 3. TIM KIEM NODE.JS TREN HE THONG (UU TIEN NODE.EXE PORTABLE TRONG THU MUC)
echo [3/4] Dang kiem tra Node.js Engine...
set "NODE_EXE=node"

if exist "%~dp0node.exe" (
    set "NODE_EXE=%~dp0node.exe"
    goto :node_ready_srv
)
if exist "C:\Program Files\nodejs\node.exe" (
    set "NODE_EXE=C:\Program Files\nodejs\node.exe"
    set "PATH=%PATH%;C:\Program Files\nodejs"
    goto :node_ready_srv
)
where node >nul 2>nul
if %ERRORLEVEL% EQU 0 goto :node_ready_srv

if exist "C:\Program Files (x86)\nodejs\node.exe" (
    set "NODE_EXE=C:\Program Files (x86)\nodejs\node.exe"
    set "PATH=%PATH%;C:\Program Files (x86)\nodejs"
    goto :node_ready_srv
)
if exist "CAI_DAT_NODEJS_TU_DONG.bat" (
    echo.
    echo [!] May chua co Node.js. Dang tien hanh cai dat tu dong...
    call CAI_DAT_NODEJS_TU_DONG.bat AUTO
    if exist "C:\Program Files\nodejs\node.exe" (
        set "NODE_EXE=C:\Program Files\nodejs\node.exe"
        set "PATH=%PATH%;C:\Program Files\nodejs;C:\Users\%USERNAME%\AppData\Roaming\npm"
    )
)

:node_ready_srv
echo [*] Node.js da san sang: %NODE_EXE%

:: 4. THIET LAP CAU HINH CHIU TAI & CLOUDFLARE TUNNEL (6 BOX = 120 MAY | 4000 REQUEST KY MA DONG THOI)
set UV_THREADPOOL_SIZE=128
set ENABLE_CLOUD_TUNNEL=true
set MAX_WORKERS=150
set MAX_CONCURRENT_SIGN_REQUESTS=4000
set MAX_CONCURRENT_PER_CLIENT=500
set SIG_PORT=3099
set NODE_PATH=%~dp0node_modules

echo [4/4] Dang khoi chay Server 3099 (Quy mo 6 Box / 120 Thiet bi - 4000 Users)...
echo ===================================================================
echo   - Giao dien Quan tri Web (API Key, Goi, Thong ke): http://localhost:3099/
echo   - Tu dong quet 8 cong ADB (5037..5044) cho 6 Box (120+ thiet bi)
echo   - Chia luong da ken, can doi hien thi log chong lag CMD ^& Web UI
echo   - Ho tro Ten Mien Rieng ^& Cloudflare Tunnel phat ket noi Internet
echo ===================================================================
echo.

start "" cmd /c "timeout /t 4 >nul & start http://localhost:3099/"
"%NODE_EXE%" supervisor-3099.js

echo.
echo ===================================================================
echo   Server da dung lai.
echo ===================================================================
pause
