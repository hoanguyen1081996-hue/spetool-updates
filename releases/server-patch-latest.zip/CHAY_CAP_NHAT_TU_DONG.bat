@echo off
chcp 65001 >nul
cd /d "%~dp0"
reg add HKCU\Console /v QuickEdit /t REG_DWORD /d 0 /f >nul 2>&1
echo ===================================================================
echo   TU DONG CAP NHAT TRIET DE BAN VA SERVER 55 MAY (PORT 3099)
echo   (Giu nguyen 100%% danh sach API Key ^& so du Credit cua khach)
echo ===================================================================

echo [1/3] Dang dung triet de toan bo tien trinh Server 3099 ^& Supervisor cu...
powershell -NoProfile -Command "$conns = Get-NetTCPConnection -LocalPort 3099 -State Listen -ErrorAction SilentlyContinue; foreach ($c in $conns) { $proc = Get-CimInstance Win32_Process -Filter \"ProcessId=$($c.OwningProcess)\" -ErrorAction SilentlyContinue; if ($proc -and $proc.ParentProcessId) { taskkill /F /T /PID $proc.ParentProcessId 2>$null }; taskkill /F /T /PID $c.OwningProcess 2>$null }; Get-CimInstance Win32_Process -Filter \"Name='node.exe'\" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -match 'supervisor-3099|server\.js|tls-relay-worker' } | ForEach-Object { taskkill /F /T /PID $_.ProcessId 2>$null }" >nul 2>&1
for /f "tokens=5" %%a in ('netstat -aon 2^>nul ^| findstr :3099 ^| findstr LISTENING') do taskkill /f /t /pid %%a >nul 2>&1
taskkill /F /IM cloudflared.exe >nul 2>&1
timeout /t 2 /nobreak >nul

:: Xoa thu muc con standalone-signature-server cu (neu ton tai tu ban nen cu) de tranh ghi de nguoc file cu!
if exist "standalone-signature-server" (
    rmdir /S /Q "standalone-signature-server" >nul 2>&1
)

:: Tuyet doi khong ghi de api_keys.json tu ban va len du lieu that cua Server!
if exist "config\api_keys.json" if exist "..\config\api_keys.json" del /F /Q "config\api_keys.json" >nul 2>&1
if exist "config\api_keys.backup.json" if exist "..\config\api_keys.backup.json" del /F /Q "config\api_keys.backup.json" >nul 2>&1
if exist "config\api_keys.json" if exist "..\..\config\api_keys.json" del /F /Q "config\api_keys.json" >nul 2>&1
if exist "config\api_keys.backup.json" if exist "..\..\config\api_keys.backup.json" del /F /Q "config\api_keys.backup.json" >nul 2>&1
if exist "config\admin_auth.json" if exist "..\config\admin_auth.json" del /F /Q "config\admin_auth.json" >nul 2>&1
if exist "config\admin_auth.json" if exist "..\..\config\admin_auth.json" del /F /Q "config\admin_auth.json" >nul 2>&1

:: Kiem tra neu dang dung trong thu muc con giai nen 1 cap (..) hoac 2 cap (..\..)
if exist "node_modules" goto :START_NOW
if exist "..\node_modules" goto :COPY_TO_PARENT_1
if exist "..\..\node_modules" goto :COPY_TO_PARENT_2
if exist "..\src\server.js" goto :COPY_TO_PARENT_1
if exist "..\..\src\server.js" goto :COPY_TO_PARENT_2
goto :START_NOW

:COPY_TO_PARENT_1
echo [2/3] Phat hien giai nen ra thu muc con (1 cap), dang cap nhat de vao thu muc goc Server...
if exist "src" xcopy /E /Y /I "src" "..\src" >nul
if exist "server.js" copy /Y "server.js" "..\server.js" >nul
if exist "supervisor-3099.js" copy /Y "supervisor-3099.js" "..\supervisor-3099.js" >nul
if exist "version.json" copy /Y "version.json" "..\version.json" >nul
if exist "START_SERVER_20BOX.bat" copy /Y "START_SERVER_20BOX.bat" "..\START_SERVER_20BOX.bat" >nul
copy /Y "%~f0" "..\CHAY_CAP_NHAT_TU_DONG.bat" >nul 2>&1
cd /d ".."
goto :START_NOW

:COPY_TO_PARENT_2
echo [2/3] Phat hien giai nen ra thu muc con (2 cap), dang cap nhat de vao thu muc goc Server...
if exist "src" xcopy /E /Y /I "src" "..\..\src" >nul
if exist "server.js" copy /Y "server.js" "..\..\server.js" >nul
if exist "supervisor-3099.js" copy /Y "supervisor-3099.js" "..\..\supervisor-3099.js" >nul
if exist "version.json" copy /Y "version.json" "..\..\version.json" >nul
if exist "START_SERVER_20BOX.bat" copy /Y "START_SERVER_20BOX.bat" "..\..\START_SERVER_20BOX.bat" >nul
copy /Y "%~f0" "..\..\CHAY_CAP_NHAT_TU_DONG.bat" >nul 2>&1
cd /d "..\.."
goto :START_NOW

:START_NOW
echo [*] Dang kiem tra toan ven va tu dong phuc hoi config\api_keys.json (neu bi loi mat dien)...
set "CHECK_NODE=node"
if exist "%CD%\node.exe" set "CHECK_NODE=%CD%\node.exe"
"%CHECK_NODE%" -e "const fs=require('fs'),p=require('path');const f1='config/api_keys.json',f2='config/api_keys.backup.json',f3='config/api_keys.prev.json';function ok(f){try{if(!fs.existsSync(f))return null;const s=fs.readFileSync(f,'utf8').replace(/^\uFEFF/,'').replace(/\u0000+$/g,'').trim();if(!s||s.includes('\u0000'))return null;const j=JSON.parse(s);return Array.isArray(j.keys)?j:null;}catch(e){return null;}}const d1=ok(f1),d2=ok(f2),d3=ok(f3);if(!d1&&(d2||d3)){const src=d2||d3,srcName=d2?f2:f3;try{if(fs.existsSync(f1))fs.copyFileSync(f1,'config/api_keys.corrupted.bak');}catch(_){}fs.writeFileSync(f1,JSON.stringify(src,null,2),'utf8');console.log('   -> [KHOI PHUC THANH CONG] Da phuc hoi '+src.keys.length+' API Key tu '+srcName+'!');}else if(d1){console.log('   -> [AN TOAN] File api_keys.json hop le ('+d1.keys.length+' API Key).');}else{console.log('   -> [CANH BAO] Chua tim thay ban backup hop le tren dia, mo http://localhost:3099 de Nhap Backup!');}" 2>nul

echo [3/3] Dang khoi dong lai Server 3099 tu thu muc goc: %CD%
if exist "START_SERVER_20BOX.bat" (
    start "Shopee Farm Server 3099" cmd /k "call START_SERVER_20BOX.bat"
) else (
    start "Shopee Farm Server 3099" cmd /k "node supervisor-3099.js"
)
echo.
echo [HOAN TAT] Da cap nhat tat ca file moi nhat va khoi dong lai Server 3099 thanh cong!
echo Anh co the dong cua so nay.
timeout /t 4 >nul
